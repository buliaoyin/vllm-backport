import gzip
import hashlib
import json
import os
from pathlib import Path
import subprocess
import time

ROOT = Path('/home/bul/dev/vllm-backport')
OUT = Path('/tmp/exl3-fixed-pp-20260910')
protocol = json.loads((OUT / 'protocol.json').read_text())
original = ROOT / 'docs/validation/exl3-long-20260910/moe-inputs.json.gz'
base = json.loads(gzip.decompress(original.read_bytes()))
base['cases'] = [case for case in base['cases'] if len(case['inputs']) == 1]
base['evals'] = []
assert [len(case['inputs'][0]) for case in base['cases']] == [8192, 16384, 32768, 65536]
long_protocol = {
    'pp_layers': [11, 11, 11, 12], 'expected_decoder_ids': protocol['expected_decoder_ids'],
    'chunk_size': 1024, 'max_model_len': 66560, 'kv_cache_gib': 8,
    'warmups': 1, 'repeats': 3, 'output_tokens': 32, 'max_num_seqs': 4, 'batch_requests': 1,
    'source_input': str(original.relative_to(ROOT)),
    'source_input_sha256': hashlib.sha256(original.read_bytes()).hexdigest(),
    'inputs': {}, 'sources': protocol['sources'],
    'comment': 'Every format uses identical B1 cases, original decoder partition and common long-context settings.',
}
for fmt in ('exl3', 'nvfp4', 'awq'):
    short_input = json.loads(gzip.decompress((OUT / f'{fmt}-inputs.json.gz').read_bytes()))
    data = dict(base, model=short_input['model'])
    assert data['eos_ids'] == short_input['eos_ids']
    assert data['cases'][0] == short_input['cases'][0]
    payload = gzip.compress(json.dumps(data, ensure_ascii=False).encode(), mtime=0)
    filename = f'{fmt}-long-b1-inputs.json.gz'
    (OUT / filename).write_bytes(payload)
    long_protocol['inputs'][fmt] = {'file': filename, 'sha256': hashlib.sha256(payload).hexdigest(), 'model': data['model']}
(OUT / 'long-protocol.json').write_text(json.dumps(long_protocol, indent=2, ensure_ascii=False))

short_status = json.loads((OUT / 'status.json').read_text())
assert len(short_status) == 6 and all(s['state'] == 'complete' for s in short_status)
status = []
for fmt in ('exl3', 'nvfp4', 'awq'):
    name = f'{fmt}-long-pp11-11-11-12-c1024'
    output = OUT / f'{name}.json'
    cmd = [
        str(ROOT / '.venv/bin/python'), str(ROOT / 'benchmarks/benchmark_exl3.py'),
        '--backend', 'vllm', '--inputs', str(OUT / f'{fmt}-long-b1-inputs.json.gz'),
        '--output', str(output), '--pp', '4', '--expected-layer-counts', '11', '11', '11', '12',
        '--chunk-size', '1024', '--max-model-len', '66560', '--kv-cache-gib', '8',
        '--batch-size', '4', '--warmups', '1', '--repeats', '3', '--tokens', '32', '--skip-eval',
    ]
    environment = dict(
        CUDA_DEVICE_ORDER='PCI_BUS_ID', CUDA_VISIBLE_DEVICES='0,1,2,3',
        NCCL_P2P_DISABLE='1', VLLM_PP_LAYER_PARTITION='11,11,11,12', OMP_NUM_THREADS='1',
        EXL3_INT8_GEMV='0', VLLM_DETERMINISTIC_MOE_ALIGN='0',
        VLLM_EXL3_MOE_MAX_TOKENS='1024', VLLM_EXL3_MOE_PRIORITY='1',
    )
    record = {'name': name, 'command': cmd, 'environment': environment, 'start': time.time(), 'state': 'running'}
    status.append(record)
    (OUT / 'long-status.json').write_text(json.dumps(status, indent=2))
    print('RUN', name, flush=True)
    with (OUT / f'{name}.log').open('w') as log:
        proc = subprocess.run(cmd, cwd=ROOT, env=dict(os.environ, **environment), stdout=log, stderr=subprocess.STDOUT)
    record.update(exit_code=proc.returncode, end=time.time(), state='complete' if proc.returncode == 0 else 'failed')
    if proc.returncode == 0:
        result = json.loads(output.read_text())
        ranks = sorted(result['runtime_before'], key=lambda r: r['pp_rank'])
        assert [sorted(layer['index'] for layer in r['decoder_layers']) for r in ranks] == protocol['expected_decoder_ids']
        assert len(result['perf']) == 12
        assert all(check['matched'] for perf in result['perf'] for check in perf['checks'])
        assert all(row['cached_tokens'] == 0 and row['new_tokens'] == 32 for perf in result['perf'] for row in perf['rows'])
        record['postcheck'] = 'passed'
    (OUT / 'long-status.json').write_text(json.dumps(status, indent=2))
    print('DONE', name, proc.returncode, flush=True)
    if proc.returncode:
        raise SystemExit(proc.returncode)
for relative, metadata in protocol['sources'].items():
    assert hashlib.sha256((ROOT / relative).read_bytes()).hexdigest() == metadata['sha256'], relative
print('ALL_LONG_COMPLETE', flush=True)
