import gzip
import hashlib
import json
from pathlib import Path

repo=Path('/home/bul/dev/vllm-backport')
root=Path('/tmp/exl3-fixed-pp-20260910')
protocol=json.loads((root/'protocol.json').read_text())
long_protocol=json.loads((root/'long-protocol.json').read_text())
expected=protocol['expected_decoder_ids']
validation={'source_hashes_unchanged':True,'runs':[],'inputs_identical_across_formats':{}}
for p in (protocol,long_protocol):
    cases=[]
    for fmt in ('exl3','nvfp4','awq'):
        m=p['inputs'][fmt]
        payload=(root/m['file']).read_bytes()
        assert hashlib.sha256(payload).hexdigest()==m['sha256']
        cases.append(json.loads(gzip.decompress(payload)))
    assert all(c['cases']==cases[0]['cases'] and c['eos_ids']==cases[0]['eos_ids'] for c in cases)
    validation['inputs_identical_across_formats']['long' if p is long_protocol else '8k']=True
for name in ('status.json','long-status.json'):
    for status in json.loads((root/name).read_text()):
        assert status['exit_code']==0 and status['postcheck']=='passed'
        result=json.loads((root/(status['name']+'.json')).read_text())
        ranks=sorted(result['runtime_before'],key=lambda r:r['pp_rank'])
        actual=[sorted(layer['index'] for layer in r['decoder_layers']) for r in ranks]
        assert actual==expected
        a=result['args']
        assert a['tokens']==32 and a['batch_size']==4 and a['repeats']==3 and a['warmups']==1
        assert a['pp']==4 and not a['eager'] and a['skip_eval'] and not a['skip_perf']
        log=(root/(status['name']+'.log')).read_text()
        warmup=log.index('WARMUP p8192_b1')
        last_measure=max(i for i in range(len(log)) if log.startswith('MAX_TTFT', i))
        timing_log=log[warmup:last_measure]
        allocation_error='memory allocation failed with OOM'
        assert allocation_error not in timing_log and 'torch.OutOfMemoryError' not in timing_log
        assert 'Traceback (most recent call last)' not in log
        validation['runs'].append({
            'name':status['name'],'decoder_layer_indices_verified':True,
            'all_retrieval_checks_passed':all(c['matched'] for p in result['perf'] for c in p['checks']),
            'no_allocation_retries_during_timing':True,
            'allocation_retry_messages_before_timing':log[:warmup].count(allocation_error),
            'measured_requests':len(result['perf']),
        })
for rel, meta in protocol['sources'].items():
    assert hashlib.sha256((repo/rel).read_bytes()).hexdigest()==meta['sha256']
for rel in ('vllm/model_executor/layers/quantization/exl3.py','vllm/envs.py'):
    old=repo/'docs/validation/exl3-opt-20260910/current-sources'/(rel+'.gz')
    assert gzip.decompress(old.read_bytes())==(repo/rel).read_bytes()
validation['production_matches_previous_final_snapshot']=True
assert len(validation['runs'])==9
assert sum(r['measured_requests'] for r in validation['runs'])==60
(root/'validation.json').write_text(json.dumps(validation,indent=2))
print(json.dumps(validation,indent=2))
