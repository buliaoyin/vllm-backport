import gzip
import hashlib
import json
import os
from pathlib import Path
import subprocess
import time

ROOT = Path('/home/bul/dev/vllm-backport')
OUT = Path('/tmp/exl3-fixed-pp-20260910')
ORIGINAL = ROOT / 'docs/validation/exl3-prefill-20260910'
PARTITION = [11, 11, 11, 12]

def sha(data):
    return hashlib.sha256(data).hexdigest()

protocol = json.loads((ORIGINAL / 'protocol.json').read_text())
assert protocol['pp_layers'] == PARTITION
payloads = {}
inputs = {}
for fmt in ('exl3', 'nvfp4', 'awq'):
    path = ORIGINAL / f'{fmt}-inputs.json.gz'
    payloads[fmt] = json.loads(gzip.decompress(path.read_bytes()))
    (OUT / path.name).write_bytes(path.read_bytes())
    inputs[fmt] = {
        'file': path.name,
        'sha256': sha(path.read_bytes()),
        'tokenizer_sha256': sha((Path(payloads[fmt]['model']) / 'tokenizer.json').read_bytes()),
    }
    assert payloads[fmt]['cases'] == payloads['exl3']['cases']
    assert inputs[fmt]['tokenizer_sha256'] == protocol['tokenizer_sha256']
assert len(payloads['exl3']['cases']) == 1
assert len(payloads['exl3']['cases'][0]['inputs']) == 1
assert len(payloads['exl3']['cases'][0]['inputs'][0]) == 8192

sources = {}
source_dir = OUT / 'sources'
source_dir.mkdir(exist_ok=True)
for relative in (
    'benchmarks/benchmark_exl3.py',
    'benchmarks/exl3_profile_worker.py',
    'benchmarks/kernels/benchmark_exl3_moe.py',
    'vllm/model_executor/layers/quantization/exl3.py',
    'vllm/envs.py',
    'vllm/model_executor/layers/fused_moe/fused_moe_method_base.py',
    'vllm/model_executor/layers/fused_moe/runner/moe_runner.py',
    'vllm/model_executor/layers/fused_moe/runner/shared_experts.py',
    'vllm/model_executor/model_loader/default_loader.py',
    'vllm/models/glm5next/nvidia/model.py',
    'vllm/models/glm5next/nvidia/kda.py',
):
    data = (ROOT / relative).read_bytes()
    filename = relative.replace('/', '__') + '.gz'
    (source_dir / filename).write_bytes(gzip.compress(data, mtime=0))
    sources[relative] = {'sha256': sha(data), 'snapshot': 'sources/' + filename}

variants = [
    {'capacity': None, 'label': 'production-before'},
    {'capacity': 128, 'priority': False, 'label': 'legacy-settings'},
    {'capacity': 512, 'priority': True, 'label': 'production-after'},
]
(OUT / 'exl3-c512-variants.json').write_text(json.dumps(variants, indent=2))
protocol.update({
    'chunks': [512, 1024],
    'batch_requests': 1,
    'max_num_seqs': 4,
    'comparison': 'All formats use original PP 11/11/11/12. Main comparison retains chunk 512. Secondary comparison uses chunk 1024 for every format.',
    'timing_statistic': 'median of three requests; production-before is the primary EXL3 c512 measurement',
    'exl3_c512_control': 'Production / legacy capacity128 priority0 / restored production; native production fused function is used in every case.',
    'expected_decoder_ids': [list(range(0, 11)), list(range(11, 22)), list(range(22, 33)), list(range(33, 45))],
    'inputs': inputs,
    'sources': sources,
    'revision': subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=ROOT, text=True).strip(),
})
(OUT / 'protocol.json').write_text(json.dumps(protocol, indent=2, ensure_ascii=False))
(OUT / 'git-status.txt').write_text(subprocess.check_output(['git', 'status', '--short'], cwd=ROOT, text=True))

status = []
for fmt, chunk in [('exl3', 512), ('nvfp4', 512), ('awq', 512), ('awq', 1024), ('nvfp4', 1024), ('exl3', 1024)]:
    name = f'{fmt}-pp11-11-11-12-c{chunk}'
    output = OUT / f'{name}.json'
    cmd = [
        str(ROOT / '.venv/bin/python'), str(ROOT / 'benchmarks/benchmark_exl3.py'),
        '--backend', 'vllm', '--inputs', str(OUT / f'{fmt}-inputs.json.gz'),
        '--output', str(output), '--pp', '4', '--expected-layer-counts', '11', '11', '11', '12',
        '--chunk-size', str(chunk), '--max-model-len', '16384', '--kv-cache-gib', '4',
        '--batch-size', '4', '--warmups', '1', '--repeats', '3', '--tokens', '32',
        '--skip-eval', '--event-profile',
    ]
    if fmt == 'exl3' and chunk == 512:
        cmd.extend(['--moe-variants', str(OUT / 'exl3-c512-variants.json')])
    environment = dict(
        CUDA_DEVICE_ORDER='PCI_BUS_ID', CUDA_VISIBLE_DEVICES='0,1,2,3',
        NCCL_P2P_DISABLE='1', VLLM_PP_LAYER_PARTITION='11,11,11,12', OMP_NUM_THREADS='1',
        EXL3_INT8_GEMV='0', VLLM_DETERMINISTIC_MOE_ALIGN='0',
        VLLM_EXL3_MOE_MAX_TOKENS='1024', VLLM_EXL3_MOE_PRIORITY='1',
    )
    record = {'name': name, 'command': cmd, 'environment': environment, 'start': time.time(), 'state': 'running'}
    status.append(record)
    (OUT / 'status.json').write_text(json.dumps(status, indent=2))
    print('RUN', name, flush=True)
    with (OUT / f'{name}.log').open('w') as log:
        proc = subprocess.run(cmd, cwd=ROOT, env=dict(os.environ, **environment), stdout=log, stderr=subprocess.STDOUT)
    record.update(exit_code=proc.returncode, end=time.time(), state='complete' if proc.returncode == 0 else 'failed')
    if proc.returncode == 0:
        result = json.loads(output.read_text())
        ranks = sorted(result['runtime_before'], key=lambda r: r['pp_rank'])
        assert [sorted(layer['index'] for layer in r['decoder_layers']) for r in ranks] == protocol['expected_decoder_ids']
        assert all(check['matched'] for perf in result['perf'] for check in perf['checks'])
        assert all(row['cached_tokens'] == 0 and row['prompt_tokens'] == 8192 and row['new_tokens'] == 32 for perf in result['perf'] for row in perf['rows'])
        record['postcheck'] = 'passed'
    (OUT / 'status.json').write_text(json.dumps(status, indent=2))
    print('DONE', name, proc.returncode, flush=True)
    if proc.returncode:
        raise SystemExit(proc.returncode)
for relative, metadata in sources.items():
    assert sha((ROOT / relative).read_bytes()) == metadata['sha256'], relative
print('ALL_COMPLETE', flush=True)
