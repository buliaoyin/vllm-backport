import argparse
import gzip
import hashlib
import json
from pathlib import Path
from statistics import median

parser = argparse.ArgumentParser()
parser.add_argument('--root', type=Path, default=Path('/tmp/exl3-fixed-pp-20260910'))
parser.add_argument('--require-complete', action='store_true')
args = parser.parse_args()
root = args.root
protocol = json.loads((root / 'protocol.json').read_text())
summary = {'conditions': {'pp_layers': protocol['pp_layers'], 'chunks': protocol['chunks']}, 'runs': [], 'all_checks': 0, 'all_checks_passed': 0}
for path in sorted(root.glob('*-pp11-11-11-12-c*.json')):
    data = json.loads(path.read_text())
    if not data['perf']:
        continue
    ranks = sorted(data['runtime_before'], key=lambda r: r['pp_rank'])
    actual = [sorted(layer['index'] for layer in rank['decoder_layers']) for rank in ranks]
    assert actual == protocol['expected_decoder_ids'], (path, actual)
    assert data['environment']['VLLM_PP_LAYER_PARTITION'] == '11,11,11,12'
    assert data['benchmark_source_sha256'] == protocol['sources']['benchmarks/benchmark_exl3.py']['sha256']
    groups = {}
    for record in data['perf']:
        label = record['variant'].get('label', 'production')
        groups.setdefault((record['case'], label), []).append(record)
    for (case, label), records in groups.items():
        assert len(records) == data['args']['repeats'] or not args.require_complete
        rows = [record['rows'][0] for record in records]
        assert all(len(record['rows']) == 1 for record in records)
        assert all(row['cached_tokens'] == 0 and row['new_tokens'] == 32 for row in rows)
        checks = [check for record in records for check in record['checks']]
        summary['all_checks'] += len(checks)
        summary['all_checks_passed'] += sum(check['matched'] for check in checks)
        item = {
            'file': path.name, 'format': path.name.split('-')[0], 'case': case, 'variant': label,
            'prompt_tokens': rows[0]['prompt_tokens'], 'chunk': data['args']['chunk_size'],
            'max_model_len': data['args']['max_model_len'], 'kv_cache_gib': data['args']['kv_cache_gib'],
            'ttft_s': median(row['ttft'] for row in rows),
            'ttft_samples_s': [row['ttft'] for row in rows],
            'prefill_s': median(row['prefill'] for row in rows),
            'prefill_tokens_per_s': median(row['prompt_tokens'] / row['prefill'] for row in rows),
            'decode_tokens_per_s': median((row['new_tokens'] - 1) / row['decode'] for row in rows),
            'total_seconds': median(record['seconds'] for record in records),
            'checks_passed': sum(check['matched'] for check in checks), 'checks_total': len(checks),
            'decoder_ids': actual,
        }
        if 'event_profile' in data and label in ('production', 'production-after'):
            item['profile_rank_sums_ms'] = [
                {label: sum(values) for label, values in rank['timings_ms'].items()}
                for rank in data['event_profile']['ranks']
            ]
            item['profile_is_independent_request'] = True
        summary['runs'].append(item)
if args.require_complete:
    status = json.loads((root / 'status.json').read_text())
    assert len(status) == 6 and all(s['state'] == 'complete' and s['postcheck'] == 'passed' for s in status)
    assert summary['all_checks_passed'] == summary['all_checks']
    assert len(summary['runs']) >= 8
(root / 'summary.json').write_text(json.dumps(summary, ensure_ascii=False, indent=2))
for item in summary['runs']:
    print(item['format'], item['chunk'], item['case'], item['variant'], 'TTFT', round(item['ttft_s'], 4), 'TPS', round(item['prefill_tokens_per_s'], 1), 'checks', f"{item['checks_passed']}/{item['checks_total']}")
print('CHECKS', summary['all_checks_passed'], '/', summary['all_checks'])
