import gzip,hashlib,json,subprocess
from pathlib import Path
R=Path('/home/bul/dev/vllm-backport');O=Path('/tmp/exl3-hybrid-default-20260911');D=R/'docs/validation/exl3-hybrid-default-20260911'
D.mkdir(parents=True,exist_ok=True)
source_files=['vllm/model_executor/layers/quantization/exl3.py','vllm/envs.py','vllm/engine/arg_utils.py','benchmarks/exl3_profile_worker.py','tests/quantization/test_exl3.py','vllm/_exl3_C.abi3.so']
source_files+=sorted(str(p.relative_to(R)) for p in (R/'csrc/libtorch_stable/quantization/exl3').rglob('*') if p.is_file())
(O/'final-source-hashes.json').write_text(json.dumps({f:hashlib.sha256((R/f).read_bytes()).hexdigest() for f in source_files},indent=2))
files=['inputs.json.gz','native-before.json','hybrid-default.json','native-after.json','native-before.log','hybrid-default.log','native-after.log','summary.json','model-status.json','kernel-status.json','final-checks.json','build.json','measured-build.json','source-provenance.json','runtime-source-hashes.json','final-source-hashes.json','sass-equivalence.json','measured-sass-equivalence.json','rebuild-equivalence.json','sm80.log','sm120.log','memcheck-sm120.log','racecheck-sm120.log','rebuilt-sm80.log','rebuilt-sm120.log','precommit-first.log','precommit-final.log','build.log','rebuild.log','sass-final.log','benchmark_model.py','run_models.py','summarize.py','validate_kernels.py','build.py','compare_sass.py','final_checks.py','archive.py','render_report.py','mypy312.log','mypy312-final.log']
manifest={}
for name in files:
 src=O/name
 if not src.exists():
  assert name=='precommit-final.log',name
  continue
 dst=D/(name if name.endswith('.gz') else name+'.gz')
 content=src.read_bytes();dst.write_bytes(content if name.endswith('.gz') else gzip.compress(content,mtime=0))
 manifest[dst.name]={'bytes':dst.stat().st_size,'sha256':hashlib.sha256(dst.read_bytes()).hexdigest(),'uncompressed_sha256':hashlib.sha256(gzip.decompress(dst.read_bytes())).hexdigest()}
(D/'manifest.json').write_text(json.dumps({'revision':subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip(),'artifacts':manifest},indent=2)+'\n')
print('Archived',len(manifest),'files')
