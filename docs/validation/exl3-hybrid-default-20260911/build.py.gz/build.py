import hashlib,json,os,subprocess,time
from pathlib import Path
R=Path('/home/bul/dev/vllm-backport');O=Path('/tmp/exl3-hybrid-default-20260911');B=Path('/tmp/exl3-defaults-20260911/full-build')
env=dict(os.environ,CUDA_VISIBLE_DEVICES='',OMP_NUM_THREADS='1')
commands=[[str(R/'.venv/bin/cmake'),'--build',str(B),'--target','_exl3_C','--parallel','2'],[str(R/'.venv/bin/cmake'),'--install',str(B),'--component','_exl3_C']]
metadata={'commands':commands,'start':time.time(),'sources':{str(p.relative_to(R)):hashlib.sha256(p.read_bytes()).hexdigest() for p in (R/'csrc/libtorch_stable/quantization/exl3').rglob('*') if p.is_file()}}
(O/'build.json').write_text(json.dumps(metadata,indent=2))
for cmd in commands:subprocess.run(cmd,cwd=R,env=env,check=True)
p=R/'vllm/_exl3_C.abi3.so';metadata.update(library=str(p),sha256=hashlib.sha256(p.read_bytes()).hexdigest(),end=time.time());(O/'build.json').write_text(json.dumps(metadata,indent=2))
