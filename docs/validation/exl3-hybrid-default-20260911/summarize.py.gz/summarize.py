import collections
import hashlib
import json
import statistics
from pathlib import Path

O = Path('/tmp/exl3-hybrid-default-20260911')
names = ('native-before', 'hybrid-default', 'native-after')
results = {name: json.loads((O / (name + '.json')).read_text()) for name in names}
status = json.loads((O / 'model-status.json').read_text())
assert len(status) == 3 and all(x.get('exit_code') == 0 for x in status)
assert len({r['inputs_sha256'] for r in results.values()}) == 1
assert len({r['benchmark_source_sha256'] for r in results.values()}) == 1
source_hash = hashlib.sha256((O / 'benchmark_model.py').read_bytes()).hexdigest()
assert all(r['benchmark_source_sha256'] == source_hash for r in results.values())
audit = {}
for name, r in results.items():
    assert r['resolved_chunk_size'] == 2048 and r['args']['chunk_size'] is None
    assert r['args']['moe_variants'] is None and r['args']['worker_extension_cls'] == ''
    env = r['environment']
    assert all(env[k] is None for k in ('EXL3_INT8_GEMV', 'VLLM_EXL3_MOE_M_TILE', 'VLLM_EXL3_MOE_MAX_TOKENS', 'VLLM_EXL3_MOE_PRIORITY'))
    assert env['VLLM_EXL3_MOE_DECODE'] == (None if name == 'hybrid-default' else 'native')
    phases = {}
    for phase in ('runtime_before', 'runtime_after'):
        ranks = sorted(r[phase], key=lambda x: x['pp_rank'])
        assert len(ranks) == 4
        rows = []
        offset = 0
        for rank, count in zip(ranks, (11, 11, 11, 12)):
            ids = sorted(layer['index'] for layer in rank['decoder_layers'])
            assert ids == list(range(offset, offset + count))
            offset += count
            expected_mode = ('plain' if rank['pp_rank'] < 3 else 'residual') if name == 'hybrid-default' else 'native'
            assert all(layer['decode_mode'] == expected_mode and layer['m_tile'] == (32 if rank['pp_rank'] < 3 else 16) and layer['capacity'] == 2048 for layer in rank['layers'])
            assert rank['priority'] is True
            rows.append({'rank': rank['pp_rank'], 'layer_ids': ids, 'expert_layers': len(rank['layers']), 'decode_mode': expected_mode, 'm_tile': 32 if rank['pp_rank'] < 3 else 16, 'capacity': 2048})
        phases[phase] = rows
    perf_rows = [row for p in r['perf'] for row in p['rows']]
    assert all(row['cached_tokens'] == 0 for row in perf_rows + r['eval'])
    assert all(row['finish_reason'] == 'length' for row in perf_rows)
    audit[name] = phases

def describe(values):
    return {'median': statistics.median(values), 'min': min(values), 'max': max(values), 'samples': values}

cases = sorted({p['case'] for r in results.values() for p in r['perf']}, key=lambda s: (int(s.split('_')[0][1:]), int(s.split('_')[1][1:])))
perf = []
for case in cases:
    groups = {}
    for name, r in results.items():
        samples = [p for p in r['perf'] if p['case'] == case]
        assert len(samples) == (2 if name == 'native-after' else 3)
        metrics = {'input_tps': [sum(row['prompt_tokens'] for row in p['rows']) / p['max_ttft'] for p in samples], 'generate_output_tps': [p['throughput'] for p in samples]}
        if len(samples[0]['rows']) == 1:
            metrics['decode_tps'] = [(p['rows'][0]['new_tokens'] - 1) / p['rows'][0]['decode'] for p in samples]
        groups[name] = {k: describe(v) for k, v in metrics.items()}
    baseline = {key: describe(groups['native-before'][key]['samples'] + groups['native-after'][key]['samples']) for key in groups['native-before']}
    candidate = groups['hybrid-default']
    perf.append({'case': case, 'baseline': baseline, 'hybrid': candidate, 'gain_percent': {key: (candidate[key]['median'] / baseline[key]['median'] - 1) * 100 for key in baseline}, 'processes': groups})

a = {x['id']: x for x in results['native-before']['eval']}
b = {x['id']: x for x in results['hybrid-default']['eval']}
assert len(a) == len(b) == 64 and set(a) == set(b)
assert not results['native-after']['eval']
quality = {'count': len(a), 'native_correct': sum(x['correct'] for x in a.values()), 'hybrid_correct': sum(x['correct'] for x in b.values()), 'native_wrong': [i for i in a if not a[i]['correct']], 'hybrid_wrong': [i for i in a if not b[i]['correct']], 'new_wrong': [i for i in a if a[i]['correct'] and not b[i]['correct']], 'fixed': [i for i in a if not a[i]['correct'] and b[i]['correct']], 'answers_equal': sum(a[i]['predicted'] == b[i]['predicted'] for i in a), 'tokens_equal': sum(a[i]['token_ids'] == b[i]['token_ids'] for i in a), 'native_truncated': [i for i in a if a[i]['finish_reason'] == 'length'], 'hybrid_truncated': [i for i in a if b[i]['finish_reason'] == 'length'], 'native_finish_reasons': dict(collections.Counter(x['finish_reason'] for x in a.values())), 'hybrid_finish_reasons': dict(collections.Counter(x['finish_reason'] for x in b.values()))}
retrieval = {}
for name, r in results.items():
    checks = [check for p in r['perf'] for check in p.get('checks', [])]
    retrieval[name] = {'matched': sum(x['matched'] for x in checks), 'total': len(checks)}
summary = {'perf': perf, 'quality': quality, 'retrieval': retrieval, 'runtime_audit': audit, 'benchmark_source_sha256': source_hash, 'inputs_sha256': results['native-before']['inputs_sha256']}
(O / 'summary.json').write_text(json.dumps(summary, ensure_ascii=False, indent=2))
for row in perf:
    metric = 'decode_tps' if 'decode_tps' in row['baseline'] else 'generate_output_tps'
    print(row['case'], metric, round(row['baseline'][metric]['median'], 3), '->', round(row['hybrid'][metric]['median'], 3), round(row['gain_percent'][metric], 2), '%')
print(json.dumps(quality, ensure_ascii=False))
print(json.dumps(retrieval, ensure_ascii=False))
