import gzip,json,os,subprocess,time
from pathlib import Path
R=Path('/home/bul/dev/vllm-backport');O=Path('/tmp/exl3-hybrid-default-20260911');D=Path('/tmp/exl3-defaults-20260911');C=Path('/tmp/exl3-int8-combo-20260911')
while True:
    try:
        tests=json.loads((O/'kernel-status.json').read_text())
        if any(x.get('exit_code',0)!=0 for x in tests):raise RuntimeError('Kernel validation failed')
        if len(tests)==4 and all(x.get('exit_code')==0 for x in tests):break
    except json.JSONDecodeError:pass
    time.sleep(5)
s=(D/'benchmark_defaults.py').read_text().replace('                "EXL3_INT8_GEMV",','                "EXL3_INT8_GEMV",\n                "VLLM_EXL3_MOE_DECODE",\n                "VLLM_EXL3_MOE_M_TILE",')
(O/'benchmark_model.py').write_text(s)
data=json.loads(gzip.decompress((C/'moe-inputs.json.gz').read_bytes()))
data['cases']=[c for c in data['cases'] if c['name'] in ('p2048_b1','p2048_b4','p8192_b1','p65536_b1')]
(O/'inputs.json.gz').write_bytes(gzip.compress(json.dumps(data).encode(),mtime=0))
status=[]
for name,policy,repeats,quality in [('native-before','native',3,True),('hybrid-default',None,3,True),('native-after','native',2,False)]:
 env={k:v for k,v in os.environ.items() if not k.startswith(('VLLM_EXL3_','EXL3_'))}
 env.update(CUDA_VISIBLE_DEVICES='0,1,2,3',CUDA_DEVICE_ORDER='PCI_BUS_ID',OMP_NUM_THREADS='1',NCCL_P2P_DISABLE='1',VLLM_PP_LAYER_PARTITION='11,11,11,12',PYTHONPATH=str(R/'benchmarks')+':'+str(R))
 if policy is not None:env['VLLM_EXL3_MOE_DECODE']=policy
 command=[str(R/'.venv/bin/python'),str(O/'benchmark_model.py'),'--backend','vllm','--inputs',str(O/'inputs.json.gz'),'--output',str(O/(name+'.json')),'--pp','4','--expected-layer-counts','11','11','11','12','--max-model-len','66560','--kv-cache-gib','8','--batch-size','4','--eval-batch-size','1','--warmups','1','--repeats',str(repeats),'--tokens','32','--eval-tokens','768']
 if not quality:command+=['--skip-eval']
 record={'name':name,'command':command,'environment':{k:v for k,v in env.items() if k.startswith(('CUDA_','VLLM_','EXL3_','NCCL_','OMP_','PYTHONPATH'))},'start':time.time()};status.append(record);(O/'model-status.json').write_text(json.dumps(status,indent=2));print('START',name,flush=True)
 with (O/(name+'.log')).open('w') as log:r=subprocess.run(command,cwd=R,env=env,stdout=log,stderr=subprocess.STDOUT)
 record.update(exit_code=r.returncode,end=time.time());(O/'model-status.json').write_text(json.dumps(status,indent=2));print('DONE',name,r.returncode,flush=True)
 if r.returncode:raise SystemExit(r.returncode)
