import hashlib,json,re,subprocess
from pathlib import Path
O=Path('/tmp/exl3-hybrid-default-20260911')
paths=['/tmp/exl3-moe-next-20260911/final-decode/decode.so','/home/bul/dev/vllm-backport/vllm/_exl3_C.abi3.so']
def extract(path):
    output=subprocess.check_output(['/usr/local/cuda/bin/cuobjdump','--dump-sass',path],text=True)
    arch=name=None;functions={}
    for line in output.splitlines():
        if line.startswith('arch = '):arch=line.split(' = ')[1]
        if 'Function :' in line:
            name=line.split('Function :')[1].strip();functions[arch,name]=[]
        elif name:
            m=re.match(r'\s*/\*[0-9a-f]+\*/\s+(.*?)\s*/\* 0x[0-9a-f]+ \*/',line)
            if m:functions[arch,name].append(m[1])
    return {k:v for k,v in functions.items() if 'exl3_expert' in k[1] and v}
a,b=[extract(p) for p in paths]
assert len(a)==10 and set(a)<=set(b),(len(a),set(a)-set(b))
records=[{'arch':k[0],'kernel':k[1],'reference_instructions':len(v),'native_instructions':len(b[k]),'identical':v==b[k]} for k,v in a.items()]
result={'libraries':[{ 'path':p,'sha256':hashlib.sha256(Path(p).read_bytes()).hexdigest()} for p in paths],'kernels':records,'all_identical':all(r['identical'] for r in records)}
(O/'sass-equivalence.json').write_text(json.dumps(result,indent=2));print(json.dumps(result,indent=2))
