import hashlib,json,os,shutil,subprocess,time
from pathlib import Path
R=Path('/home/bul/dev/vllm-backport');O=Path('/tmp/exl3-hybrid-default-20260911')
while True:
    try:
        status=json.loads((O/'model-status.json').read_text())
        if any(x.get('exit_code',0)!=0 for x in status):raise RuntimeError('Model run failed')
        if len(status)==3 and all(x.get('exit_code')==0 for x in status):break
    except json.JSONDecodeError:pass
    time.sleep(5)
records=[]
def run(name,cmd,env=None):
    record={'name':name,'command':cmd,'start':time.time()};records.append(record);print('START',name,flush=True)
    with (O/(name+'.log')).open('w') as log:r=subprocess.run(cmd,cwd=R,env=env,stdout=log,stderr=subprocess.STDOUT)
    record.update(exit_code=r.returncode,end=time.time());(O/'final-checks.json').write_text(json.dumps(records,indent=2));print('DONE',name,r.returncode,flush=True)
    return r.returncode
# Verify every measured process used the same frozen runtime and native binary.
old=json.loads((O/'runtime-source-hashes.json').read_text())
assert all(hashlib.sha256((R/f).read_bytes()).hexdigest()==sha for f,sha in old.items())
assert run('summarize',[str(R/'.venv/bin/python'),str(O/'summarize.py')])==0
# A local variable used for two differently sized tuple keys confused mypy.
# Rename only the decode key after all measured model processes have exited.
p=R/'vllm/model_executor/layers/quantization/exl3.py';text=p.read_text()
old_key="""            key = (device, stride)
            if key not in self.config.decode_workspaces:
                self.config.decode_workspaces[key] = torch.zeros(
                    (64, stride), device=device, dtype=torch.int32
                )
            self.decode_workspace = self.config.decode_workspaces[key]"""
new_key=old_key.replace('key', 'decode_key')
assert text.count(old_key)==1
p.write_text(text.replace(old_key,new_key))

shutil.copy2(R/'vllm/_exl3_C.abi3.so',O/'measured-exl3.so')
shutil.copy2(O/'build.json',O/'measured-build.json')
# Include all existing related work so the final workspace passes the repo hooks.
paths=set(subprocess.check_output(['git','diff','--name-only'],cwd=R,text=True).splitlines())
paths.update(subprocess.check_output(['git','ls-files','--others','--exclude-standard'],cwd=R,text=True).splitlines())
paths=sorted(p for p in paths if Path(R/p).is_file())
command=[str(R/'.venv/bin/pre-commit'),'run','--files',*paths]
first=run('precommit-first',command)
if first:assert run('precommit-final',command)==0,'Inspect precommit logs'
assert run('mypy312-final',[str(R/'.venv/bin/pre-commit'),'run','mypy-3.12','--hook-stage','manual','--files','vllm/model_executor/layers/quantization/exl3.py','vllm/envs.py','benchmarks/exl3_profile_worker.py','benchmarks/kernels/exl3_m32/worker.py','tests/quantization/test_exl3.py'])==0
assert run('rebuild',[str(R/'.venv/bin/python'),str(O/'build.py')])==0
assert run('sass-final',[str(R/'.venv/bin/python'),str(O/'compare_sass.py')])==0
# Compare all CUDA kernel instruction text before/after formatting/rebuild.
script=(O/'compare_sass.py').read_text()
ns={};exec(script[:script.index('a,b=[extract(p)')].replace("if 'exl3_expert' in k[1] and v",'if v'),ns)
a,b=[ns['extract'](str(p)) for p in (O/'measured-exl3.so',R/'vllm/_exl3_C.abi3.so')]
assert set(a)==set(b) and all(a[k]==b[k] for k in a)
(O/'rebuild-equivalence.json').write_text(json.dumps({'all_identical':True,'kernels':len(a),'measured_sha256':hashlib.sha256((O/'measured-exl3.so').read_bytes()).hexdigest(),'final_sha256':hashlib.sha256((R/'vllm/_exl3_C.abi3.so').read_bytes()).hexdigest()},indent=2))
for name,gpu in [('rebuilt-sm80','0'),('rebuilt-sm120','3')]:
 env={k:v for k,v in os.environ.items() if not k.startswith(('EXL3_','VLLM_EXL3_'))};env.update(CUDA_VISIBLE_DEVICES=gpu,EXL3_INT8_GEMV='0',OMP_NUM_THREADS='1')
 assert run(name,[str(R/'.venv/bin/python'),'-m','pytest','tests/quantization/test_exl3.py','-q','-k','expert_decode_defaults'],env)==0
print('ALL CHECKS DONE',flush=True)
