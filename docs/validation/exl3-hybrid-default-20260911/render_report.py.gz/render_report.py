import json
from pathlib import Path
O=Path('/tmp/exl3-hybrid-default-20260911');R=Path('/home/bul/dev/vllm-backport')
s=json.loads((O/'summary.json').read_text());p=s['perf'];q=s['quality'];table=['| 输入 token | 输入 native | 输入 hybrid | 输出 native | 输出 hybrid | 输出增益 |','| --- | ---: | ---: | ---: | ---: | ---: |']
for row in p:
 if 'decode_tps' not in row['baseline']:continue
 a,b=row['baseline'],row['hybrid'];n=int(row['case'].split('_')[0][1:])
 table.append(f"| {n} | {a['input_tps']['median']:.2f} | {b['input_tps']['median']:.2f} | {a['decode_tps']['median']:.2f} | {b['decode_tps']['median']:.2f} | {row['gain_percent']['decode_tps']:+.2f}% |")
b4=next(r for r in p if r['case']=='p2048_b4');a,b=[b4[g]['generate_output_tps'] for g in ('baseline','hybrid')]
b4table=f"| 设置 | 中位数 [最小, 最大]，token/s |\n| --- | ---: |\n| native | {a['median']:.2f} [{a['min']:.2f}, {a['max']:.2f}] |\n| hybrid | {b['median']:.2f} [{b['min']:.2f}, {b['max']:.2f}] |\n\n中位数变化 {b4['gain_percent']['generate_output_tps']:+.2f}%。"
drift=[];gains=[]
for r in p:
 if 'decode_tps' not in r['baseline']:continue
 a=r['processes']['native-before']['decode_tps']['median'];b=r['processes']['native-after']['decode_tps']['median'];c=r['hybrid']['decode_tps']['median']
 drift.append(f"{r['case'].split('_')[0][1:]} token：{a:.2f}→{b:.2f}")
 gains += [(c/a-1)*100,(c/b-1)*100]
drifttext='前测→后测的 native B1 decode 中位数为 '+ '；'.join(drift)+f" token/s。hybrid 相对前、后两个独立控制进程均提升，范围为 {min(gains):.2f}%–{max(gains):.2f}%。这仍是本机少量重复测量，不代表其他硬件或并发的保证值。"
quality=f"| 专家策略 | 正确数 | 错题 ID | 输出截断 ID |\n| --- | ---: | --- | --- |\n| native | {q['native_correct']}/64 | {q['native_wrong']} | {q['native_truncated']} |\n| hybrid | {q['hybrid_correct']}/64 | {q['hybrid_wrong']} | {q['hybrid_truncated']} |\n\nhybrid 新增错题 {q['new_wrong']}，修正题 {q['fixed']}。最终抽取答案相同 {q['answers_equal']}/64，完整 token 序列完全相同 {q['tokens_equal']}/64。"
r=s['retrieval'];total=sum(x['total'] for x in r.values());matched=sum(x['matched'] for x in r.values());h=r['hybrid-default']
retrieval=f"8K/64K 固定访问码检索合计 **{matched}/{total}**，其中默认 hybrid 为 **{h['matched']}/{h['total']}**。"
g=[r['gain_percent']['decode_tps'] for r in p if 'decode_tps' in r['baseline']]
conclusion=f"本机固定分层下，默认开启混合专家 decode 带来约 {min(g):.1f}%–{max(g):.1f}% 的 B1 输出吞吐提升，输入吞吐基本不变。结合上述工程检查与有限模型评测，采用 hybrid 作为本次已支持配置的默认策略，并保留 native 回退。Dense 不使用路由专家，本轮变更不影响其路径；本轮未重复测试 AWQ/NVFP4 或原版 ExLlamaV3。"
checks=json.loads((O/'final-checks.json').read_text());assert all(x['exit_code']==0 for x in checks if x['name']!='precommit-first')
assert any(x['name']=='rebuilt-sm120' for x in checks)
lint='完整相关改动通过仓库 pre-commit；Python 3.12 mypy 通过。规范检查修正了一个局部缓存键变量的类型推断，以及 vendored 头文件格式。格式化后重新构建，全部 CUDA 内核计算指令与计时二进制一致；重建组件在 SM80/SM120 上各通过 28 项默认 decode 测试。'
template=(O/'report-template.md').read_text()
for key,value in {'B1_TABLE':'\n'.join(table),'B4_TABLE':b4table,'DRIFT':drifttext,'QUALITY':quality,'RETRIEVAL':retrieval,'LINT':lint,'CONCLUSION':conclusion}.items():
 assert '@@'+key+'@@' in template
 template=template.replace('@@'+key+'@@',value)
assert '@@' not in template
(R/'docs/validation/exl3-hybrid-default-20260911.md').write_text(template)
print('Report written')
