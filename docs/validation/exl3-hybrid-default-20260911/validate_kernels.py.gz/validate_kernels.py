import json,os,subprocess,time
from pathlib import Path
R=Path('/home/bul/dev/vllm-backport');O=Path('/tmp/exl3-hybrid-default-20260911');P=Path('/tmp/exl3-moe-next-20260911')
status=[];py=str(R/'.venv/bin/python')
env=dict(os.environ,OMP_NUM_THREADS='1',CUDA_DEVICE_ORDER='PCI_BUS_ID',EXL3_INT8_GEMV='0',VLLM_EXL3_TEST_DECODE_LIBRARY=str(P/'final-decode/decode.so'),VLLM_EXL3_TEST_PIPELINE_LIBRARY=str(P/'safe-prefill/pipeline.so'),VLLM_EXL3_TEST_ROWS_LIBRARY=str(P/'rows64/rows.so'),VLLM_EXL3_TEST_INT8_LIBRARY='/tmp/exl3-int8-20260911/final-v9/int8.so')
for name,gpu,prefix,selection in [('sm80','0',[],[]),('sm120','3',[],[]),('memcheck-sm120','3',['/usr/local/cuda/bin/compute-sanitizer','--tool','memcheck','--error-exitcode','99','--target-processes','all'],['-k','expert_decode_defaults']),('racecheck-sm120','3',['/usr/local/cuda/bin/compute-sanitizer','--tool','racecheck','--error-exitcode','99','--target-processes','all'],['-k','expert_decode_defaults'])]:
 command=prefix+[py,'-m','pytest','tests/quantization/test_exl3.py','-q']+selection
 record={'name':name,'command':command,'gpu':gpu,'start':time.time()};status.append(record);(O/'kernel-status.json').write_text(json.dumps(status,indent=2));print('START',name,flush=True)
 with (O/f'{name}.log').open('w') as log:r=subprocess.run(command,cwd=R,env=dict(env,CUDA_VISIBLE_DEVICES=gpu),stdout=log,stderr=subprocess.STDOUT)
 record.update(exit_code=r.returncode,end=time.time());(O/'kernel-status.json').write_text(json.dumps(status,indent=2));print('DONE',name,r.returncode,flush=True)
 if r.returncode:raise SystemExit(r.returncode)
