import gzip,hashlib,json,os,subprocess,time
from pathlib import Path
R=Path('/home/bul/dev/vllm-backport')
O=Path('/tmp/exl3-m32-20260911')
inputs=R/'docs/validation/exl3-fixed-pp-20260910/exl3-long-b1-inputs.json.gz'
variants=[{'name':'native_before','capacity':1024,'priority':True}, {'name':'m32_sm80','capacity':1024,'priority':True,'rows_library':str(O/'repro-build/rows.so'),'rows_variant':'m32_predicated'}, {'name':'native_after','capacity':1024,'priority':True}]
(O/'model-variants.json').write_text(json.dumps(variants,indent=2))
cmd=[str(R/'.venv/bin/python'),str(R/'benchmarks/benchmark_exl3.py'),'--backend','vllm','--inputs',str(inputs),'--output',str(O/'model-long.json'),'--pp','4','--expected-layer-counts','11','11','11','12','--chunk-size','1024','--max-model-len','66560','--kv-cache-gib','8','--batch-size','4','--warmups','1','--repeats','3','--tokens','32','--skip-eval','--moe-variants',str(O/'model-variants.json'),'--worker-extension-cls','kernels.exl3_m32.worker.Exl3RowsWorkerExtension']
env=dict(CUDA_DEVICE_ORDER='PCI_BUS_ID',CUDA_VISIBLE_DEVICES='0,1,2,3',NCCL_P2P_DISABLE='1',VLLM_PP_LAYER_PARTITION='11,11,11,12',OMP_NUM_THREADS='1',EXL3_INT8_GEMV='0',VLLM_DETERMINISTIC_MOE_ALIGN='0',VLLM_EXL3_MOE_MAX_TOKENS='1024',VLLM_EXL3_MOE_PRIORITY='1',PYTHONPATH=str(R/'benchmarks'))
meta={'command':cmd,'environment':env,'start':time.time(),'input_sha256':hashlib.sha256(inputs.read_bytes()).hexdigest(),'sources':{str(p.relative_to(R)):hashlib.sha256(p.read_bytes()).hexdigest() for p in [R/'benchmarks/benchmark_exl3.py',*sorted((R/'benchmarks/kernels/exl3_m32').glob('*.py'))]}}
(O/'model-status.json').write_text(json.dumps(meta,indent=2))
with (O/'model-long.log').open('w') as f:
 proc=subprocess.run(cmd,cwd=R,env=dict(os.environ,**env),stdout=f,stderr=subprocess.STDOUT)
meta.update(exit_code=proc.returncode,end=time.time());(O/'model-status.json').write_text(json.dumps(meta,indent=2));print('model-long',proc.returncode,flush=True)
raise SystemExit(proc.returncode)
