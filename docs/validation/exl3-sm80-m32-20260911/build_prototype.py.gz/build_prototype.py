"""Build isolated profiling and row-reuse prototypes from pinned ExLlamaV3 headers."""
import hashlib,json,subprocess
from pathlib import Path

ROOT=Path('/tmp/exl3-m32-20260911')
SRC=Path('/home/bul/dev/exllamav3/exllamav3/exllamav3_ext')
TORCH=Path('/home/bul/dev/vllm-backport/.venv/lib/python3.12/site-packages/torch')

# Preserve original code and license; the generated headers use absolute includes
# only inside this isolated build directory.
(ROOT/'LICENSE-exllamav3.txt').write_bytes((SRC.parent.parent/'LICENSE').read_bytes())
def includes(s,base):
 import re
 return re.sub(r'#include "([^"]+)"',lambda m:'#include "'+str((base/m.group(1)).resolve())+'"',s)

moe=includes((SRC/'quant/exl3_moe_kernel.cuh').read_text(),SRC/'quant')
profile=moe.replace('template<int t_bits, int MOE_TILESIZE_N, int cb>','template<int t_bits, int MOE_TILESIZE_N, int cb>')
profile=profile.replace('void exl3_moe_kernel(EXL3_MOE_KERNEL_ARGS)','void exl3_moe_profile_kernel(EXL3_MOE_KERNEL_ARGS, unsigned long long* profile)')
profile=profile.replace('    // Buffers for group', '''    unsigned long long stamp = clock64();
    const int profile_base = (blockIdx.z * gridDim.x + blockIdx.x) * 16;
    auto mark = [&](int category) {
        if (threadIdx.x == 0) {
            unsigned long long now = clock64();
            profile[profile_base + category] += now - stamp;
            stamp = clock64();
        }
    };

    // Buffers for group''',1)
# Split existing barriers out of transformation timing, keeping all barriers.
profile=profile.replace('        had_gather_gu_in();','        mark(0);\n        had_gather_gu_in();\n        mark(1);',1)
profile=profile.replace('''        if (gated)
            gemm_up(temp_state_g, temp_intermediate_g, exp_gate_trellis, K_gate);
        gemm_up(temp_state_u, temp_intermediate_u, exp_up_trellis, K_up);
        group_barrier(group_idx, group_size, barrier_counters_sense);''','''        mark(0);
        if (gated)
            gemm_up(temp_state_g, temp_intermediate_g, exp_gate_trellis, K_gate);
        mark(2);
        gemm_up(temp_state_u, temp_intermediate_u, exp_up_trellis, K_up);
        mark(3);
        group_barrier(group_idx, group_size, barrier_counters_sense);
        mark(4);''',1)
profile=profile.replace('        had_guad();','        mark(0);\n        had_guad();\n        mark(5);',1)
profile=profile.replace('''        gemm_down(temp_intermediate_g, temp_state_g, exp_down_trellis, K_down);
        group_barrier(group_idx, group_size, barrier_counters_sense);''','''        mark(0);
        gemm_down(temp_intermediate_g, temp_state_g, exp_down_trellis, K_down);
        mark(6);
        group_barrier(group_idx, group_size, barrier_counters_sense);
        mark(7);''',1)
profile=profile.replace('        had_d_out();','        mark(0);\n        had_d_out();\n        mark(8);',1)
profile=profile.replace('        ticket = sched[2 + group_idx];','        ticket = sched[2 + group_idx];\n        mark(9);',1)
profile=profile.rsplit('\n}',1)[0]+'\n    mark(0);\n}\n'
(ROOT/'moe_profile.cuh').write_text(profile)
(ROOT/'moe_profile.cu').write_text('#include "moe_profile.cuh"\nextern "C" void* exl3_profile_factory() { return (void*) exl3_moe_profile_kernel<4,256,2>; }\n')
cmd=['/usr/local/cuda-13.0/bin/nvcc','--shared','--cudart','shared','-Xcompiler','-fPIC','-O3','-std=c++20','--use_fast_math','--expt-relaxed-constexpr','--expt-extended-lambda','-lineinfo','-Xptxas=-v','-gencode=arch=compute_80,code=sm_80','-I'+str(TORCH/'include'),'-I'+str(TORCH/'include/torch/csrc/api/include'),str(ROOT/'moe_profile.cu'),'-o',str(ROOT/'moe_profile.so')]
(ROOT/'profile-build-command.json').write_text(json.dumps(cmd,indent=2))
with (ROOT/'profile-build.log').open('w') as log:
 subprocess.run(cmd,stdout=log,stderr=subprocess.STDOUT,check=True)
print('built profiling kernel',flush=True)
