"""Benchmark-only launcher for the ExLlamaV3 1.4.8 kernel ABI at 6ff3a17.

This deliberately stays outside production: it uses private exported factories.
The shared-memory calculation is from exl3_gemm_inner.cuh with shmem_out_had=False.
"""
import ctypes as ct
import importlib.metadata
from pathlib import Path
import torch

class Dim3(ct.Structure):
    _fields_ = [('x', ct.c_uint), ('y', ct.c_uint), ('z', ct.c_uint)]

class Launcher:
    def __init__(self, extension, tile_n=256, shared='fixed', tile_k=32, library=None, width=8):
        assert importlib.metadata.version('exllamav3') == '1.4.8'
        self.extension = extension
        self.original = extension.exl3_moe
        self.tile_n, self.shared, self.tile_k, self.width = tile_n, shared, tile_k, width
        self.native = ct.CDLL(extension.__file__)
        self.kernels = ct.CDLL(library) if library else self.native
        paths = {line.split()[-1] for line in Path('/proc/self/maps').read_text().splitlines() if 'libcudart.so' in line}
        assert len(paths) == 1, paths
        self.cuda = ct.CDLL(paths.pop())
        self.cuda.cudaLaunchKernel.argtypes = [ct.c_void_p, Dim3, Dim3, ct.POINTER(ct.c_void_p), ct.c_size_t, ct.c_void_p]
        self.cuda.cudaLaunchKernel.restype = ct.c_int
        self.cuda.cudaFuncSetAttribute.argtypes = [ct.c_void_p, ct.c_int, ct.c_int]
        self.cuda.cudaFuncSetAttribute.restype = ct.c_int
        self.cuda.cudaOccupancyMaxActiveBlocksPerMultiprocessor.argtypes = [ct.POINTER(ct.c_int), ct.c_void_p, ct.c_int, ct.c_size_t]
        self.cuda.cudaOccupancyMaxActiveBlocksPerMultiprocessor.restype = ct.c_int
        self.cuda.cudaGetErrorString.argtypes = [ct.c_int]
        self.cuda.cudaGetErrorString.restype = ct.c_char_p
        instance = getattr(self.native, '_ZN6DevCtx8instanceEv')
        instance.argtypes, instance.restype = [], ct.c_void_p
        self.context = instance()
        self.get_locks = getattr(self.native, '_ZN6DevCtx9get_locksEi')
        self.get_locks.argtypes, self.get_locks.restype = [ct.c_void_p, ct.c_int], ct.c_void_p
        self.plans = {}

    def check(self, status):
        if status:
            raise RuntimeError(self.cuda.cudaGetErrorString(status).decode())

    def plan(self, device, bits, flags):
        common = bits[0] if len(set(bits)) == 1 else 0
        assert len(set(zip(flags[::2], flags[1::2]))) == 1
        assert bool(flags[0]) != bool(flags[1])
        cb = 2 if flags[1] else 1
        key = (device, common, cb, tuple(bits))
        if key not in self.plans:
            if self.tile_k == 32:
                name = f'_Z27exl3_moe_kernel_k{common}_n{self.tile_n}_cb{cb}v'
            else:
                name = f'exl3_moe_k{common}_n{self.tile_n}_k{self.tile_k}_cb{cb}'
            factory = getattr(self.kernels, name)
            factory.argtypes, factory.restype = [], ct.c_void_p
            kernel = factory()
            needed = 3 * (2*16*self.tile_k + 2*(self.tile_k//16)*(self.tile_n//16)*16*max(bits)) + 4*(4*256*(2*(self.tile_n//16)//8))
            shared = 90*1024 if self.shared == 'fixed' else needed
            threads = 256*self.tile_k//16
            self.check(self.cuda.cudaFuncSetAttribute(kernel, 8, 90*1024))
            active = ct.c_int()
            self.check(self.cuda.cudaOccupancyMaxActiveBlocksPerMultiprocessor(ct.byref(active), kernel, threads, shared))
            sms = torch.cuda.get_device_properties(device).multi_processor_count
            self.plans[key] = {'kernel':kernel,'threads':threads,'shared_bytes':shared,'required_shared_bytes':needed,'active_blocks_per_sm':active.value,'sms':sms,'max_groups':min(64,sms*active.value//self.width),'locks':self.get_locks(self.context,device)}
        return self.plans[key]

    def __call__(self, *args):
        assert len(args)==30, len(args)
        hidden, output, counts, tokens, routing = args[:5]
        workspace, activation, bits, ptrs, flags = args[5:9],args[9],args[10:13],args[13:22],args[22:28]
        limit, hint = args[28:30]
        assert hidden.is_contiguous() and hidden.dtype==torch.float16
        assert output.dtype==torch.float32 and output.shape==hidden.shape
        device = hidden.device.index
        plan = self.plan(device,bits,flags)
        groups = min(workspace[0].shape[0],64)
        width = self.width
        if hint > 0:
            groups = min(groups,hint)
            width = min(plan['sms']//groups,32)
        assert groups*width <= plan['sms']*plan['active_blocks_per_sm'], plan
        assert hidden.shape[1] % self.tile_n == 0 and workspace[2].shape[-1] % self.tile_n == 0
        tensors = [hidden,*workspace,output,*ptrs,counts,tokens,routing]
        assert all(t.device==hidden.device for t in tensors)
        values = [ct.c_void_p(t.data_ptr()) for t in tensors]
        values += [ct.c_int(v) for v in [hidden.shape[1],workspace[2].shape[-1],counts.numel()-1,tokens.numel()//hidden.shape[0],workspace[0].shape[1],groups]]
        values += [ct.c_float(limit),ct.c_int(activation),*(ct.c_int(v) for v in bits),ct.c_void_p(plan['locks'])]
        pointers = (ct.c_void_p * len(values))(*(ct.addressof(v) for v in values))
        self.check(self.cuda.cudaLaunchKernel(plan['kernel'],Dim3(width,1,groups),Dim3(plan['threads'],1,1),pointers,plan['shared_bytes'],torch.cuda.current_stream(device).cuda_stream))
