import ctypes as ct
import sys
from pathlib import Path
import torch
sys.path.insert(0,'/tmp/exl3-opt-20260910')
from exl3_tile_launch import Launcher as Base, Dim3

class Launcher(Base):
    def __init__(self, extension, factory, library, profile=None, shared_bytes=90*1024):
        super().__init__(extension, library=str(library))
        self.factory_name = factory
        self.profile = profile
        self.shared_bytes = shared_bytes
        self.threads = 256 if "_k16_" in factory else 512
    def plan(self, device, bits, flags):
        assert tuple(bits)==(4,4,4), bits
        assert tuple(map(bool,flags))==(False,True,False,True,False,True),flags
        if device not in self.plans:
            factory=getattr(self.kernels,self.factory_name)
            factory.argtypes,factory.restype=[],ct.c_void_p
            kernel=factory()
            self.check(self.cuda.cudaFuncSetAttribute(kernel,8,90*1024))
            active=ct.c_int()
            self.check(self.cuda.cudaOccupancyMaxActiveBlocksPerMultiprocessor(ct.byref(active),kernel,self.threads,self.shared_bytes))
            sms=torch.cuda.get_device_properties(device).multi_processor_count
            self.plans[device]={'kernel':kernel,'threads':self.threads,'shared_bytes':self.shared_bytes,'active_blocks_per_sm':active.value,'sms':sms,'locks':self.get_locks(self.context,device)}
        return self.plans[device]
    def __call__(self,*args):
        assert len(args)==30
        hidden,output,counts,tokens,routing=args[:5]
        workspace,activation,bits,ptrs,flags=args[5:9],args[9],args[10:13],args[13:22],args[22:28]
        limit,hint=args[28:30]
        device=hidden.device.index
        plan=self.plan(device,bits,flags)
        groups=min(workspace[0].shape[0],64)
        width=8
        if hint>0:
            groups=min(groups,hint);width=min(plan['sms']//groups,32)
        assert groups*width<=plan['sms']*plan['active_blocks_per_sm'],plan
        tensors=[hidden,*workspace,output,*ptrs,counts,tokens,routing]
        values=[ct.c_void_p(t.data_ptr()) for t in tensors]
        values += [ct.c_int(v) for v in [hidden.shape[1],workspace[2].shape[-1],counts.numel()-1,tokens.numel()//hidden.shape[0],workspace[0].shape[1],groups]]
        values += [ct.c_float(limit),ct.c_int(activation),*(ct.c_int(v) for v in bits),ct.c_void_p(plan['locks'])]
        if self.profile is not None:
            assert self.profile.numel()>=groups*width*16
            values += [ct.c_void_p(self.profile.data_ptr())]
        pointers=(ct.c_void_p*len(values))(*(ct.addressof(v) for v in values))
        self.check(self.cuda.cudaLaunchKernel(plan['kernel'],Dim3(width,1,groups),Dim3(self.threads,1,1),pointers,plan['shared_bytes'],torch.cuda.current_stream(device).cuda_stream))
