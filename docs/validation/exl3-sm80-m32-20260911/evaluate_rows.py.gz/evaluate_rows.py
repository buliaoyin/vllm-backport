import gzip,hashlib,json,os,sys,time
from pathlib import Path
from types import SimpleNamespace
R=Path('/home/bul/dev/vllm-backport');O=Path('/tmp/exl3-m32-20260911')
sys.path.insert(0,str(R/'benchmarks'))
from benchmark_exl3 import VllmBackend,answer_value

def main():
 source=Path('/tmp/exl3-opt-20260910/moe-long-eval64.json.gz')
 data=json.loads(gzip.decompress(source.read_bytes()))
 long=json.loads(gzip.decompress((R/'docs/validation/exl3-fixed-pp-20260910/exl3-long-b1-inputs.json.gz').read_bytes()))
 args=SimpleNamespace(profile_dir=None,event_profile=True,moe_workspace_sizes=None,moe_variants=None,capture_routing_dir=None,expected_layer_counts=[11,11,11,12],worker_extension_cls='kernels.exl3_m32.worker.Exl3RowsWorkerExtension',max_model_len=66560,batch_size=4,pp=4,chunk_size=1024,eager=False,kv_cache_gib=8)
 result={'args':vars(args),'eval_input_sha256':hashlib.sha256(source.read_bytes()).hexdigest(),'variants':[],'start':time.time()}
 backend=VllmBackend(args,data)
 result['runtime']=backend.llm.collective_rpc('get_exl3_runtime_state')
 assert [sorted(v['index'] for v in r['decoder_layers']) for r in sorted(result['runtime'],key=lambda r:r['pp_rank'])]==[list(range(0,11)),list(range(11,22)),list(range(22,33)),list(range(33,45))]
 variants=[{'name':'native','capacity':1024,'priority':True},{'name':'m32_sm80','capacity':1024,'priority':True,'rows_library':str(O/'final-build/rows.so'),'rows_variant':'m32_predicated'}]
 for variant in variants:
  record={'variant':variant,'state':backend.llm.collective_rpc('configure_exl3_optimization',args=(variant,)),'eval':[]}
  result['variants'].append(record)
  for offset in range(0,64,4):
   batch=data['evals'][offset:offset+4];elapsed,rows=backend.generate([r['input_ids'] for r in batch],768,False)
   for request,row in zip(batch,rows):
    predicted=answer_value(row['text']);row.update(id=request['id'],predicted=predicted,expected=request['answer'],correct=predicted is not None and float(predicted)==float(request['answer']))
    record['eval'].append(row)
   (O/'eval.json').write_text(json.dumps(result,indent=2));print('EVAL',variant['name'],len(record['eval']),sum(r['correct'] for r in record['eval']),flush=True)
  backend.generate(long['cases'][0]['inputs'],16,True)
  record['profile_install']=backend.llm.collective_rpc('install_exl3_event_profile')
  try:
   elapsed,rows=backend.generate(long['cases'][0]['inputs'],1,True)
   record['profile']={'seconds':elapsed,'rows':rows}
  finally:record['profile']['ranks']=backend.llm.collective_rpc('collect_exl3_event_profile')
  (O/'eval.json').write_text(json.dumps(result,indent=2))
 result['end']=time.time();(O/'eval.json').write_text(json.dumps(result,indent=2))
if __name__=='__main__':main()
