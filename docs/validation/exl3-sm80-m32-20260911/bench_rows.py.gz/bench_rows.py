import json,os,statistics,sys,time
from pathlib import Path
import torch
sys.path.insert(0,'/home/bul/dev/vllm-backport/benchmarks/kernels')
import benchmark_exl3_moe as bench
from rows_launch import Launcher
ROOT=Path('/tmp/exl3-m32-20260911')

def graph_times(fn):
    graph=torch.cuda.CUDAGraph()
    with torch.cuda.graph(graph):
        captured=fn()
    for _ in range(3):graph.replay()
    flush=torch.empty(256*1024*1024,device='cuda',dtype=torch.uint8)
    torch.cuda.synchronize()
    pairs=[]
    for _ in range(15):
        flush.zero_()
        start=torch.cuda.Event(enable_timing=True);end=torch.cuda.Event(enable_timing=True)
        start.record();graph.replay();end.record();pairs.append((start,end))
    torch.cuda.synchronize()
    return [start.elapsed_time(end) for start,end in pairs]

@torch.inference_mode()
def run(layer,method,args,k,n):
    sample=torch.load(args.route_sample,weights_only=True,map_location='cuda')
    ext=bench._extension();native=ext.exl3_moe
    variants=os.environ.get('ROW_VARIANTS','native,'+','.join(f'n{n}_s{s}_force{f}' for n in (128,256) for s in (2,3) for f in (0,1))+',native_after,profile').split(',')
    result={'gpu':torch.cuda.get_device_name(),'torch':str(torch.__version__),'prefix':args.prefix,'routing':str(args.route_sample),'bits':method.bits,'flags':method.flags,'scope':'full expert wrapper GPU work; CUDA graph events; one call/sample; explicit 256 MiB L2 flush outside timed interval','records':[]}
    for rows in args.prefill_rows:
        chunk=int(os.environ.get('ROW_CHUNK','1024'))
        x,weights,ids=(sample[name][:rows].contiguous() for name in ('x','weights','ids'))
        workspace=[t.new_empty((t.shape[0],chunk,t.shape[2])) for t in method.workspace]
        inputs=(x,weights,ids,method.ptrs,workspace,method.bits,method.flags,10.)
        def fn():return bench.fused_with_chunk(inputs,chunk,longest_first=True)
        ext.exl3_moe=native
        ref=fn();torch.cuda.synchronize()
        for name in variants:
            if name.startswith('native'):
                launch=None;ext.exl3_moe=native
            elif name=='profile':
                profile=torch.zeros((64*32,16),device='cuda',dtype=torch.int64)
                launch=Launcher(ext,'exl3_profile_factory',ROOT/'moe_profile.so',profile=profile)
                ext.exl3_moe=launch
            else:
                launch=Launcher(ext,'exl3_rows_'+name,ROOT/('moe_rows_v2.so' if name.startswith('v2_') else 'moe_rows.so'))
                ext.exl3_moe=launch
            y=fn();torch.cuda.synchronize()
            delta=y.float()-ref.float()
            rec={'variant':name,'rows':rows,'chunk':chunk,'relative_l2':float(delta.norm()/ref.float().norm()),'max_abs':float(delta.abs().max()),'finite':bool(torch.isfinite(y).all())}
            if rec['finite'] and rec['relative_l2']<0.01:
                for _ in range(3):fn()
                torch.cuda.synchronize()
                times=graph_times(fn)
                rec['times_ms']=list(map(float,times));rec['median_ms']=statistics.median(rec['times_ms'])
                if name=='profile':
                    categories=['other','gather_input_had_and_barrier','gate_gemm','up_gemm','gate_up_barrier','middle_had_activation_and_barrier','down_gemm','down_barrier','output_had_scatter','scheduler_and_barrier']
                    rec['profiles']=[]
                    for _ in range(3):
                        profile.zero_();fn();torch.cuda.synchronize()
                        p=profile.cpu();totals=p[:,:10].sum(0).tolist();total=sum(totals)
                        rec['profiles'].append({'cycles_by_category':dict(zip(categories,totals)),'fraction_by_category':dict(zip(categories,[v/total for v in totals])),'blocks':p[p.sum(1)>0].tolist()})
            else:rec['rejected']='correctness'
            if launch:rec['launch']={key:value for key,value in launch.plans[x.device.index].items() if key not in ('kernel','locks')}
            result['records'].append(rec)
            args.output.write_text(json.dumps(result,indent=2))
            print({key:value for key,value in rec.items() if key not in ('times_ms','profiles')},flush=True)
            ext.exl3_moe=native
    ext.exl3_moe=native
bench.prefill_ablation=run
if __name__=='__main__':bench.main()
