import gzip,hashlib,json,statistics
from pathlib import Path
R=Path('/home/bul/dev/vllm-backport');O=Path('/tmp/exl3-m32-20260911')
D=R/'docs/validation/exl3-sm80-m32-20260911'

def summarize(data,label,variant=None):
 result=[]
 for n in (8192,16384,32768,65536):
  records=[r for r in data['perf'] if r['rows'][0]['prompt_tokens']==n and (variant is None or r['variant'].get('name')==variant)]
  assert len(records)==3,(label,n,len(records))
  rows=[r['rows'][0] for r in records]
  assert all(r['new_tokens']==32 and r['cached_tokens']==0 for r in rows)
  assert all(c['matched'] for r in records for c in r['checks'])
  result.append({'label':label,'tokens':n,'ttft_s':statistics.median(r['ttft'] for r in rows),'ttft_samples_s':[r['ttft'] for r in rows],'prefill_tokens_per_s':statistics.median(n/r['prefill'] for r in rows),'decode_tokens_per_s':statistics.median(31/r['decode'] for r in rows)})
 return result

def main():
 data=json.loads((O/'model-long.json').read_text());assert len(data['perf'])==36
 expected=[list(range(0,11)),list(range(11,22)),list(range(22,33)),list(range(33,45))]
 assert [sorted(l['index'] for l in r['decoder_layers']) for r in sorted(data['runtime_before'],key=lambda r:r['pp_rank'])]==expected
 for i,states in enumerate(data['workspace_sweep']):
  assert len(states)==4
  if i==1:
   assert all(s['row_kernel']['variant']=='m32_predicated' for s in states[:3]);assert states[3]['row_kernel']=='native'
  else:assert all(s['row_kernel']=='native' for s in states)
 source=R/'docs/validation/exl3-fixed-pp-20260910';inputs=json.loads(gzip.decompress((source/'exl3-long-b1-inputs.json.gz').read_bytes()))
 result={'pp_layers':[11,11,11,12],'whole_model_checks':36,'rows':[],'comparator_scope':'NVFP4/AWQ are the previously measured fixed-partition runs, not rerun in this experiment.'}
 for label in ('native_before','m32_sm80','native_after'):result['rows']+=summarize(data,label,label)
 for fmt in ('nvfp4','awq'):
  previous=json.loads((source/f'{fmt}-long-pp11-11-11-12-c1024.json').read_text())
  assert previous['gpu_names']==data['gpu_names']
  for key in ('pp','chunk_size','max_model_len','kv_cache_gib','batch_size','warmups','repeats','tokens'):
   assert previous['args'][key]==data['args'][key],key
  assert [sorted(l['index'] for l in r['decoder_layers']) for r in sorted(previous['runtime_before'],key=lambda r:r['pp_rank'])]==expected
  other=json.loads(gzip.decompress((source/f'{fmt}-long-b1-inputs.json.gz').read_bytes()))
  assert other['cases']==inputs['cases']
  result['rows']+=summarize(previous,fmt)
 for row in result['rows']:print(row['label'],row['tokens'],round(row['ttft_s'],4),round(row['prefill_tokens_per_s'],1),flush=True)
 (O/'summary.json').write_text(json.dumps(result,indent=2))
 (D/'summary.json').write_text(json.dumps(result,indent=2))
if __name__=='__main__':main()
