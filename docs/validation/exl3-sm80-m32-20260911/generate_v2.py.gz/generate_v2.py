import json,re,subprocess
from pathlib import Path
R=Path('/tmp/exl3-m32-20260911')
T=Path('/home/bul/dev/vllm-backport/.venv/lib/python3.12/site-packages/torch')
def span(s,name):
 a=s.index('{',s.index('auto '+name+' ='));b=a+1;level=1
 while level:
  level+=(s[b]=='{')-(s[b]=='}');b+=1
 return a,b
s=(R/'gemm_rows.cuh').read_text().replace('exl3_gemm_rows_inner','exl3_gemm_rows_v2_inner')
s=s.replace('template<EXL3_GEMM_T_ARGS, bool shmem_out_had>','template<EXL3_GEMM_T_ARGS, bool shmem_out_had, bool PREDICATE_ROWS>')
for name in ('load_frags','matmul','threadblock_reduce'):
 a,b=span(s,name);body=s[a:b]
 body=re.sub(r'(for \(int m = 0; m < TILEBLOCKS_M; \+\+m\)\s*\{)',r'\1\n            if constexpr (PREDICATE_ROWS) { if (m * 16 >= size_m) continue; }',body)
 s=s[:a]+body+s[b:]
(R/'gemm_rows_v2.cuh').write_text(s)
s=(R/'moe_rows.cuh').read_text().replace('"gemm_rows.cuh"','"gemm_rows_v2.cuh"')
s=s.replace('template<int t_bits, int MOE_TILESIZE_N, int cb, int ROW_FRAG_STAGES, bool FORCE_M32>','template<int t_bits, int MOE_TILESIZE_N, int cb, int ROW_FRAG_STAGES, int ROW_TILE_M, int ROW_TILE_K, bool PREDICATE_ROWS>')
s=s.replace('exl3_moe_rows_kernel','exl3_moe_rows_v2_kernel').replace('MOE_TILESIZE_K','ROW_TILE_K')
for name,din,dout in [('gemm_up','hidden_dim','intermediate_dim'),('gemm_down','intermediate_dim','hidden_dim')]:
 a,b=span(s,name)
 body='''{
            static_assert(t_bits == 4 && cb == 2);
            for (int offset = 0; offset < token_count; offset += ROW_TILE_M)
            {
                int rows = MIN(token_count - offset, ROW_TILE_M);
                if constexpr (ROW_TILE_M == 16)
                    exl3_gemm_kernel_inner<t_bits,false,cb,16,ROW_TILE_K,MOE_TILESIZE_N,MOE_SH_STAGES,ROW_FRAG_STAGES,false>
                        (in_addr + offset * DIM_IN,trellis,out_addr + offset * DIM_OUT,rows,DIM_IN,DIM_OUT,locks,nullptr);
                else
                    exl3_gemm_rows_v2_inner<t_bits,false,cb,32,ROW_TILE_K,MOE_TILESIZE_N,MOE_SH_STAGES,ROW_FRAG_STAGES,false,PREDICATE_ROWS>
                        (in_addr + offset * DIM_IN,trellis,out_addr + offset * DIM_OUT,rows,DIM_IN,DIM_OUT,locks,nullptr);
            }
        }'''.replace('DIM_IN',din).replace('DIM_OUT',dout)
 s=s[:a]+body+s[b:]
(R/'moe_rows_v2.cuh').write_text(s)
variants=[(16,32,256,2,False),(16,32,256,3,False),(32,32,256,2,False),(32,32,256,2,True),(32,16,256,2,False),(32,16,256,3,False),(32,16,256,2,True),(32,16,256,3,True)]
cu='#include "moe_rows_v2.cuh"\n'
for m,k,n,stages,p in variants:
 name=f'v2_m{m}_k{k}_n{n}_s{stages}_p{int(p)}'
 cu+=f'extern "C" void* exl3_rows_{name}() {{ return (void*) exl3_moe_rows_v2_kernel<4,{n},2,{stages},{m},{k},{str(p).lower()}>; }}\n'
(R/'moe_rows_v2.cu').write_text(cu)
cmd=['/usr/local/cuda-13.0/bin/nvcc','--shared','--cudart','shared','-Xcompiler','-fPIC','-O3','-std=c++20','--use_fast_math','--expt-relaxed-constexpr','--expt-extended-lambda','-lineinfo','-Xptxas=-v','-gencode=arch=compute_80,code=sm_80','-I'+str(T/'include'),'-I'+str(T/'include/torch/csrc/api/include'),str(R/'moe_rows_v2.cu'),'-o',str(R/'moe_rows_v2.so')]
(R/'v2-build-command.json').write_text(json.dumps(cmd,indent=2))
with (R/'v2-build.log').open('w') as log:subprocess.run(cmd,stdout=log,stderr=subprocess.STDOUT,check=True)
print('built v2 kernels',flush=True)
