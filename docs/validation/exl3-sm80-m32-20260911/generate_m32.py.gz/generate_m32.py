"""Generate a row-reuse GEMM prototype without modifying upstream sources."""
import hashlib,json,re,subprocess
from pathlib import Path
R=Path('/tmp/exl3-m32-20260911')
S=Path('/home/bul/dev/exllamav3/exllamav3/exllamav3_ext')
T=Path('/home/bul/dev/vllm-backport/.venv/lib/python3.12/site-packages/torch')
def includes(s):
 return re.sub(r'#include "([^"]+)"',lambda m:'#include "'+str((S/'quant'/m.group(1)).resolve())+'"',s)
def lambda_span(s,name):
 start=s.index('auto '+name+' =')
 a=s.index('{',start);level=1;b=a+1
 while level:
  if s[b]=='{':level+=1
  elif s[b]=='}':level-=1
  b+=1
 return a,b

gemm=includes((S/'quant/exl3_gemm_inner.cuh').read_text())
gemm=gemm.replace('void exl3_gemm_kernel_inner','void exl3_gemm_rows_inner',1)
gemm=gemm.replace('static_assert(TILESIZE_M == 16, "Invalid kernel params");','static_assert(TILESIZE_M == 32, "Row-reuse prototype requires M=32");')
gemm=gemm.replace('4 * EXL3_GEMM_BASE_THREADS * FRAGS_N_PER_WARP,','4 * EXL3_GEMM_BASE_THREADS * FRAGS_N_PER_WARP * TILEBLOCKS_M,')
gemm=gemm.replace('FragA frag_a[FRAG_STAGES];','FragA frag_a[FRAG_STAGES][TILEBLOCKS_M];')
gemm=gemm.replace('FragC frag_c[FRAGS_N_PER_WARP];','FragC frag_c[TILEBLOCKS_M][FRAGS_N_PER_WARP];')
gemm=gemm.replace('FragC_h frag_c_h[FRAGS_N_PER_WARP];','FragC_h frag_c_h[TILEBLOCKS_M][FRAGS_N_PER_WARP];')
gemm=gemm.replace('frag_a[buf]', 'frag_a[buf][m]')
gemm=gemm.replace('frag_c[n]', 'frag_c[m][n]').replace('frag_c_h[n]', 'frag_c_h[m][n]')
# The decoded B fragment is outside the M loop and consumed by both row fragments.
for name in ('clear_frag_c','write_sum_tile_sh','read_sum_gl','write_sum_gl','matmul'):
 a,b=lambda_span(gemm,name)
 body=gemm[a+1:b-1]
 if name in ('write_sum_tile_sh','read_sum_gl','write_sum_gl'):
  body=body.replace('r0 = lane_id / 4;', 'r0 = lane_id / 4 + m * 16;')
 gemm=gemm[:a]+'''{
        #pragma unroll
        for (int m = 0; m < TILEBLOCKS_M; ++m)
        {'''+body+'\n        }\n    }'+gemm[b:]
a,b=lambda_span(gemm,'threadblock_reduce')
gemm=gemm[:a]+'''{
        static_assert(TILEBLOCKS_K == 1 || TILEBLOCKS_K == 2);
        if constexpr (TILEBLOCKS_K == 2)
        {
            if (sub_k == 1)
            {
                #pragma unroll
                for (int m = 0; m < TILEBLOCKS_M; ++m)
                {
                    float* sh_red = sh_c + (m * EXL3_GEMM_BASE_THREADS + t) * FRAGS_N_PER_WARP * 4;
                    #pragma unroll
                    for (int n = 0; n < FRAGS_N_PER_WARP; ++n)
                        #pragma unroll
                        for (int j = 0; j < 4; ++j) *sh_red++ = frag_c[m][n][j];
                }
            }
            __syncthreads();
            if (sub_k == 0)
            {
                #pragma unroll
                for (int m = 0; m < TILEBLOCKS_M; ++m)
                {
                    float* sh_red = sh_c + (m * EXL3_GEMM_BASE_THREADS + t) * FRAGS_N_PER_WARP * 4;
                    #pragma unroll
                    for (int n = 0; n < FRAGS_N_PER_WARP; ++n)
                        #pragma unroll
                        for (int j = 0; j < 4; ++j) frag_c[m][n][j] += *sh_red++;
                }
            }
        }
    }'''+gemm[b:]
# The fp16 accumulation branch is not enabled on SM80, but keep it well-formed.
a,b=lambda_span(gemm,'reduce')
body=gemm[a:b]
start=body.index('        #if EXL3_GEMM_H_ACC');stop=body.index('        #endif',start)
part=body[start:stop]
part=part.replace('            #pragma unroll','            #pragma unroll\n            for (int m = 0; m < TILEBLOCKS_M; ++m)\n            #pragma unroll',1)
body=body[:start]+part+body[stop:]
gemm=gemm[:a]+body+gemm[b:]
# Include upstream's license next to this derivative snapshot.
(R/'gemm_rows.cuh').write_text(gemm)

moe=includes((S/'quant/exl3_moe_kernel.cuh').read_text())
moe=moe.replace('template<int t_bits, int MOE_TILESIZE_N, int cb>', 'template<int t_bits, int MOE_TILESIZE_N, int cb, int ROW_FRAG_STAGES, bool FORCE_M32>')
moe=moe.replace('void exl3_moe_kernel', 'void exl3_moe_rows_kernel',1)
moe=moe.replace('#include "'+str(S/'quant/exl3_gemm_inner.cuh')+'"', '#include "'+str(S/'quant/exl3_gemm_inner.cuh')+'"\n#include "gemm_rows.cuh"',1)
for name,dim_in,dim_out in [('gemm_up','hidden_dim','intermediate_dim'),('gemm_down','intermediate_dim','hidden_dim')]:
 a,b=lambda_span(moe,name)
 body='''{
            static_assert(t_bits == 4 && cb == 2);
            int size_m = token_count;
            while (size_m > 0)
            {
                int rows;
                if (size_m > 16 || FORCE_M32)
                {
                    rows = MIN(size_m, 32);
                    exl3_gemm_rows_inner<t_bits, false, cb, 32, MOE_TILESIZE_K, MOE_TILESIZE_N, MOE_SH_STAGES, ROW_FRAG_STAGES, false>
                        (in_addr, trellis, out_addr, rows, DIM_IN, DIM_OUT, locks, nullptr);
                }
                else
                {
                    rows = MIN(size_m, 16);
                    exl3_gemm_kernel_inner<t_bits, false, cb, 16, MOE_TILESIZE_K, 256, MOE_SH_STAGES, MOE_FRAG_STAGES, false>
                        (in_addr, trellis, out_addr, rows, DIM_IN, DIM_OUT, locks, nullptr);
                }
                in_addr += rows * DIM_IN;
                out_addr += rows * DIM_OUT;
                size_m -= rows;
            }
        }'''.replace('DIM_IN',dim_in).replace('DIM_OUT',dim_out)
 moe=moe[:a]+body+moe[b:]
(R/'moe_rows.cuh').write_text(moe)
cu='#include "moe_rows.cuh"\n'
for n in (128,256):
 for stages in (2,3):
  for force in (False,True):
   name=f'exl3_rows_n{n}_s{stages}_force{int(force)}'
   cu+=f'extern "C" void* {name}() {{ return (void*) exl3_moe_rows_kernel<4,{n},2,{stages},{str(force).lower()}>; }}\n'
(R/'moe_rows.cu').write_text(cu)
cmd=['/usr/local/cuda-13.0/bin/nvcc','--shared','--cudart','shared','-Xcompiler','-fPIC','-O3','-std=c++20','--use_fast_math','--expt-relaxed-constexpr','--expt-extended-lambda','-lineinfo','-Xptxas=-v','-gencode=arch=compute_80,code=sm_80','-I'+str(T/'include'),'-I'+str(T/'include/torch/csrc/api/include'),str(R/'moe_rows.cu'),'-o',str(R/'moe_rows.so')]
(R/'rows-build-command.json').write_text(json.dumps(cmd,indent=2))
with (R/'rows-build.log').open('w') as log:
 subprocess.run(cmd,stdout=log,stderr=subprocess.STDOUT,check=True)
print('built M=32 row-reuse kernels',flush=True)
