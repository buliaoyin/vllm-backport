import json
import sys
from pathlib import Path
import torch
sys.path.insert(0, '/home/bul/dev/vllm-backport/benchmarks/kernels')
import benchmark_exl3_moe as bench

@torch.inference_mode()
def profile(layer, method, args, k, n):
    sample=torch.load(args.route_sample,weights_only=True,map_location='cuda')
    rows=1024
    x,weights,ids=(sample[name][:rows].contiguous() for name in ('x','weights','ids'))
    workspace=[t.new_empty((t.shape[0],rows,t.shape[2])) for t in method.workspace]
    inputs=(x,weights,ids,method.ptrs,workspace,method.bits,method.flags,10.0)
    for _ in range(3):bench.fused_with_chunk(inputs,1024,longest_first=True)
    torch.cuda.synchronize()
    torch.cuda.cudart().cudaProfilerStart()
    y=bench.fused_with_chunk(inputs,1024,longest_first=True)
    torch.cuda.synchronize()
    torch.cuda.cudart().cudaProfilerStop()
    args.output.write_text(json.dumps({'finite':bool(torch.isfinite(y).all()),'shape':list(y.shape),'bits':method.bits,'flags':method.flags}))
bench.prefill_ablation=profile
if __name__=='__main__':bench.main()
