from pathlib import Path
p=Path('benchmarks/kernels/benchmark_exl3_moe.py')
s=p.read_text().replace('callers must check the 128-row expert limit.', 'callers must check workspace capacity.')
s=s.replace('        "prefix": args.prefix,\n        "shape":', '        "prefix": args.prefix,\n        "checkpoint": str(args.checkpoint),\n        "expand_workspace": args.expand_workspace,\n        "shape":',1)
s=s.replace('        "routing": "seeded uniform scores, unique top-8 per token",','        "routing": args.routing,')
needle='        ids = torch.rand(rows, args.experts, device="cuda").topk(8, dim=-1).indices\n'
repl='''        scores = torch.rand(rows, args.experts, device="cuda")
        if args.routing == "hot":
            scores[:, 0] = 2.0
        ids = scores.topk(8, dim=-1).indices
'''
assert s.count(needle)==2
s=s.replace(needle,repl,1)
needle='''            peak = counts.max().item()
            item = {
'''
repl='''            peak = counts.max().item()
            capacity = min(chunk, rows) if args.expand_workspace else 128
            workspace = method.workspace
            if capacity != workspace[0].shape[1]:
                workspace = [
                    t.new_empty((t.shape[0], capacity, t.shape[2])) for t in workspace
                ]
            candidate_inputs = (*inputs[:4], workspace, *inputs[5:])
            item = {
                "workspace_rows": capacity,
                "workspace_bytes": sum(t.numel() * t.element_size() for t in workspace),
'''
assert needle in s
s=s.replace(needle,repl,1)
s=s.replace('            if peak > 128:\n                item["skipped"] = "would silently drop experts exceeding 128 rows"', '            if peak > capacity:\n                item["skipped"] = "would silently drop experts exceeding workspace rows"',1)
s=s.replace('candidate = fused_with_chunk(inputs, chunk)', 'candidate = fused_with_chunk(candidate_inputs, chunk)',1)
s=s.replace('                    fused_with_chunk(inputs, chunk)', '                    fused_with_chunk(candidate_inputs, chunk)',1)
s=s.replace('input_args=(inputs, chunk)', 'input_args=(candidate_inputs, chunk)',1)
needle='    parser.add_argument("--prefill-rows", type=int, nargs="+")\n'
s=s.replace(needle,needle+'''    parser.add_argument("--expand-workspace", action="store_true")
    parser.add_argument("--routing", choices=["uniform", "hot"], default="uniform")
''',1)
p.write_text(s)
