import hashlib,json,statistics
from pathlib import Path
root=Path('/tmp/exl3-prefill-analysis-20260910')
summary={'protocol':json.loads((root/'protocol.json').read_text()),'performance':{},'event_profiles':{},'microbenchmarks':{},'checkpoint_scope':json.loads((root/'checkpoint_scope.json').read_text())}
for name in ['exl3-c512','nvfp4-c512','awq-c512','exl3-c8192','awq-c8192','nvfp4-c8192','exl3-c512-events','exl3-c8192-events']:
 p=root/f'{name}.json'
 if not p.exists(): continue
 d=json.loads(p.read_text()); perf=d['perf']
 if not perf: continue
 rows=[r['rows'][0] for r in perf]
 item={'samples':len(rows),'ttft_s':statistics.median(r['ttft'] for r in rows),'ttft_samples_s':[r['ttft'] for r in rows],'prefill_s':statistics.median(r['prefill'] for r in rows),'prefill_tokens_per_s':statistics.median(r['prompt_tokens']/r['prefill'] for r in rows),'answer_checks':[c['matched'] for r in perf for c in r['checks']],'cached_tokens':[r['cached_tokens'] for r in rows],'source_sha256':d['benchmark_source_sha256']}
 summary['performance'][name]=item
 print(name,'TTFT',round(item['ttft_s'],4),'TPS',round(item['prefill_tokens_per_s'],1),'correct',sum(item['answer_checks']),len(item['answer_checks']))
 if 'event_profile' not in d: continue
 event=d['event_profile']; ranks=[]
 print(' event wall',round(event['seconds'],4),'first token unchanged',event['rows'][0]['token_ids']==rows[0]['token_ids'][:1])
 for rank,data in enumerate(event['ranks']):
  r={'rank':rank,'gpu':data['gpu'],'timings':{k:{'calls':len(v),'sum_ms':sum(v),'median_ms':statistics.median(v),'min_ms':min(v),'max_ms':max(v)} for k,v in data['timings_ms'].items()}}
  if data['routing']:
   routing=data['routing']; assignments=sum(x['tokens']*x['topk'] for x in routing); tile_rows=sum(x['chunk128_rows_in_16row_tiles'] for x in routing)
   r['routing']={'calls':len(routing),'token_shapes':sorted(set(x['tokens'] for x in routing)),'expert_max_counts':[x['max_tokens_per_expert'] for x in routing],'assignments':assignments,'rows_in_16row_tiles':tile_rows,'tile_valid_fraction':assignments/tile_rows,'expert_visits':sum(x['chunk128_active_expert_visits'] for x in routing),'inner_128_chunks':sum((x['tokens']+127)//128 for x in routing)}
  ranks.append(r)
  print(' rank',rank,{k:round(v['sum_ms'],2) for k,v in r['timings'].items()})
 summary['event_profiles'][name]={'wall_seconds':event['seconds'],'first_token_unchanged':event['rows'][0]['token_ids']==rows[0]['token_ids'][:1],'ranks':ranks,'installed':d['event_profile_install']}
for p in sorted(root.glob('micro-gpu*.json')):
 d=json.loads(p.read_text()); summary['microbenchmarks'][p.stem]=d
 print(p.stem,[(r['tokens'],[(c['chunk'],round(c.get('median_ms',0),2)) for c in r['chunks']]) for r in d['rows']])
(root/'summary.json').write_text(json.dumps(summary,indent=2))
