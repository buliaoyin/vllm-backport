# SPDX-License-Identifier: Apache-2.0
# SPDX-FileCopyrightText: Copyright contributors to the vLLM project
"""Compare EXL3 fused experts and small-batch GEMM on a checkpoint MoE layer."""

import argparse
import json
import statistics
from pathlib import Path
from types import SimpleNamespace

import torch
from flashinfer.testing import bench_gpu_time_with_cudagraph
from safetensors import safe_open

from vllm.model_executor.layers.quantization.exl3 import (
    Exl3Config,
    Exl3MoEMethod,
    _exl3_moe_decode,
    _exl3_moe_fused,
    _extension,
)


def fused_with_chunk(inputs, chunk_size):
    """Ablate token grouping only; callers must check workspace capacity."""
    x, topk_weights, topk_ids, ptrs, workspace, bits, flags, limit = inputs
    ext = _extension()
    output = torch.empty_like(x)
    for start in range(0, x.shape[0], chunk_size):
        hidden = x[start : start + chunk_size].to(torch.float16).contiguous()
        ids = topk_ids[start : start + chunk_size].to(torch.int64).flatten()
        weights = topk_weights[start : start + chunk_size].to(torch.float16).flatten()
        order = torch.argsort(ids, stable=True)
        counts = torch.zeros(ptrs[0].numel() + 1, dtype=torch.int64, device=x.device)
        counts.scatter_add_(0, ids, torch.ones_like(ids))
        tokens = torch.div(order, topk_ids.shape[1], rounding_mode="floor")
        result = torch.zeros_like(hidden, dtype=torch.float32)
        ext.exl3_moe(
            hidden,
            result,
            counts,
            tokens,
            weights[order],
            *workspace,
            0,
            *bits,
            *ptrs,
            *flags,
            limit,
            -1,
        )
        output[start : start + hidden.shape[0]].copy_(result)
    return output


def prefill_ablation(layer, method, args, k, n):
    result = {
        "gpu": torch.cuda.get_device_name(),
        "torch": torch.__version__,
        "prefix": args.prefix,
        "checkpoint": str(args.checkpoint),
        "expand_workspace": args.expand_workspace,
        "shape": {"hidden": k, "intermediate": n, "experts": args.experts, "topk": 8},
        "seed": 20260910,
        "routing": args.routing,
        "cold_l2": True,
        "timer": "CUDA graph events (CUPTI unavailable on CMP)",
        "scope": "full expert wrapper GPU work, excludes Python replay dispatch",
        "flops": "6 * tokens * topk * hidden * intermediate (useful GEMM only)",
        "rows": [],
    }
    torch.manual_seed(result["seed"])
    for rows in args.prefill_rows:
        x = torch.randn(rows, k, device="cuda", dtype=torch.bfloat16)
        scores = torch.rand(rows, args.experts, device="cuda")
        if args.routing == "hot":
            scores[:, 0] = 2.0
        ids = scores.topk(8, dim=-1).indices
        weights = torch.rand(rows, 8, device="cuda").softmax(-1)
        inputs = (
            x,
            weights,
            ids,
            method.ptrs,
            method.workspace,
            method.bits,
            method.flags,
            10.0,
        )
        reference = _exl3_moe_fused(*inputs)
        record = {"tokens": rows, "chunks": []}
        for chunk in args.prefill_chunks:
            counts = torch.stack(
                [
                    torch.bincount(part.flatten(), minlength=args.experts)
                    for part in ids.split(chunk)
                ]
            )
            peak = counts.max().item()
            capacity = min(chunk, rows) if args.expand_workspace else 128
            workspace = method.workspace
            if capacity != workspace[0].shape[1]:
                workspace = [
                    t.new_empty((t.shape[0], capacity, t.shape[2])) for t in workspace
                ]
            candidate_inputs = (*inputs[:4], workspace, *inputs[5:])
            item = {
                "workspace_rows": capacity,
                "workspace_bytes": sum(t.numel() * t.element_size() for t in workspace),
                "chunk": chunk,
                "max_tokens_per_expert": peak,
                "active_expert_visits": (counts > 0).sum().item(),
                "rows_in_16row_tiles": (((counts + 15) // 16) * 16).sum().item(),
            }
            if peak > capacity:
                item["skipped"] = "would silently drop experts exceeding workspace rows"
            else:
                candidate = fused_with_chunk(candidate_inputs, chunk)
                relative = (
                    (candidate.float() - reference.float()).norm()
                    / reference.float().norm()
                ).item()
                assert relative < 0.01, (rows, chunk, relative)
                item["relative_l2"] = relative
                for _ in range(3):
                    fused_with_chunk(candidate_inputs, chunk)
                torch.accelerator.synchronize()
                ms = bench_gpu_time_with_cudagraph(
                    fused_with_chunk,
                    input_args=(candidate_inputs, chunk),
                    cold_l2_cache=True,
                    dry_run_iters=3,
                    repeat_iters=15,
                )
                item["median_ms"] = statistics.median(ms)
                item["min_ms"] = min(ms)
                item["max_ms"] = max(ms)
                item["useful_tflops"] = 6 * rows * 8 * k * n / (item["median_ms"] * 1e9)
            record["chunks"].append(item)
            print(rows, item, flush=True)
        result["rows"].append(record)
        args.output.write_text(json.dumps(result, indent=2))


@torch.inference_mode()
def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--checkpoint", type=Path, required=True)
    parser.add_argument("--prefix", required=True)
    parser.add_argument("--experts", type=int, default=288)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--prefill-rows", type=int, nargs="+")
    parser.add_argument("--expand-workspace", action="store_true")
    parser.add_argument("--routing", choices=["uniform", "hot"], default="uniform")
    parser.add_argument(
        "--prefill-chunks", type=int, nargs="+", default=[128, 512, 2048]
    )
    args = parser.parse_args()
    config = Exl3Config({})
    config.maybe_update_config(str(args.checkpoint))
    k, n = config.matrices[args.prefix + ".0.gate_proj"].dimensions
    moe = SimpleNamespace(
        moe_parallel_config=SimpleNamespace(tp_size=1, ep_size=1),
        activation="silu",
        swiglu_limit=10.0,
    )
    layer = torch.nn.Module()
    method = Exl3MoEMethod(config, moe, args.prefix)
    with torch.device("cuda"):
        method.create_weights(layer, args.experts, k, n, torch.bfloat16)
    for shard in args.checkpoint.glob("*.safetensors"):
        with safe_open(shard, framework="pt", device="cpu") as handle:
            for name in list(handle.keys()):
                if not name.startswith(args.prefix + "."):
                    continue
                expert, proj, component = name[len(args.prefix) + 1 :].split(".")
                if int(expert) >= args.experts:
                    continue
                kind = {"gate_proj": "w1", "up_proj": "w3", "down_proj": "w2"}[proj]
                param = getattr(layer, ("w2_" if kind == "w2" else "w13_") + component)
                param.weight_loader(
                    param, handle.get_tensor(name), expert_id=int(expert), shard_id=kind
                )
    method.process_weights_after_loading(layer)
    if args.prefill_rows:
        prefill_ablation(layer, method, args, k, n)
        return
    result = {
        "gpu": torch.cuda.get_device_name(),
        "torch": torch.__version__,
        "prefix": args.prefix,
        "cold_l2": True,
        "timer": "CUDA graph",
        "rows": [],
    }
    for rows in [1, 4, 8]:
        x = torch.randn(rows, k, device="cuda", dtype=torch.bfloat16)
        ids = torch.rand(rows, args.experts, device="cuda").topk(8, dim=-1).indices
        weights = torch.rand(rows, 8, device="cuda").softmax(-1)
        inputs = (
            x,
            weights,
            ids,
            method.ptrs,
            method.workspace,
            method.bits,
            method.flags,
            10.0,
        )
        fused = _exl3_moe_fused(*inputs)
        decode = _exl3_moe_decode(*inputs)
        rel = ((fused.float() - decode.float()).norm() / fused.float().norm()).item()
        assert rel < 0.01, rel
        record = {"tokens": rows, "relative_l2": rel}
        for label, fn in [
            ("fused_us", _exl3_moe_fused),
            ("decode_us", _exl3_moe_decode),
        ]:
            for _ in range(10):
                fn(*inputs)
            torch.accelerator.synchronize()
            timings = bench_gpu_time_with_cudagraph(
                fn,
                input_args=inputs,
                cold_l2_cache=True,
                dry_run_iters=5,
                repeat_iters=40,
            )
            record[label] = statistics.median(timings) * 1000
        result["rows"].append(record)
        print(record, flush=True)
        args.output.write_text(json.dumps(result, indent=2))


if __name__ == "__main__":
    main()
