import datetime,hashlib,json,os,subprocess,time
from pathlib import Path
root=Path('/tmp/exl3-prefill-analysis-20260910')
script=Path('/home/bul/dev/vllm-backport/benchmarks/kernels/benchmark_exl3_moe.py')
status={'runs':[]}
for gpu,routing in [(0,'uniform'),(0,'hot'),(3,'uniform'),(3,'hot')]:
 name=f'micro-gpu{gpu}-{routing}'
 env=os.environ.copy(); env.update(CUDA_DEVICE_ORDER='PCI_BUS_ID',CUDA_VISIBLE_DEVICES=str(gpu),EXL3_INT8_GEMV='0',OMP_NUM_THREADS='1')
 cmd=['/home/bul/dev/vllm-backport/.venv/bin/python',str(script),'--checkpoint','/home/bul/dev/models1/zai/turboderp/GLM-5.3-Flash-exl3/4.05bpw','--prefix','model.language_model.layers.3.mlp.experts','--output',str(root/f'{name}.json'),'--prefill-rows','512','8192','--prefill-chunks','128','512','2048','8192','--expand-workspace','--routing',routing]
 item={'name':name,'command':cmd,'source_sha256':hashlib.sha256(script.read_bytes()).hexdigest(),'start_utc':datetime.datetime.now(datetime.timezone.utc).isoformat()}
 status['runs'].append(item); (root/'micro_status.json').write_text(json.dumps(status,indent=2))
 print('START',name,flush=True); start=time.monotonic()
 with (root/f'{name}.log').open('w') as out:
  r=subprocess.run(cmd,cwd='/home/bul/dev/vllm-backport',env=env,stdout=out,stderr=subprocess.STDOUT)
 item.update(exit_code=r.returncode,elapsed_seconds=time.monotonic()-start,end_utc=datetime.datetime.now(datetime.timezone.utc).isoformat())
 (root/'micro_status.json').write_text(json.dumps(status,indent=2))
 print('DONE',name,r.returncode,round(item['elapsed_seconds'],1),flush=True)
 if r.returncode: raise SystemExit(r.returncode)
