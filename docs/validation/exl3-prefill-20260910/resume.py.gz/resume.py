import datetime,hashlib,json,os,subprocess,time
from pathlib import Path
root=Path('/tmp/exl3-prefill-analysis-20260910')
source=Path('/home/bul/dev/vllm-backport/benchmarks/benchmark_exl3.py')
status={'reason':'Remaining 8192-chunk comparisons, followed by EXL3 512 event probe. Initial AWQ clean timings succeeded; profiling RPC needed explicit local pickle support.','runs':[]}
env=os.environ.copy()
env.update({'CUDA_DEVICE_ORDER':'PCI_BUS_ID','CUDA_VISIBLE_DEVICES':'0,1,2,3','NCCL_P2P_DISABLE':'1','VLLM_PP_LAYER_PARTITION':'11,11,11,12','OMP_NUM_THREADS':'1','EXL3_INT8_GEMV':'0','VLLM_DETERMINISTIC_MOE_ALIGN':'0','VLLM_ALLOW_INSECURE_SERIALIZATION':'1'})
for fmt,chunk,label in [('exl3',8192,'exl3-c8192'),('awq',8192,'awq-c8192'),('nvfp4',8192,'nvfp4-c8192'),('exl3',512,'exl3-c512-events')]:
 cmd=['/home/bul/dev/vllm-backport/.venv/bin/python',str(source),'--backend','vllm','--pp','4','--inputs',str(root/f'{fmt}-inputs.json.gz'),'--output',str(root/f'{label}.json'),'--max-model-len','16384','--kv-cache-gib','4','--chunk-size',str(chunk),'--warmups','1','--tokens','32','--skip-eval','--profile-dir',str(root/f'{label}-profile'),'--profile-tokens','1']
 item={'name':label,'command':cmd,'source_sha256':hashlib.sha256(source.read_bytes()).hexdigest(),'start_utc':datetime.datetime.now(datetime.timezone.utc).isoformat()}
 status['runs'].append(item); (root/'resume_status.json').write_text(json.dumps(status,indent=2))
 print('START',label,flush=True); start=time.monotonic()
 with (root/f'{label}.log').open('w') as out:
  r=subprocess.run(cmd,cwd='/home/bul/dev/vllm-backport',env=env,stdout=out,stderr=subprocess.STDOUT)
 item.update(exit_code=r.returncode,elapsed_seconds=time.monotonic()-start,end_utc=datetime.datetime.now(datetime.timezone.utc).isoformat())
 (root/'resume_status.json').write_text(json.dumps(status,indent=2))
 print('DONE',label,r.returncode,round(item['elapsed_seconds'],1),flush=True)
 if r.returncode: raise SystemExit(r.returncode)
