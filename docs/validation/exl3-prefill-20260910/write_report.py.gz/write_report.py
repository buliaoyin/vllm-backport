import gzip,hashlib,json,shutil,statistics
from pathlib import Path
root=Path('/tmp/exl3-prefill-analysis-20260910')
repo=Path('/home/bul/dev/vllm-backport')
summary=json.loads((root/'summary.json').read_text())
primary=['exl3-c512','nvfp4-c512','awq-c512','exl3-c8192','nvfp4-c8192','awq-c8192']
assert all(summary['performance'].get(n,{}).get('samples')==3 for n in primary)
assert all(n in summary['event_profiles'] for n in ['exl3-c512-events','exl3-c8192-events','nvfp4-c8192','awq-c8192'])
art=repo/'docs/validation/exl3-prefill-20260910'; art.mkdir(exist_ok=True)
files=[]
for pat in ['*-inputs.json.gz','*-c*.json','micro-gpu*.json','*status*.json','protocol.json','checkpoint_scope.json','summary.json','current_source_sha256.json']:
 files.extend(root.glob(pat))
for p in sorted(set(files)):
 shutil.copy2(p,art/p.name)
for p in sorted(root.glob('*.log')):
 (art/(p.name+'.gz')).write_bytes(gzip.compress(p.read_bytes(),mtime=0))
for p in sorted(root.glob('*.py')):
 (art/(p.name+'.gz')).write_bytes(gzip.compress(p.read_bytes(),mtime=0))
for path in ['benchmarks/benchmark_exl3.py','benchmarks/exl3_profile_worker.py','benchmarks/kernels/benchmark_exl3_moe.py','vllm/model_executor/layers/quantization/exl3.py']:
 p=repo/path
 (art/(p.name+'.gz')).write_bytes(gzip.compress(p.read_bytes(),mtime=0))
manifest={p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in art.iterdir() if p.is_file() and p.name!='sha256.json'}
(art/'sha256.json').write_text(json.dumps(manifest,indent=2)+'\n')
text=(root/'report_notes.md').read_text()
rows=['## 同配置整模型结果','', '| 格式 | 外层 chunk | TTFT 中位数（秒） | Prefill token/s | 检索检查 |', '| --- | ---: | ---: | ---: | ---: |']
for fmt in ['exl3','nvfp4','awq']:
 for chunk in [512,8192]:
  r=summary['performance'][f'{fmt}-c{chunk}']
  rows.append(f"| {fmt.upper()} | {chunk} | {r['ttft_s']:.4f} | {r['prefill_tokens_per_s']:.1f} | {sum(r['answer_checks'])}/{len(r['answer_checks'])} |")
rows.extend(['','默认 512 chunk 下，EXL3 的 TTFT 是 NVFP4 的 {:.2f} 倍、AWQ 的 {:.2f} 倍。外层 chunk 提升到 8192，在这组 B1 / PP4 输入上没有改善延迟。'.format(summary['performance']['exl3-c512']['ttft_s']/summary['performance']['nvfp4-c512']['ttft_s'],summary['performance']['exl3-c512']['ttft_s']/summary['performance']['awq-c512']['ttft_s']),''])
text=text.replace('## 专家路径的结构差异','\n'.join(rows)+'\n## 专家路径的结构差异',1)
events=['## GPU 分项计时','', '| 格式 / chunk | rank | MoE runner 含路由/shared（ms） | routed wrapper（ms） | 专家 kernel/GEMM（ms） |', '| --- | ---: | ---: | ---: | ---: |']
for name in ['exl3-c512-events','exl3-c8192-events','nvfp4-c8192','awq-c8192']:
 for r in summary['event_profiles'][name]['ranks']:
  t=r['timings']; get=lambda k:t.get(k,{}).get('sum_ms',0)
  kernel='exl3_moe' if name.startswith('exl3') else 'marlin_gemm'
  events.append(f"| {name} | {r['rank']} | {get('moe_runner_inclusive'):.2f} | {get('routed_experts_inclusive'):.2f} | {get(kernel):.2f} |")
events.extend(['','以上三列是嵌套边界，不能相加。AWQ 的 routed / Marlin 列覆盖 41 个量化 MoE 层，runner 列还包含末层未量化专家；EXL3/NVFP4 routed 列覆盖 42 层。各组都是单独采样请求，最终首 token 与干净计时的首 token 一致。',''])
for name in ['exl3-c512-events','exl3-c8192-events']:
 e=summary['event_profiles'][name]; totals={}
 for r in e['ranks']:
  for k,v in r['timings'].items():totals[k]=totals.get(k,0)+v['sum_ms']
 events.append(f"`{name}` 的 profile 请求墙钟为 {e['wall_seconds']:.4f} 秒；四卡专家 wrapper 间隔之和 {totals.get('routed_experts_inclusive',0)/1000:.4f} 秒，内部 expert kernel 间隔之和 {totals.get('exl3_moe',0)/1000:.4f} 秒。其余 EXL3 扩展操作总间隔：" )
 events.append('')
 for k in ['reconstruct_slice','reconstruct_had_slice','had_r_128','hgemm','exl3_gemm']:
  if k in totals:events.append(f'- `{k}`：{totals[k]:.2f} ms。')
 events.append('')
text=text.replace('## 消融的约束','\n'.join(events)+'\n## 消融的约束',1)
mic=['## 8K 单层同权重消融','', '| GPU / 路由 | 分组 128（ms） | 分组 512（ms） | 分组 2048（ms） | 分组 8192（ms） | 512 相对 128 | 最大 relative L2 |','| --- | ---: | ---: | ---: | ---: | ---: | ---: |']
for name in ['micro-gpu0-uniform','micro-gpu0-hot','micro-gpu3-uniform','micro-gpu3-hot']:
 r=next(r for r in summary['microbenchmarks'][name]['rows'] if r['tokens']==8192)['chunks']
 vals={c['chunk']:c for c in r}
 mic.append('| '+name+' | '+' | '.join(f"{vals[k]['median_ms']:.2f}" for k in [128,512,2048,8192])+f" | {vals[128]['median_ms']/vals[512]['median_ms']:.2f}× | {max(c['relative_l2'] for c in r):.2e} |")
mic.extend(['','两类 GPU、两种路由、两种输入长度、四种分组，共 32 个候选/基线输出比较均通过。更大工作区允许热门专家接收超过 128 行；极端用例覆盖了单专家 8192 行。',''])
text=text.replace('## 量化覆盖范围','\n'.join(mic)+'\n## 量化覆盖范围',1)
text=text.replace('完整命令、环境、token IDs 哈希、源文件快照、结果和日志位于配套 artifacts。','完整命令、环境、token IDs 哈希、源文件快照、结果和日志位于 [artifacts](exl3-prefill-20260910/sha256.json)，结构化汇总见 [summary.json](exl3-prefill-20260910/summary.json)。')
text+='\n检查：相关文件 pre-commit 与 Python 3.12 mypy 通过；模型计时请求和独立算子正确性检查如上。此次诊断仅修改基准、探针与文档，较大的专家分组尚未应用于推理后端。\n'
(repo/'docs/validation/exl3-prefill-analysis-20260910.md').write_text(text)
print('wrote report',len(text),'characters and',len(manifest),'artifacts')
