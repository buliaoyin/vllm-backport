from pathlib import Path
p=Path('benchmarks/kernels/benchmark_exl3_moe.py')
s=p.read_text().replace('    _exl3_moe_fused,\n','    _exl3_moe_fused,\n    _extension,\n')
needle='\n\n@torch.inference_mode()\ndef main():'
addition='''

def fused_with_chunk(inputs, chunk_size):
    """Ablate token grouping only; callers must check the 128-row expert limit."""
    x, topk_weights, topk_ids, ptrs, workspace, bits, flags, limit = inputs
    ext = _extension()
    output = torch.empty_like(x)
    for start in range(0, x.shape[0], chunk_size):
        hidden = x[start : start + chunk_size].to(torch.float16).contiguous()
        ids = topk_ids[start : start + chunk_size].to(torch.int64).flatten()
        weights = topk_weights[start : start + chunk_size].to(torch.float16).flatten()
        order = torch.argsort(ids, stable=True)
        counts = torch.zeros(ptrs[0].numel() + 1, dtype=torch.int64, device=x.device)
        counts.scatter_add_(0, ids, torch.ones_like(ids))
        tokens = torch.div(order, topk_ids.shape[1], rounding_mode="floor")
        result = torch.zeros_like(hidden, dtype=torch.float32)
        ext.exl3_moe(
            hidden, result, counts, tokens, weights[order], *workspace,
            0, *bits, *ptrs, *flags, limit, -1,
        )
        output[start : start + hidden.shape[0]].copy_(result)
    return output


def prefill_ablation(layer, method, args, k, n):
    result = {
        "gpu": torch.cuda.get_device_name(),
        "torch": torch.__version__,
        "prefix": args.prefix,
        "shape": {"hidden": k, "intermediate": n, "experts": args.experts, "topk": 8},
        "seed": 20260910,
        "routing": "seeded uniform scores, unique top-8 per token",
        "cold_l2": True,
        "timer": "CUDA graph events (CUPTI unavailable on CMP)",
        "scope": "full expert wrapper GPU work, excludes Python replay dispatch",
        "flops": "6 * tokens * topk * hidden * intermediate (useful GEMM only)",
        "rows": [],
    }
    torch.manual_seed(result["seed"])
    for rows in args.prefill_rows:
        x = torch.randn(rows, k, device="cuda", dtype=torch.bfloat16)
        ids = torch.rand(rows, args.experts, device="cuda").topk(8, dim=-1).indices
        weights = torch.rand(rows, 8, device="cuda").softmax(-1)
        inputs = (x, weights, ids, method.ptrs, method.workspace,
                  method.bits, method.flags, 10.0)
        reference = _exl3_moe_fused(*inputs)
        record = {"tokens": rows, "chunks": []}
        for chunk in args.prefill_chunks:
            counts = torch.stack([
                torch.bincount(part.flatten(), minlength=args.experts)
                for part in ids.split(chunk)
            ])
            peak = counts.max().item()
            item = {"chunk": chunk, "max_tokens_per_expert": peak,
                    "active_expert_visits": (counts > 0).sum().item(),
                    "rows_in_16row_tiles": (((counts + 15) // 16) * 16).sum().item()}
            if peak > 128:
                item["skipped"] = "would silently drop experts exceeding 128 rows"
            else:
                candidate = fused_with_chunk(inputs, chunk)
                relative = ((candidate.float() - reference.float()).norm()
                            / reference.float().norm()).item()
                assert relative < 0.01, (rows, chunk, relative)
                item["relative_l2"] = relative
                for _ in range(3):
                    fused_with_chunk(inputs, chunk)
                torch.cuda.synchronize()
                ms = bench_gpu_time_with_cudagraph(
                    fused_with_chunk, input_args=(inputs, chunk),
                    cold_l2_cache=True, dry_run_iters=3, repeat_iters=15,
                )
                item["median_ms"] = statistics.median(ms)
                item["min_ms"] = min(ms)
                item["max_ms"] = max(ms)
                item["useful_tflops"] = 6 * rows * 8 * k * n / (item["median_ms"] * 1e9)
            record["chunks"].append(item)
            print(rows, item, flush=True)
        result["rows"].append(record)
        args.output.write_text(json.dumps(result, indent=2))
'''
assert needle in s
s=s.replace(needle,addition+needle)
s=s.replace('    args = parser.parse_args()\n','''    parser.add_argument("--prefill-rows", type=int, nargs="+")
    parser.add_argument("--prefill-chunks", type=int, nargs="+", default=[128, 512, 2048])
    args = parser.parse_args()
''')
s=s.replace('    result = {\n        "gpu": torch.cuda.get_device_name(),', '''    if args.prefill_rows:
        prefill_ablation(layer, method, args, k, n)
        return
    result = {
        "gpu": torch.cuda.get_device_name(),''',1 if False else 0) if False else s
needle='    method.process_weights_after_loading(layer)\n'
s=s.replace(needle,needle+'''    if args.prefill_rows:
        prefill_ablation(layer, method, args, k, n)
        return
''')
p.write_text(s)
