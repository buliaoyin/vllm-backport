import sys
from types import SimpleNamespace
sys.path.insert(0,'/home/bul/dev/vllm-backport/benchmarks')
import torch
from exl3_profile_worker import Exl3ProfileWorkerExtension
from vllm.model_executor.layers.quantization.exl3 import _extension

def child():
    worker=SimpleNamespace(vllm_config=SimpleNamespace(model_config=SimpleNamespace(quantization='exl3')),get_model=lambda:torch.nn.Module())
    a=torch.randn(128,128,device='cuda',dtype=torch.float16); b=torch.randn_like(a); c=torch.empty_like(a)
    ext=_extension(); ext.hgemm(a,b,c); torch.accelerator.synchronize()
    print(Exl3ProfileWorkerExtension.install_exl3_event_profile(worker),flush=True)
    ext.hgemm(a,b,c)
    r=Exl3ProfileWorkerExtension.collect_exl3_event_profile(worker)
    assert len(r['timings_ms']['hgemm'])==1
    assert r['timings_ms']['hgemm'][0]>0
    print('EVENT_PROBE_PASS',r['timings_ms'],flush=True)

if __name__=='__main__':
    import multiprocessing as mp
    p=mp.get_context('spawn').Process(target=child); p.start(); p.join(); assert p.exitcode==0
