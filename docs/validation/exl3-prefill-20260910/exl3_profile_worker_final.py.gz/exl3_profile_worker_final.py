# SPDX-License-Identifier: Apache-2.0
# SPDX-FileCopyrightText: Copyright contributors to the vLLM project
"""Optional worker instrumentation for benchmark_exl3.py."""

import torch


class Exl3ProfileWorkerExtension:
    def install_exl3_event_profile(self):
        """Instrument eager expert boundaries after the clean throughput runs."""
        from collections import Counter
        from functools import wraps

        from vllm.model_executor.layers.fused_moe.experts import marlin_moe
        from vllm.model_executor.layers.fused_moe.runner.moe_runner import MoERunner
        from vllm.model_executor.layers.quantization import exl3

        state = {"events": [], "originals": [], "pool": [], "routing": []}
        self._exl3_event_profile = state
        # Initialize CUDA event handles before entering the measured request.
        for _ in range(16384):
            pair = tuple(torch.cuda.Event(enable_timing=True) for _ in range(2))
            for event in pair:
                event.record()
            state["pool"].append(pair)
        torch.accelerator.synchronize()

        def patch(owner, name, label, routing=False):
            original = getattr(owner, name)
            state["originals"].append((owner, name, original))

            @wraps(original)
            def measured(*args, **kwargs):
                index = len(state["events"])
                if index >= len(state["pool"]):
                    raise RuntimeError("CUDA event profile pool exhausted")
                start, end = state["pool"][index]
                state["events"].append((label, start, end))
                if routing:
                    ids = kwargs.get("topk_ids")
                    if ids is None:
                        ids = args[2]
                    state["routing"].append(ids.detach().clone())
                start.record()
                try:
                    return original(*args, **kwargs)
                finally:
                    end.record()

            setattr(owner, name, measured)

        patch(MoERunner, "_forward_impl", "moe_runner_inclusive")
        patch(marlin_moe, "fused_marlin_moe", "routed_experts_inclusive")
        patch(marlin_moe.ops, "moe_wna16_marlin_gemm", "marlin_gemm")
        quantization = self.vllm_config.model_config.quantization
        if quantization == "exl3":
            patch(exl3, "_exl3_moe_fused", "routed_experts_inclusive", routing=True)
            ext = exl3._extension()
            for name in (
                "exl3_moe",
                "exl3_gemm",
                "hgemm",
                "reconstruct_slice",
                "reconstruct_had_slice",
                "had_r_128",
            ):
                patch(ext, name, name)
        methods = Counter(
            type(module.quant_method).__name__
            for module in self.get_model().modules()
            if getattr(module, "quant_method", None) is not None
        )
        return {"gpu": torch.cuda.get_device_name(), "quant_methods": dict(methods)}

    def collect_exl3_event_profile(self):
        """Return rank-local stream intervals; nested labels must not be added."""
        from collections import defaultdict

        state = self._exl3_event_profile
        torch.accelerator.synchronize()
        for owner, name, original in reversed(state["originals"]):
            setattr(owner, name, original)
        timings = defaultdict(list)
        for label, start, end in state["events"]:
            timings[label].append(start.elapsed_time(end))
        routing = []
        for ids in state["routing"]:
            counts = torch.bincount(ids.flatten().long(), minlength=288)
            chunk_counts = torch.stack(
                [
                    torch.bincount(chunk.flatten().long(), minlength=288)
                    for chunk in ids.split(128)
                ]
            )
            routing.append(
                {
                    "tokens": ids.shape[0],
                    "topk": ids.shape[1],
                    "max_tokens_per_expert": counts.max().item(),
                    "active_experts": (counts > 0).sum().item(),
                    "chunk128_active_expert_visits": (chunk_counts > 0).sum().item(),
                    "chunk128_max_tokens_per_expert": chunk_counts.max().item(),
                    "chunk128_rows_in_16row_tiles": (((chunk_counts + 15) // 16) * 16)
                    .sum()
                    .item(),
                }
            )
        result = {
            "gpu": torch.cuda.get_device_name(),
            "timer": "CUDA events on current stream, including wrapper launch gaps",
            "nested_labels_are_not_additive": True,
            "timings_ms": dict(timings),
            "routing": routing,
        }
        del self._exl3_event_profile
        return result
