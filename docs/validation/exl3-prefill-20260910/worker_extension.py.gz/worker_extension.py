from pathlib import Path
import textwrap
p=Path('benchmarks/benchmark_exl3.py'); s=p.read_text()
a=s.index('def install_event_profile(worker):'); b=s.index('def response_before_stop(',a)
block=s[a:b].rstrip().replace('install_event_profile(worker)','install_exl3_event_profile(self)').replace('collect_event_profile(worker)','collect_exl3_event_profile(self)').replace('worker.', 'self.')
header='''# SPDX-License-Identifier: Apache-2.0
# SPDX-FileCopyrightText: Copyright contributors to the vLLM project
"""Optional worker instrumentation for benchmark_exl3.py."""

import torch


class Exl3ProfileWorkerExtension:
'''
Path('benchmarks/exl3_profile_worker.py').write_text(header+textwrap.indent(block,'    ')+'\n')
s=s[:a]+s[b:]
s=s.replace('''            profiler_config=(
''','''            worker_extension_cls=(
                "benchmarks.exl3_profile_worker.Exl3ProfileWorkerExtension"
                if args.profile_dir
                else ""
            ),
            profiler_config=(
''',1)
s=s.replace('            install_event_profile\n','            "install_exl3_event_profile"\n')
s=s.replace('backend.llm.collective_rpc(collect_event_profile)','backend.llm.collective_rpc("collect_exl3_event_profile")')
p.write_text(s)
root=Path('/tmp/exl3-prefill-analysis-20260910')
(root/'benchmark_worker_extension.py').write_bytes(p.read_bytes())
(root/'exl3_profile_worker.py').write_bytes(Path('benchmarks/exl3_profile_worker.py').read_bytes())
