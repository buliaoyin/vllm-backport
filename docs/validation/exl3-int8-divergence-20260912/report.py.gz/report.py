import json
from pathlib import Path

p=Path('/tmp/exl3-divergence-20260912')
s=json.loads((p/'summary.json').read_text())
r=json.loads((p/'results.json').read_text())
a=s['aggregates'];cn=a['native_repeat']['gsm'];ci=a['int8_forced']['gsm']
lines=['# EXL3 强制 INT8 全模型 logits 散度（2026-09-12）','',
       '## 结果','',
       f"三张 CMP 170HX、固定 PP **16/15/14**。64 道 GSM8K 共 **{ci['positions']:,} 个输出预测位置**，",
       '逐 token 固定相同历史，比较全词表分布。参考是原生 EXL3 prefill，不是未量化 BF16 模型。','',
       '| 对照 | 平均 KL | P95 KL | P99 KL | 最大 KL | 平均 JS | 平均 TV | Top-1 一致率 |',
       '| --- | --- | --- | --- | --- | --- | --- | --- |']
for label,z in [('原生重复 / 原生参考',cn),('强制 INT8 / 原生参考',ci)]:
    k=z['kl_native_int8'];lines.append(f"| {label} | {k['mean']:.6f} | {k['p95']:.6f} | {k['p99']:.6f} | {k['max']:.6f} | {z['js']['mean']:.6f} | {z['tv']['mean']*100:.3f}% | {z['top1_agreement']*100:.3f}% |")
lines += ['', 'KL 为 **KL(原生参考 || 候选)**，KL/JS 单位 nats。TV 表示概率质量差异；',
          'top-1 一致率是固定历史下下一 token 的一致率，不是题目正确率。', '',
          f"INT8 平均 KL 约为原生重复的 **{ci['kl_native_int8']['mean']/cn['kl_native_int8']['mean']:.2f} 倍**，",
          f"观察到 {ci['top1_flips']} 个 top-1 变化；原生自身重复为 {cn['top1_flips']} 个。",
          f"INT8 中，原生 top-1 概率 ≥90% 的位置发生 {ci['native_confidence_90_flips']} 次翻转。",
          '按题目分别求均值，59/64 题的 INT8 KL 高于原生重复。',
          '低于 90% 原生置信度的 1648 个位置中，INT8 top-1 一致率为 93.932%；',
          '其余 9024 个高置信度位置一致率为 100%。这仍只描述本次固定历史样本。',
          '重复运行并非逐位一致，因此不能把 INT8 对照的全部散度都归于新增近似算术；',
          '同时，较小的平均散度也不能证明自由生成答案无退化。', '',
          '## 首 token 与后续 decode','',
          '| 阶段 | 位置数 | 原生重复平均 KL | INT8 平均 KL | INT8 P95 KL | INT8 Top-1 一致率 |',
          '| --- | --- | --- | --- | --- | --- |']
for title,key in [('Prefill 首 token','gsm_first'),('后续纯 decode','gsm_decode')]:
    z=a['int8_forced'][key];n=a['native_repeat'][key]
    lines.append(f"| {title} | {z['positions']} | {n['kl_native_int8']['mean']:.6f} | {z['kl_native_int8']['mean']:.6f} | {z['kl_native_int8']['p95']:.6f} | {z['top1_agreement']*100:.3f}% |")
lines += ['', '这 64 题的 prefill 在各自 B4 的首批完成，后续为 1–4 行纯 decode。算子计数确认，',
          '两边后续使用相同的专家 plain INT8 GEMV；散度可以随不同数值的 KV/状态延续到后续步骤。',
          '这里的“后续 decode 散度”不是把 decode 改成新 INT8 prefill 内核后测得的。','',
          '## 上轮三道新增错题','',
          '| 题号 | 位置数 | 原生重复平均 KL | INT8 平均 KL | INT8 最大 KL | 原生 / INT8 Top-1 变化数 |',
          '| --- | --- | --- | --- | --- | --- |']
for idx in (9,12,21):
    n=s['per_request']['native_repeat'][f'gsm_{idx}'];z=s['per_request']['int8_forced'][f'gsm_{idx}']
    lines.append(f"| {idx} | {z['positions']} | {n['kl_native_int8']['mean']:.6f} | {z['kl_native_int8']['mean']:.6f} | {z['kl_native_int8']['max']:.6f} | {n['top1_flips']} / {z['top1_flips']} |")
lines += ['', '在固定原生正确历史下，三题最后数字的 top-1 仍分别为 460、13、14，没有翻转。',
          '第 21 题在输出 step 61（从 0 计数）的 KL 为 0.268917，',
          '相同前缀 `Step 2: Find` 后的 top-1 从 ` the` 变为 ` when`；最终 `14` 位置',
          'step 99 的 KL 约为 5.3e-7。这样的措辞分支本身不等于算术错误。',
          '本轮没有自由生成到错误轨迹，不能据此宣称复现、定位或修复了上轮三题的失败。','',
          '## 长输入与并发','',
          '这一部分是访问码检索，**10 个请求仅有 49 个输出预测位置**；每请求为 4–5 个 token。',
          '输入长度到 64K，但没有对全部输入 token 采集 logits。样本很少，仅作为长上下文数值检查。','',
          '| 输入组合 | 输出位置数 | 原生重复平均 KL | 全 prefill 强制 INT8 平均 KL | ≥4096 行 INT8 平均 KL | 强制 / ≥4096 Top-1 一致率 |',
          '| --- | --- | --- | --- | --- | --- |']
for name,label in [('long_8k','8K × 1'),('long_16k','16K × 1'),('long_32k','32K × 1'),('long_64k','64K × 1'),('long_8k_8k_8k_8k','8K × 4'),('long_32k_32k','32K × 2')]:
    n=a['native_repeat'][name];z=a['int8_forced'][name];h=a['int8_4096'][name]
    lines.append(f"| {label} | {z['positions']} | {n['kl_native_int8']['mean']:.6g} | {z['kl_native_int8']['mean']:.6g} | {h['kl_native_int8']['mean']:.6g} | {z['top1_agreement']*100:.1f}% / {h['top1_agreement']*100:.1f}% |")
long=a['int8_forced']['long']
lines += ['', f"其中 {long['mixed_decode_positions']} 个位置是 decode 与其他请求 prefill 合批，可能一并经过新 INT8 内核。",
          '4096 行对照保持相同的 6144 调度 chunk，只让小尾块回到原生；它不是完整的 auto 调度运行，',
          '也不是量化误差补偿。16K、64K 的两种 INT8 门槛实际算子/行数计数完全相同，',
          '因为其所有 prefill chunk 均 ≥4096；它们的散度仍有变化，不能解读为 4096 门槛改善精度。',
          '逐请求及纯/混合 decode 的细分保存在 summary.json。','',
          '## 判断','',
          '本轮测得强制 INT8 相对于原生重复有额外分布偏移，但 top-1 大部分仍相同。',
          '散度无法替代题目正确率，尤其不能从 49 个检索输出位置外推完整长上下文能力。',
          '上轮自由生成的原生 64/64、强制 INT8 61/64 仍是独立的质量记录；本轮不改写它，',
          '也不证明其中全部差异来自 INT8。默认继续保持 native，本次没有修改生产内核或默认参数。','']
methods=(p/'report-methods.md').read_text().split('\n',1)[1]
lines.append(methods.lstrip())
lines += ['','## 校验、文件与复现','',
          '所有 72 个阶段完成，22 组调度逐项一致；三卡算子计数、纯 decode 行数分布、',
          '全量位置/目标 token 覆盖、数值范围、执行源码和依赖哈希核验通过。',
          '新增诊断代码通过 pre-commit；可解析分布的 KL/TV、自比较、argmax 平局校验通过。',
          '日志在 DONE 之后出现 vLLM 收尾清理超时及 shared_memory 提示；退出码为 0，',
          '确认无残留 GPU 进程，采样阶段无异常。','',
          '- [逐组原始结果](exl3-int8-divergence-20260912/results.json.gz)：输入/目标 IDs、逐位置指标、调度和各 rank 计数。',
          '- [统计汇总](exl3-int8-divergence-20260912/summary.json)：分组、首 token、decode、置信度及每请求统计。',
          '- [逐位置 CSV](exl3-int8-divergence-20260912/positions.csv.gz)：可直接用于额外分析。',
          '- [上下文样本](exl3-int8-divergence-20260912/contexts.json)：大散度位置及三道旧错题的 token 文本。',
          '- [完整核验](exl3-int8-divergence-20260912/audit.json) 与 [文件清单](exl3-int8-divergence-20260912/manifest.json)。',
          '- [运行日志](exl3-int8-divergence-20260912/run.log.gz) 和冻结的 runner/worker/分析脚本也在同一目录。','',
          '在已配置的仓库环境中运行，先清除其他 EXL3 环境变量覆盖；存档 run.py.gz 含完整的环境清理逻辑：','',
          '```bash',
          'env CUDA_VISIBLE_DEVICES=0,1,2 CUDA_DEVICE_ORDER=PCI_BUS_ID \\',
          '  NCCL_P2P_DISABLE=1 VLLM_PP_LAYER_PARTITION=16,15,14 \\',
          '  VLLM_TOKEN_BUCKET_PAD=0 VLLM_EXL3_MOE_PREFILL=int8 \\',
          '  VLLM_EXL3_MOE_INT8_MIN_TOKENS=9 VLLM_EXL3_MOE_MAX_TOKENS=2048 \\',
          '  EXL3_INT8_GEMV=2 VLLM_TRITON_USE_TD=0 OMP_NUM_THREADS=1 \\',
          '  PYTHONPATH="$PWD/benchmarks:$PWD" \\',
          '  PYTORCH_ALLOC_CONF=expandable_segments:True \\',
          '  .venv/bin/python benchmarks/benchmark_exl3_divergence.py \\',
          '  --artifacts docs/validation/exl3-adaptive-prefill-20260912 \\',
          '  --output /tmp/exl3-divergence.json',
          '```','']
report=Path('/home/bul/dev/vllm-backport/docs/validation/exl3-int8-divergence-20260912.md')
report.write_text('\n'.join(lines))
print(report)
