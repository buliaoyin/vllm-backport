import json
from pathlib import Path
from transformers import AutoTokenizer

p=Path('/tmp/exl3-divergence-20260912')
raw=json.loads((p/'results.json').read_text())
summary=json.loads((p/'summary.json').read_text())
tokenizer=AutoTokenizer.from_pretrained(raw['model'],local_files_only=True)
records={r['name']:r for _,rs in raw['groups'] for r in rs}
selected={}
for r in summary['largest_kl']+summary['prior_errors_flips']:
    selected[r['name'],r['step']]=r
# Include the final numeric-answer region of the three previously wrong questions.
for result in raw['results']:
    if result['phase'] != 'int8_forced':continue
    for row in result['ranks'][-1]['metrics']:
        if row['name'] in ['gsm_9','gsm_12','gsm_21'] and row['step'] >= len(records[row['name']]['targets'])-8:
            selected[row['name'],row['step']]=dict(row,group=result['group'],phase=result['phase'])
contexts=[]
for (name,step),row in selected.items():
    tokens=records[name]['targets']
    item=dict(row)
    item.update(prefix=tokenizer.decode(tokens[max(0,step-18):step]),
                target_text=tokenizer.decode([row['target']]),
                native_top1_text=tokenizer.decode([row['native_top1']]),
                candidate_top1_text=tokenizer.decode([row['candidate_top1']]),
                native_top2_text=tokenizer.decode([row['native_top2']]),
                candidate_top2_text=tokenizer.decode([row['candidate_top2']]),
                next_tokens=tokenizer.decode(tokens[step:step+12]))
    contexts.append(item)
(p/'contexts.json').write_text(json.dumps(contexts,ensure_ascii=False,indent=2))
print('contexts',len(contexts))
for r in sorted(contexts,key=lambda r:r['kl_native_int8'],reverse=True)[:15]:
    print(r['name'],r['step'],round(r['kl_native_int8'],6),round(r['native_top1_probability'],4),repr(r['prefix']),repr(r['native_top1_text']),'=>',repr(r['candidate_top1_text']))
