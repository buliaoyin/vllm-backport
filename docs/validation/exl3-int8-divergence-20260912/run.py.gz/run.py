import json,os,subprocess,sys,time
from pathlib import Path
root=Path('/home/bul/dev/vllm-backport');p=Path('/tmp/exl3-divergence-20260912')
env={k:v for k,v in os.environ.items() if not k.startswith(('EXL3_','VLLM_EXL3_'))}
env.update(CUDA_VISIBLE_DEVICES='0,1,2',CUDA_DEVICE_ORDER='PCI_BUS_ID',NCCL_P2P_DISABLE='1',VLLM_PP_LAYER_PARTITION='16,15,14',VLLM_EXL3_MOE_PREFILL='int8',VLLM_EXL3_MOE_INT8_MIN_TOKENS='9',EXL3_INT8_GEMV='2',VLLM_EXL3_MOE_MAX_TOKENS='2048',VLLM_TRITON_USE_TD='0',VLLM_TOKEN_BUCKET_PAD='0',OMP_NUM_THREADS='1',PYTHONPATH=str(root/'benchmarks')+':'+str(root),PYTORCH_ALLOC_CONF='expandable_segments:True')
cmd=[sys.executable,'benchmarks/benchmark_exl3_divergence.py','--artifacts','docs/validation/exl3-adaptive-prefill-20260912','--output',str(p/'results.json'),*sys.argv[1:]]
status={'command':cmd,'env':{k:v for k,v in env.items() if k.startswith(('CUDA_','VLLM_','EXL3_','NCCL_','OMP_','PYTORCH_'))},'start':time.time()};(p/'status.json').write_text(json.dumps(status,indent=2))
with (p/'run.log').open('w') as log:r=subprocess.run(cmd,cwd=root,env=env,stdout=log,stderr=subprocess.STDOUT,timeout=3000)
status.update(exit_code=r.returncode,end=time.time());(p/'status.json').write_text(json.dumps(status,indent=2));print(r.returncode,flush=True);sys.exit(r.returncode)
