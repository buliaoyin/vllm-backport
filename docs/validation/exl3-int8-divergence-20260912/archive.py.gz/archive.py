import gzip,hashlib,json
from pathlib import Path

root=Path('/home/bul/dev/vllm-backport')
source=Path('/tmp/exl3-divergence-20260912')
out=root/'docs/validation/exl3-int8-divergence-20260912'
assert json.loads((source/'audit.json').read_text())['passed']
out.mkdir(parents=True,exist_ok=True)
plain=['summary.json','contexts.json','status.json','audit.json','metrics-check.json','provenance.json','packages.json']
compressed=['results.json','positions.csv','run.log','run.py','analyze.py','context.py','audit.py','report.py','report-methods.md','archive.py','lint.log']
for name in plain:
    (out/name).write_bytes((source/name).read_bytes())
for name in compressed:
    (out/(name+'.gz')).write_bytes(gzip.compress((source/name).read_bytes(),mtime=0))
for name in ['benchmark_exl3_divergence.py.gz','exl3_divergence_worker.py.gz']:
    (out/name).write_bytes((source/name).read_bytes())
manifest={'scope':'Completed unpadded teacher-forced full-vocabulary diagnostics only. Failed request-ID probe and excluded padded-decode probe are not included.',
          'inputs_and_native_targets':'../exl3-adaptive-prefill-20260912',
          'files':{f.name:{'bytes':f.stat().st_size,'sha256':hashlib.sha256(f.read_bytes()).hexdigest()} for f in sorted(out.iterdir()) if f.name!='manifest.json'}}
(out/'manifest.json').write_text(json.dumps(manifest,indent=2))
print(out,len(manifest['files']),sum(f['bytes'] for f in manifest['files'].values()))
