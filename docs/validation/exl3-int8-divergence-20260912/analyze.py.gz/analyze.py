import csv
import json
import math
import statistics
from collections import defaultdict
from pathlib import Path

folder = Path('/tmp/exl3-divergence-20260912')
raw = json.loads((folder/'results.json').read_text())
metrics = []
schedules = {}
checks = []
for result in raw['results']:
    group, phase = result['group'], result['phase']
    ranks = result['ranks']
    schedule = ranks[-1]['schedule']
    if phase == 'reference':
        schedules[group] = schedule
    else:
        checks.append({'group': group, 'phase': phase,
                       'same_schedule': schedule == schedules[group],
                       'positions': len(ranks[-1]['metrics']),
                       'int8_calls': [r['calls'].get('int8', 0) for r in ranks]})
    geometry = {}
    offset = 0
    while offset < len(schedule):
        count = schedule[offset][3]
        batch = schedule[offset:offset+count]
        assert len(batch) == count and all(x[3] == count for x in batch)
        total = sum(x[2] for x in batch)
        for name, step, scheduled, _ in batch:
            if step >= 0:
                assert (name, step) not in geometry
                geometry[name, step] = {'batch_tokens': total,
                                       'batch_requests': count,
                                       'row_scheduled_tokens': scheduled,
                                       'mixed_decode': step > 0 and total > count}
        offset += count
    for row in ranks[-1]['metrics']:
        metrics.append(dict(row, group=group, phase=phase, **geometry[row['name'], row['step']]))

def quantile(values, q):
    values = sorted(values)
    x = (len(values)-1)*q
    lo, hi = math.floor(x), math.ceil(x)
    return values[lo]*(hi-x)+values[hi]*(x-lo) if lo != hi else values[lo]

def aggregate(rows):
    if not rows:
        return {}
    out = {'positions': len(rows), 'requests': len({r['name'] for r in rows}),
           'top1_agreement': statistics.fmean(r['top1_equal'] for r in rows),
           'top1_flips': sum(not r['top1_equal'] for r in rows),
           'native_confidence_90_flips': sum(not r['top1_equal'] and r['native_top1_probability'] >= .9 for r in rows),
           'native_margin_1nat_flips': sum(not r['top1_equal'] and r['native_top1_margin'] >= 1 for r in rows),
           'mean_target_nll_delta': statistics.fmean(r['native_target_logprob']-r['candidate_target_logprob'] for r in rows)}
    out['mixed_decode_positions'] = sum(r['mixed_decode'] for r in rows)
    out['native_target_nll'] = -statistics.fmean(r['native_target_logprob'] for r in rows)
    out['candidate_target_nll'] = -statistics.fmean(r['candidate_target_logprob'] for r in rows)
    for field in ('kl_native_int8', 'kl_int8_native', 'js', 'tv', 'max_probability_delta'):
        vals = [r[field] for r in rows]
        out[field] = {'mean': statistics.fmean(vals), 'p50': quantile(vals, .5),
                      'p95': quantile(vals, .95), 'p99': quantile(vals, .99), 'max': max(vals)}
    req = defaultdict(list)
    for r in rows:
        req[r['name']].append(r['kl_native_int8'])
    out['mean_per_request_kl'] = statistics.fmean(statistics.fmean(v) for v in req.values())
    return out

summary = {'checks': checks, 'aggregates': {}, 'per_request': {}}
for phase in ('native_repeat', 'int8_forced', 'int8_4096'):
    part = [r for r in metrics if r['phase'] == phase]
    selections = {'all': part, 'gsm': [r for r in part if r['group'].startswith('gsm_')],
                  'long': [r for r in part if r['group'].startswith('long_')]}
    for category in ('gsm', 'long'):
        selections[category+'_first'] = [r for r in selections[category] if r['step'] == 0]
        selections[category+'_decode'] = [r for r in selections[category] if r['step'] > 0]
        selections[category+'_pure_decode'] = [r for r in selections[category] if r['step'] > 0 and not r['mixed_decode']]
        selections[category+'_mixed_decode'] = [r for r in selections[category] if r['mixed_decode']]
    selections['gsm_confidence_below_90'] = [r for r in selections['gsm'] if r['native_top1_probability'] < .9]
    selections['gsm_confidence_at_least_90'] = [r for r in selections['gsm'] if r['native_top1_probability'] >= .9]
    selections['gsm_prior_3_errors'] = [r for r in selections['gsm'] if r['name'] in ['gsm_9', 'gsm_12', 'gsm_21']]
    selections['gsm_prior_other_61'] = [r for r in selections['gsm'] if r['name'] not in ['gsm_9', 'gsm_12', 'gsm_21']]
    selections.update({g: [r for r in part if r['group'] == g] for g in sorted({r['group'] for r in part if r['group'].startswith('long_')})})
    summary['aggregates'][phase] = {k: aggregate(v) for k,v in selections.items() if v}
    summary['per_request'][phase] = {n: aggregate([r for r in part if r['name']==n]) for n in sorted({r['name'] for r in part})}
summary['paired_request_kl_difference'] = {
    name: {'native_repeat_kl': control['kl_native_int8']['mean'],
           'int8_kl': summary['per_request']['int8_forced'][name]['kl_native_int8']['mean'],
           'difference': summary['per_request']['int8_forced'][name]['kl_native_int8']['mean']-control['kl_native_int8']['mean']}
    for name,control in summary['per_request']['native_repeat'].items()
    if name in summary['per_request']['int8_forced']}
summary['largest_kl'] = sorted([r for r in metrics if r['phase']=='int8_forced'], key=lambda r:r['kl_native_int8'], reverse=True)[:40]
summary['prior_errors_flips'] = [r for r in metrics if r['phase']=='int8_forced' and r['name'] in ['gsm_9','gsm_12','gsm_21'] and not r['top1_equal']]
(folder/'summary.json').write_text(json.dumps(summary, indent=2, ensure_ascii=False))
if metrics:
    with (folder/'positions.csv').open('w') as stream:
        writer = csv.DictWriter(stream, fieldnames=list(metrics[0]))
        writer.writeheader()
        writer.writerows(metrics)
print('phases',len(raw['results']),'positions',len(metrics),'schedule_match',all(c['same_schedule'] for c in checks))
for phase, groups in summary['aggregates'].items():
    for g in ('gsm','gsm_first','gsm_decode','long','long_first','long_8k','long_16k','long_32k','long_64k','long_8k_8k_8k_8k','long_32k_32k'):
        if g in groups:
            a=groups[g]
            print(phase,g,'N',a['positions'],'KL',a['kl_native_int8'],'JS',a['js']['mean'],'TV',a['tv']['mean'],'agree',a['top1_agreement'],'NLLdelta',a['mean_target_nll_delta'])
