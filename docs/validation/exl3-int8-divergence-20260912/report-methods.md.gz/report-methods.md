# EXL3 强制 INT8 全模型 logits 散度（2026-09-12）

## 测量范围与口径

模型为 GLM-5.3-Flash EXL3 4.05bpw，三张 CMP 170HX / SM80，固定 PP 16/15/14。
42 个 MoE 层分配为 13/15/14；TP=1、BF16、每 rank KV 2 GiB、prefix cache 关闭。
所有对照固定 scheduler chunk 6144，原生专家 workspace 2048、M=32；
普通投影 EXL3_INT8_GEMV=2，专家纯 decode 使用 plain INT8 GEMV，没有普通投影 FP16 缓存。
本次仅测散度，探针的同步和数据复制会改变耗时，不作为吞吐成绩。

64 道 GSM8K 使用上轮原生正确输出的全部 token 作为共同历史，分成 16 组、每组 4 题。
长输入使用上轮精确长度的访问码检索输入，覆盖 B1 8K/16K/32K/64K、B4 4×8K、B2 2×32K。
每个长请求仅回放到原生首次 EOS（包含 EOS），不把 EOS 后的无效继续生成算进来。
因此，长输入的长度指上下文长度，散度采样位置是其输出 token，并非全部输入位置。

每组在同一个已加载的模型上依次运行：原生参考、原生重复、强制 INT8。
长输入再运行 INT8 最小行数 4096 的对照。参考 logits 只在内存中保留一组，
比较完即释放；原始逐位置统计、输入/目标 token IDs、批次调度及各 rank 算子计数存档。

- 强制 INT8 把实际行数门槛设为 9，让短 GSM8K prefill 真正经过新算术；
  纯 decode 的 1–4 行仍经过原有专家 GEMV。4096 对照只用于长输入。
- 诊断使用 eager、compile mode 0、VLLM_TOKEN_BUCKET_PAD=0，方便请求结束后切换算术。
  关闭 bucket padding 是必要的：否则小 decode 会补成 16 行，越过人为降低的 9 行门槛。
  这与默认 CUDA Graph 服务配置不同，不应把本轮统计当作默认服务的逐位复现。
- 所有请求先在暂停的 scheduler 中排队，再一起唤醒；跨阶段逐项核对请求名、位置、
  该请求本步 token 数及批次请求数。prefix cache 命中为零，输出 IDs 必须与目标逐一相同。
- 在最后 PP rank 的原始 compute_logits 后采集全词表 logits，然后才把采样结果改成
  共同的下一 token。下一步实际经过正常 attention、KV cache 和 decode 内核。
  两边比较时看到相同的 token 历史，但隐藏状态/KV 中的数值差异保留。
- 长输入并发的混合批次可能把已有请求的 decode token 一并送进 prefill 内核。
  记录实际批次 token 数，并将其与纯 decode 分开；未宣称混合批次的 decode 算术不变。
- 原始 logits 是 BF16、词表 154880；在温度 1 下转 FP64 做完整 softmax 和归约。
  greedy 的 temperature=0 只控制输出采样，不把散度计算退化为 one-hot 分布。

令 P 为本组原生参考、Q 为当前阶段候选：KL(P||Q) = Σ P log(P/Q)，
JS = [KL(P||M)+KL(Q||M)]/2，M=(P+Q)/2，TV=Σ|P−Q|/2。
KL 和 JS 使用自然对数，单位 nats；TV 位于 [0,1]。
原始 JSON 的 kl_native_int8、kl_int8_native 分别对应正向/反向 KL；
在 native_repeat 阶段，候选 Q 是另一次原生运行。
Top-1 用 argmax，平局选择最小 token ID；统计实现用可解析的三项概率分布校验。

“沿原生输出轨迹”是固定历史的条件分布诊断，不是重新自由生成的 GSM8K 正确率，
也不是独立语料困惑度。少数检索题的长上下文散度不能代表完整长上下文能力评测。
