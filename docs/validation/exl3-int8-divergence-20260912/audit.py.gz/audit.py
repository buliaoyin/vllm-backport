import gzip,hashlib,json,math
from collections import Counter
from pathlib import Path

root=Path('/home/bul/dev/vllm-backport')
p=Path('/tmp/exl3-divergence-20260912')
data=json.loads((p/'results.json').read_text())
status=json.loads((p/'status.json').read_text())
assert status['exit_code']==0
assert len(data['results'])==sum(4 if name.startswith('long_') else 3 for name,_ in data['groups'])
for source,digest in data['sources'].items():
    assert hashlib.sha256(Path(source).read_bytes()).hexdigest()==digest
    frozen=gzip.decompress((p/(Path(source).name+'.gz')).read_bytes())
    assert hashlib.sha256(frozen).hexdigest()==digest
for source,info in json.loads((p/'provenance.json').read_text()).items():
    assert hashlib.sha256((root/source).read_bytes()).hexdigest()==info['sha256']
by_group={}
for name,rows in data['groups']:
    by_group[name]={r['name']:r for r in rows}
expected_layers=[13,15,14]
assert [len(r['layers']) for r in data['runtime']]==expected_layers
reference={}
aggregate=Counter()
for result in data['results']:
    group,phase=result['group'],result['phase']
    ranks=result['ranks']
    rows=by_group[group]
    expected={(name,step):r['targets'][step] for name,r in rows.items() for step in range(len(r['targets']))}
    if phase=='reference':
        assert ranks[-1]['reference_rows']==len(expected)
        reference[group]=result
    else:
        seen={}
        for m in ranks[-1]['metrics']:
            key=(m['name'],m['step'])
            assert key not in seen and expected[key]==m['target']
            seen[key]=m['target']
            assert all(math.isfinite(v) for v in m.values() if isinstance(v,(float,int)))
            assert m['kl_native_int8']>=-1e-10 and m['kl_int8_native']>=-1e-10
            assert -1e-10<=m['js']<=math.log(2)+1e-10
            assert 0<=m['tv']<=1 and 0<=m['native_top1_probability']<=1
            assert m['top1_equal']==(m['native_top1']==m['candidate_top1'])
        assert seen==expected
        assert ranks[-1]['schedule']==reference[group]['ranks'][-1]['schedule']
        aggregate[phase+'_positions']+=len(seen)
    for i,rank in enumerate(ranks):
        assert sum(rank['rows'].values())==sum(rank['calls'].values())
        assert all(v%expected_layers[i]==0 for v in rank['calls'].values())
        native_ref=reference[group]['ranks'][i]
        decode={k:v for k,v in rank['rows'].items() if k.startswith('decode_')}
        original_decode={k:v for k,v in native_ref['rows'].items() if k.startswith('decode_')}
        assert decode==original_decode
        assert rank['calls'].get('decode_int8',0)>0 and rank['calls'].get('decode_native',0)==0
        if phase in ['reference','native_repeat']:
            assert rank['calls'].get('int8',0)==0
        else:
            assert rank['calls'].get('int8',0)>0
            minimum=4096 if phase=='int8_4096' else 9
            assert all(int(k.split(':')[1])>=minimum for k in rank['rows'] if k.startswith('int8:'))
        aggregate[phase+'_rank'+str(i)+'_int8_calls']+=rank['calls'].get('int8',0)
        if phase=='native_repeat':
            assert rank['rows']==native_ref['rows']
report={'passed':True,'groups':len(by_group),'phases':len(data['results']),'aggregates':dict(aggregate),
        'checks':['complete position and target coverage','all schedules match reference','pure-decode row histograms match reference','all rank/layer arithmetic counters agree','INT8 minimum-row thresholds enforced','KL/JS/TV range and finiteness','executed sources and dependency hashes unchanged','successful benchmark exit']}
(p/'audit.json').write_text(json.dumps(report,indent=2))
print(json.dumps(report,indent=2))
