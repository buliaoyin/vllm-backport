import common
import torch
from tiles_launcher import Tiles
from vllm.model_executor.layers.quantization.exl3 import _extension
from benchmarks.kernels.benchmark_exl3_moe import fused_with_chunk
layer,method,k,n=common.load();sample=torch.load('/tmp/exl3-opt-20260910/routes/layer-22.pt',weights_only=True,map_location='cuda');ext=_extension()
x,w,ids=(sample[name][:512].contiguous() for name in ['x','weights','ids']);impl=Tiles(ext,common.ROOT/'tiles/tiles.so',32,32,256)
launch=impl.launch
def checked(fn,*args,**kwargs):
 print('LAUNCH',next((key for key,value in impl.functions.items() if value==fn),fn),flush=True)
 launch(fn,*args,**kwargs);torch.accelerator.synchronize();print('OK',flush=True)
impl.launch=checked;ext.exl3_moe=impl
with torch.inference_mode():
 out=fused_with_chunk((x,w,ids,method.ptrs,method.workspace,method.bits,method.flags,10.0),1024,longest_first=True)
 print(out.norm(),flush=True)
