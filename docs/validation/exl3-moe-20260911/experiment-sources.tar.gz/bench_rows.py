import os,sys,json,statistics,hashlib
from pathlib import Path
import common
import torch
from rows_launcher import Launcher
from vllm.model_executor.layers.quantization.exl3 import _extension
from benchmarks.kernels.benchmark_exl3_moe import fused_with_chunk
O=common.ROOT;out=O/(sys.argv[1] if len(sys.argv)>1 else 'rows64-layer22.json');layer_index=int(sys.argv[2]) if len(sys.argv)>2 else 22
layer,method,k,n=common.load(layer_index)
sample=torch.load(f'/tmp/exl3-opt-20260910/routes/layer-{layer_index}.pt',weights_only=True,map_location='cuda');ext=_extension();original=ext.exl3_moe
records=[];metadata={'gpu':torch.cuda.get_device_name(),'torch':str(torch.__version__),'layer':layer_index,'library_sha256':hashlib.sha256((O/'rows64/rows.so').read_bytes()).hexdigest(),'records':records}
with torch.inference_mode():
 for rows,chunk in [(512,1024),(1024,1024),(2048,1024),(2048,2048)]:
  x,w,ids=(sample[a][:rows].contiguous() for a in ['x','weights','ids'])
  ws=[t.new_empty(t.shape[0],chunk,t.shape[2]) for t in method.workspace];args=(x,w,ids,method.ptrs,ws,method.bits,method.flags,10.0)
  fn=lambda:fused_with_chunk(args,chunk,longest_first=True)
  ext.exl3_moe=Launcher(ext,O/'rows64/rows.so','m32_predicated');ref=fn()
  for variant in ['m32_predicated','m64','m64_k16','m64_n128','m32_k16','m32_n128','m32_predicated']:
   ext.exl3_moe=Launcher(ext,O/'rows64/rows.so',variant)
   y=fn();err=float((y.float()-ref.float()).norm()/ref.float().norm())
   r={'rows':rows,'chunk':chunk,'variant':variant,'relative_l2':err,'finite':bool(torch.isfinite(y).all())}
   records.append(r)
   if r['finite'] and err<0.003:
    times=common.graph_times(fn);r.update(median_ms=statistics.median(times),times_ms=times)
   else:r['rejected']='correctness'
   out.write_text(json.dumps(metadata,indent=2));print({a:b for a,b in r.items() if a!='times_ms'},flush=True)
 ext.exl3_moe=original
