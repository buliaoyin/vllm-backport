import subprocess,os,json,hashlib,re,time
from pathlib import Path
R=Path('/home/bul/dev/vllm-backport');O=Path('/tmp/exl3-moe-next-20260911');records=[]
def run(name,cmd,env=None):
 print('START',name,flush=True);rec={'name':name,'command':cmd,'start':time.time()};records.append(rec)
 with (O/f'{name}.log').open('w') as log:result=subprocess.run(cmd,cwd=R,env=env,stdout=log,stderr=subprocess.STDOUT)
 rec.update(exit_code=result.returncode,end=time.time());(O/'final-build-status.json').write_text(json.dumps(records,indent=2));print('DONE',name,result.returncode,flush=True)
 if result.returncode:raise SystemExit(result.returncode)
for name,script in [('rebuild-decode','build.py'),('rebuild-prefill','build_prefill.py')]:
 if not (O/name/'build.json').exists():
  run(name,[str(R/'.venv/bin/python'),str(R/'benchmarks/kernels/exl3_moe_decode'/script),'--source','/home/bul/dev/exllamav3','--build-dir',str(O/name),'--nvcc','/usr/local/cuda/bin/nvcc'],dict(os.environ,PYTHONPATH=str(R)))
