import json,subprocess,time
from pathlib import Path
R=Path('/home/bul/dev/vllm-backport');O=Path('/tmp/exl3-moe-next-20260911')
while True:
 state=json.loads((O/'safe-validation-status.json').read_text())
 if any(x.get('exit_code',0)!=0 for x in state):raise SystemExit(1)
 if state[-1]['name']=='final-benchmark-sm80' and state[-1].get('exit_code')==0:break
 time.sleep(5)
records=[]
for name in ['run_hybrid','run_chunk']:
 print('START',name,flush=True);record={'name':name,'start':time.time()};records.append(record)
 with (O/f'{name}-driver.log').open('w') as log:r=subprocess.run([str(R/'.venv/bin/python'),str(O/f'{name}.py')],cwd=R,stdout=log,stderr=subprocess.STDOUT)
 record.update(exit_code=r.returncode,end=time.time());(O/'after-safe-status.json').write_text(json.dumps(records,indent=2));print('DONE',name,r.returncode,flush=True)
 if r.returncode:raise SystemExit(r.returncode)
