import ctypes as ct
import torch
from benchmarks.kernels.exl3_m32.launcher import Dim3
class Tiles:
 def __init__(self,extension,library,tm=32,tk=16,tn=128):
  self.ext=extension;self.lib=ct.CDLL(str(library));self.cuda=ct.CDLL('libcudart.so.13');self.cuda.cudaGetErrorString.restype=ct.c_char_p
  self.tm,self.tk,self.tn=tm,tk,tn;self.functions={};self.buffers={}
  self.threads=256*tk//16
  frags=2*(tn//16)//8
  self.shared=3*(2*tm*tk+2*(tk//16)*(tn//16)*16*4)+16*256*frags*(tm//16)
  for name in [f'm{tm}_k{tk}_n{tn}',f'schedule{tm}','gather','activation','scatter']:
   f=getattr(self.lib,'exl3_tile_'+name);f.restype=ct.c_void_p;self.functions[name]=f()
  self.project=self.functions[f'm{tm}_k{tk}_n{tn}']
  self.check(self.cuda.cudaFuncSetAttribute(ct.c_void_p(self.project),8,self.shared))
  self.check(self.cuda.cudaFuncSetAttribute(ct.c_void_p(self.project),9,100))
  active=ct.c_int();self.check(self.cuda.cudaOccupancyMaxActiveBlocksPerMultiprocessor(ct.byref(active),ct.c_void_p(self.project),self.threads,self.shared));self.active=active.value
 def check(self,status):
  if status:raise RuntimeError(self.cuda.cudaGetErrorString(status).decode())
 def launch(self,fn,tensors,ints,grid,threads=256,shared=0,floats=()):
  values=[ct.c_void_p(t.data_ptr()) for t in tensors]+[ct.c_int(v) for v in ints]+[ct.c_float(v) for v in floats]
  args=(ct.c_void_p*len(values))(*(ct.addressof(v) for v in values))
  self.check(self.cuda.cudaLaunchKernel(ct.c_void_p(fn),Dim3(*grid),Dim3(threads,1,1),args,ct.c_size_t(shared),ct.c_void_p(torch.cuda.current_stream().cuda_stream)))
 def __call__(self,*args):
  hidden,output,counts,tokens,routing=args[:5];ws=args[5:9];bits=args[10:13];ptrs=args[13:22]
  assert tuple(bits)==(4,4,4) and tuple(args[22:28])==(False,True)*3 and args[9]==0
  E=counts.numel()-1;H=hidden.shape[1];N=ws[2].shape[-1];slots=tokens.numel()
  assert ws[0].numel()>=slots*H and ws[2].numel()>=slots*N
  key=(hidden.device,E)
  if key not in self.buffers:self.buffers[key]=torch.empty(2*(E+1),device=hidden.device,dtype=torch.int32)
  schedule=self.buffers[key];tiles=(slots+self.tm-1)//self.tm+E
  self.launch(self.functions[f'schedule{self.tm}'],[counts,schedule],[E],(1,1,1),512)
  self.launch(self.functions['gather'],[hidden,ws[0],ws[1],schedule,tokens,ptrs[1],ptrs[4]],[E,H],(4,1,E))
  self.launch(self.project,[ws[0],ws[1],ws[2],ws[3],ptrs[0],ptrs[3],schedule],[E,H,N],(tiles*(N//self.tn),1,2),self.threads,self.shared)
  self.launch(self.functions['activation'],[ws[2],ws[3],schedule,ptrs[2],ptrs[5],ptrs[7]],[E,N],(4,1,E),floats=(args[28],))
  self.launch(self.project,[ws[2],ws[2],ws[0],ws[0],ptrs[6],ptrs[6],schedule],[E,N,H],(tiles*(H//self.tn),1,1),self.threads,self.shared)
  self.launch(self.functions['scatter'],[ws[0],output,schedule,tokens,routing,ptrs[8]],[E,H],(4,1,E),shared=8*128*4)
