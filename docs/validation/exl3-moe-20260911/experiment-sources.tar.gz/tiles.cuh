#pragma once
#include "upstream/util.h"
#include "upstream/util.cuh"
#include "upstream/ptx.cuh"
#include "upstream/quant/exl3_moe_common.cuh"
#include "upstream/quant/exl3_kernel_map.cuh"
#include "upstream/quant/hadamard_inner.cuh"
#include "gemm_tile.cuh"

template<int TM>
__global__ void make_schedule(const int64_t* counts,int* schedule,int E) {
  __shared__ int a[512],b[512];
  int t=threadIdx.x;int count=t<E?(int)counts[t]:0;
  a[t]=count;b[t]=(count+TM-1)/TM;
  __syncthreads();
  for(int step=1;step<512;step*=2) {
    int x=t>=step?a[t-step]:0,y=t>=step?b[t-step]:0;
    __syncthreads();a[t]+=x;b[t]+=y;__syncthreads();
  }
  if(t<E){schedule[t+1]=a[t];schedule[E+2+t]=b[t];}
  if(t==0){schedule[0]=0;schedule[E+1]=0;}
}

__global__ void tile_gather(const half* hidden,half* gate,half* up,
    const int* schedule,const int64_t* tokens,const half* const* gate_suh,
    const half* const* up_suh,int E,int H) {
  int e=blockIdx.z,start=schedule[e],count=schedule[e+1]-start;
  int warp=threadIdx.x/32+blockIdx.x*(blockDim.x/32);
  int stride=gridDim.x*(blockDim.x/32),spans=H/128;
  for(int task=warp;task<count*spans;task+=stride) {
    int row=task/spans,col=(task%spans)*128,token=tokens[start+row];
    const half* input=hidden+token*H+col;
    had_hf_r_128_inner<true,false>(input,gate+(start+row)*H+col,gate_suh[e]+col,0.088388347648f);
    had_hf_r_128_inner<true,false>(input,up+(start+row)*H+col,up_suh[e]+col,0.088388347648f);
  }
}

template<int TM,int TK,int TN>
__global__ __launch_bounds__(256*TK/16)
void tile_project(const half* gate,const half* up,half* output_gate,half* output_up,
    const uint16_t* const* gate_weights,const uint16_t* const* up_weights,
    const int* schedule,int E,int K,int N) {
  int nt=blockIdx.x%(N/TN),tile=blockIdx.x/(N/TN);
  const int* tiles=schedule+E+1;
  if(tile>=tiles[E])return;
  int lo=0,hi=E;
  while(lo<hi){int mid=(lo+hi)/2;if(tiles[mid+1]<=tile)lo=mid+1;else hi=mid;}
  int e=lo,start=schedule[e],offset=(tile-tiles[e])*TM;
  int rows=min(schedule[e+1]-start-offset,TM);
  const half* input=blockIdx.z?up:gate;
  half* output=blockIdx.z?output_up:output_gate;
  const uint16_t* weights=blockIdx.z?up_weights[e]:gate_weights[e];
  exl3_gemm_tile_inner<4,false,2,TM,TK,TN,3,2,false,true>(
      input+(start+offset)*K,weights,output+(start+offset)*N,rows,K,N,nullptr,nullptr,nt);
}

__global__ void tile_activation(half* gate,const half* up,const int* schedule,
    const half* const* gate_svh,const half* const* up_svh,
    const half* const* down_suh,int E,int N,float limit) {
  int e=blockIdx.z,start=schedule[e],count=schedule[e+1]-start;
  int warp=threadIdx.x/32+blockIdx.x*(blockDim.x/32),stride=gridDim.x*(blockDim.x/32),spans=N/128;
  for(int task=warp;task<count*spans;task+=stride) {
    int row=start+task/spans,col=(task%spans)*128;
    had_hf_r_128_guad_inner(gate+row*N+col,up+row*N+col,gate+row*N+col,
      gate_svh[e]+col,up_svh[e]+col,down_suh[e]+col,0.088388347648f,limit,0);
  }
}

__global__ void tile_scatter(const half* down,float* output,const int* schedule,
    const int64_t* tokens,const half* routing,const half* const* svh,int E,int H) {
  int e=blockIdx.z,start=schedule[e],count=schedule[e+1]-start;
  int warp=threadIdx.x/32+blockIdx.x*(blockDim.x/32),stride=gridDim.x*(blockDim.x/32),spans=H/128;
  for(int task=warp;task<count*spans;task+=stride) {
    int row=start+task/spans,col=(task%spans)*128,token=tokens[row];
    had_hf_r_128_d_inner(down+row*H+col,output+token*H+col,svh[e]+col,
      0.088388347648f*__half2float(routing[row]));
  }
}
