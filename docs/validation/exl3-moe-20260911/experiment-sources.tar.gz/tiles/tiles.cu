#include "tiles.cuh"
extern "C" void* exl3_tile_m32_k32_n256() { return (void*)tile_project<32,32,256>; }
extern "C" void* exl3_tile_m32_k16_n256() { return (void*)tile_project<32,16,256>; }
extern "C" void* exl3_tile_m32_k16_n128() { return (void*)tile_project<32,16,128>; }
extern "C" void* exl3_tile_m64_k16_n128() { return (void*)tile_project<64,16,128>; }
extern "C" void* exl3_tile_m64_k32_n128() { return (void*)tile_project<64,32,128>; }
extern "C" void* exl3_tile_schedule32() { return (void*)make_schedule<32>; }
extern "C" void* exl3_tile_schedule64() { return (void*)make_schedule<64>; }
extern "C" void* exl3_tile_gather() { return (void*)tile_gather; }
extern "C" void* exl3_tile_activation() { return (void*)tile_activation; }
extern "C" void* exl3_tile_scatter() { return (void*)tile_scatter; }
