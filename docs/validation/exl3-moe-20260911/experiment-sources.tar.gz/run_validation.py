import os,subprocess,json,time
from pathlib import Path
R=Path('/home/bul/dev/vllm-backport');O=Path('/tmp/exl3-moe-next-20260911');records=[]
baseenv=dict(os.environ,OMP_NUM_THREADS='1',CUDA_DEVICE_ORDER='PCI_BUS_ID',VLLM_EXL3_TEST_DECODE_LIBRARY=str(O/'final-decode/decode.so'),VLLM_EXL3_TEST_PIPELINE_LIBRARY=str(O/'pipeline/pipeline.so'),VLLM_EXL3_TEST_ROWS_LIBRARY=str(O/'rows64/rows.so'),VLLM_EXL3_TEST_INT8_LIBRARY='/tmp/exl3-int8-20260911/final-v9/int8.so')
for name,gpu,select,tool in [
 ('tests-sm80','0','',None),('tests-sm120','3','experimental_expert_int8_decode',None),
 ('memcheck-decode','0','experimental_expert_int8_decode','memcheck'),
 ('racecheck-pipeline','0','experimental_moe_pipeline and nobar and 33','racecheck')]:
 cmd=[str(R/'.venv/bin/python'),'-m','pytest','tests/quantization/test_exl3.py','-q']
 if select:cmd+=['-k',select]
 if tool:cmd=['/usr/local/cuda/bin/compute-sanitizer','--tool',tool,'--error-exitcode','99','--target-processes','all',*cmd]
 print('START',name,flush=True);rec={'name':name,'command':cmd,'start':time.time()};records.append(rec)
 with (O/f'{name}.log').open('w') as log:result=subprocess.run(cmd,cwd=R,env=dict(baseenv,CUDA_VISIBLE_DEVICES=gpu),stdout=log,stderr=subprocess.STDOUT)
 rec.update(exit_code=result.returncode,end=time.time());(O/'validation-status.json').write_text(json.dumps(records,indent=2));print('DONE',name,result.returncode,flush=True)
 if result.returncode:raise SystemExit(result.returncode)
