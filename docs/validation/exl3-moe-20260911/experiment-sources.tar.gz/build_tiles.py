import hashlib,json,shutil,subprocess
from pathlib import Path
O=Path('/tmp/exl3-moe-next-20260911');out=O/'tiles';out.mkdir(exist_ok=True);base=O/'rows64'
shutil.copytree(base/'upstream',out/'upstream',dirs_exist_ok=True)
s=(base/'gemm_next.cuh').read_text().replace('exl3_gemm_rows_next_inner','exl3_gemm_tile_inner').replace('const half* post_scale\n','const half* post_scale, const int tile_n\n')
a=s.index('    int num_slices = gridDim.x;');b=s.index('\n    auto index_m',a)
s=s[:a]+'''    int slice_beg=tile_n*tiles_k;
    int slice_end=(tile_n+1)*tiles_k;
    int slice_len=tiles_k;
'''+s[b:]
a=s.index('        // Process (partial) slices');b=s.index('        clear_frag_c();',a)
s=s[:a]+'''        if (!sub_k) write_sum_gl();
'''+s[b:]
(out/'gemm_tile.cuh').write_text(s);shutil.copyfile(O/'tiles.cuh',out/'tiles.cuh')
code='#include "tiles.cuh"\n'
for tm,tk,tn in [(32,32,256),(32,16,256),(32,16,128),(64,16,128),(64,32,128)]:code+=f'extern "C" void* exl3_tile_m{tm}_k{tk}_n{tn}() {{ return (void*)tile_project<{tm},{tk},{tn}>; }}\n'
for tm in [32,64]:code+=f'extern "C" void* exl3_tile_schedule{tm}() {{ return (void*)make_schedule<{tm}>; }}\n'
for name in ['gather','activation','scatter']:code+=f'extern "C" void* exl3_tile_{name}() {{ return (void*)tile_{name}; }}\n'
(out/'tiles.cu').write_text(code)
meta=json.loads((base/'build.json').read_text());cmd=[v.replace(str(base),str(out)).replace('/rows.cu','/tiles.cu').replace('/rows.so','/tiles.so') for v in meta['command']]
meta.update(command=cmd,experiment_sha256={p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in [out/'gemm_tile.cuh',out/'tiles.cuh',out/'tiles.cu',Path(__file__)]})
(out/'build.json').write_text(json.dumps(meta,indent=2))
with (out/'build.log').open('w') as log:subprocess.run(cmd,stdout=log,stderr=subprocess.STDOUT,check=True)
meta['library_sha256']=hashlib.sha256((out/'tiles.so').read_bytes()).hexdigest();(out/'build.json').write_text(json.dumps(meta,indent=2));print(out/'tiles.so')
