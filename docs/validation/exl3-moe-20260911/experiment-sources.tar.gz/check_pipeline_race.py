import runpy,pytest,torch,json,os
from pathlib import Path
from diagnostic_launcher import Launcher
from vllm.model_executor.layers.quantization.exl3 import _extension
O=Path('/tmp/exl3-moe-next-20260911')
check=runpy.run_path('/home/bul/dev/vllm-backport/tests/quantization/test_exl3.py')['_check_moe_routing']
variant=os.environ.get('EXL3_RACE_VARIANT','nobar_m32_k32_n256')
library=os.environ.get('EXL3_RACE_LIBRARY',str(O/'pipeline/sanitizer-sm120.so'))
result={'library':library,'variant':variant,'diagnostic_only':True,'gpu':torch.cuda.get_device_name(),'capability':torch.cuda.get_device_capability(),'rows':[]}
for rows in [33,513]:
 with pytest.MonkeyPatch.context() as mp:
  ext=_extension();mp.setattr(ext,'exl3_moe',Launcher(ext,library,variant))
  check(rows,1024,256,mp)
 result['rows'].append(rows)
 print('PASSED',rows,flush=True)
(O/os.environ.get('EXL3_RACE_RESULT',f'racecheck-sm120-{variant}-result.json')).write_text(json.dumps(result,indent=2))
