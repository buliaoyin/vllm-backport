import os,subprocess,time,json
from pathlib import Path
O=Path('/tmp/exl3-moe-next-20260911');python='/home/bul/dev/vllm-backport/.venv/bin/python';records=[]
for name,script,args,gpu in [('tiles-layer22','bench_tiles.py',[],0),('decode-sm120-layer22','bench_decode.py',['decode-sm120-layer22.json','22'],3),('decode-sm80-layer3','bench_decode.py',['decode-sm80-layer3.json','3'],1)]:
 env={**os.environ,'CUDA_DEVICE_ORDER':'PCI_BUS_ID','CUDA_VISIBLE_DEVICES':str(gpu),'EXL3_INT8_GEMV':'0','OMP_NUM_THREADS':'1'}
 cmd=[python,str(O/script),*args];r={'name':name,'command':cmd,'gpu':gpu,'start':time.time()};records.append(r);(O/'micro-status.json').write_text(json.dumps(records,indent=2))
 with (O/(name+'.log')).open('w') as log:p=subprocess.run(cmd,env=env,stdout=log,stderr=subprocess.STDOUT)
 r.update(exit_code=p.returncode,end=time.time());(O/'micro-status.json').write_text(json.dumps(records,indent=2))
 print(name,p.returncode,flush=True)
