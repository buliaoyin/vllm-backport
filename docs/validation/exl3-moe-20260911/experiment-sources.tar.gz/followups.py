import json,subprocess,time
from pathlib import Path
R=Path('/home/bul/dev/vllm-backport');O=Path('/tmp/exl3-moe-next-20260911')
while True:
 state=json.loads((O/'model-status.json').read_text())
 if state[-1]['mode']=='residual' and 'exit_code' in state[-1]:
  if state[-1]['exit_code']:raise SystemExit(state[-1]['exit_code'])
  break
 time.sleep(5)
records=[]
for name in ['final_validation','run_hybrid','run_chunk']:
 print('START',name,flush=True);rec={'script':name,'start':time.time()};records.append(rec)
 with (O/f'{name}-driver.log').open('w') as log:r=subprocess.run([str(R/'.venv/bin/python'),str(O/f'{name}.py')],cwd=R,stdout=log,stderr=subprocess.STDOUT)
 rec.update(exit_code=r.returncode,end=time.time());(O/'followups-status.json').write_text(json.dumps(records,indent=2));print('DONE',name,r.returncode,flush=True)
 if r.returncode:raise SystemExit(r.returncode)
