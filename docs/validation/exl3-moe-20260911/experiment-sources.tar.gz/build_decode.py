import hashlib,json,shutil,subprocess
from pathlib import Path
O=Path('/tmp/exl3-moe-next-20260911');out=O/'decode';out.mkdir(exist_ok=True)
base=O/'rows64';shutil.copytree(base/'upstream',out/'upstream',dirs_exist_ok=True)
s=(out/'upstream/quant/exl3_gemv_int8_kernel.cuh').read_text()
start=s.index('template <int bits, int M, bool c_fp32, bool residual>\n__global__ __launch_bounds__(NUM_THREADS)\nvoid exl3_gemv_int8_sq_kernel')
end=s.index('// ---------------------------------------------------------------------------------------------------------',start)
body=s[start:end];head,body=body.split('\n{\n',1)
head='''template <bool c_fp32, bool residual>
__global__ __launch_bounds__(NUM_THREADS)
void exl3_expert_gemv(const half* inputs, const uint16_t* const* trellis,
    void* outputs, const half* const* input_scales, const half* const* output_scales,
    const int64_t* ids, int* workspace, int size_k, int size_n,
    int top_k, int input_group, int workspace_stride)
'''
intro='''{
    constexpr int bits=4, M=1;
    const int slot=blockIdx.z;
    const int expert=ids[slot];
    const half* A=inputs+(slot/input_group)*size_k;
    const uint16_t* B=trellis[expert];
    const half* suh=input_scales[expert];
    const half* svh=output_scales[expert];
    void* C= c_fp32 ? (void*)((float*)outputs+slot*size_n) : (void*)((half*)outputs+slot*size_n);
    int* locks=workspace+slot*workspace_stride;
    const int size_m=1;
'''
code='#include "upstream/quant/exl3_gemv_int8_kernel.cuh"\n'+head+intro+body
code+='''
__global__ void exl3_expert_combine(const float* input, const half* weights,
    __nv_bfloat16* output, int rows, int top_k, int hidden) {
    int i=blockIdx.x*blockDim.x+threadIdx.x;
    if(i>=rows*hidden)return;
    int row=i/hidden,col=i%hidden;float value=0.f;
    for(int j=0;j<top_k;++j)value+=input[(row*top_k+j)*hidden+col]*__half2float(weights[row*top_k+j]);
    output[i]=__float2bfloat16_rn(value);
}
'''
for name,params in [('plain_half','false,false'),('plain_float','true,false'),('residual_half','false,true'),('residual_float','true,true')]:code+=f'extern "C" void* exl3_decode_{name}() {{ return (void*)exl3_expert_gemv<{params}>; }}\n'
code+='extern "C" void* exl3_decode_combine() { return (void*)exl3_expert_combine; }\n'
(out/'decode.cu').write_text(code)
meta=json.loads((base/'build.json').read_text());cmd=[v.replace(str(base),str(out)).replace('/rows.cu','/decode.cu').replace('/rows.so','/decode.so') for v in meta['command']]
cmd.insert(cmd.index('-I'+str(out)),'-gencode=arch=compute_120,code=sm_120')
meta.update(command=cmd,experiment_sha256={p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in [out/'decode.cu',Path(__file__)]})
(out/'build.json').write_text(json.dumps(meta,indent=2))
with (out/'build.log').open('w') as log:subprocess.run(cmd,stdout=log,stderr=subprocess.STDOUT,check=True)
meta['library_sha256']=hashlib.sha256((out/'decode.so').read_bytes()).hexdigest();(out/'build.json').write_text(json.dumps(meta,indent=2));print(out/'decode.so')
