import json,gzip,hashlib,tarfile,io
from pathlib import Path
O=Path('/tmp/exl3-moe-next-20260911');R=Path('/home/bul/dev/vllm-backport');D=R/'docs/validation/exl3-moe-20260911';D.mkdir(exist_ok=True)
for path in O.iterdir():
 if not path.is_file() or path.suffix not in ('.json','.gz','.log','.csv'):continue
 if path.name.startswith(('debug-','precommit')) and 'final' not in path.name:continue
 raw=path.read_bytes();name=path.name
 if path.suffix=='.log' or path.name.endswith('-model.json'):
  raw=gzip.compress(raw,mtime=0);name+='.gz'
 (D/name).write_bytes(raw)
for family in ['rows64','pipeline','tiles','decode','final-decode','rebuild-prefill','rebuild-decode','safe-prefill']:
 folder=O/family
 if not folder.exists():continue
 target=D/family;target.mkdir(exist_ok=True)
 for name in ['build.json','build.log']:
  path=folder/name
  if path.exists():(target/(name+'.gz' if name.endswith('.log') else name)).write_bytes(gzip.compress(path.read_bytes(),mtime=0) if name.endswith('.log') else path.read_bytes())
source_files=[p for p in O.glob('*') if p.is_file() and p.suffix in ('.py','.cuh')]
for family in ['rows64','pipeline','tiles','decode','final-decode','safe-prefill']:
 source_files += [p for p in (O/family).glob('*') if p.is_file() and p.suffix in ('.cu','.cuh')]
source_files.append(O/'safe-prefill/upstream/quant/hadamard_inner.cuh')
with (D/'experiment-sources.tar.gz').open('wb') as f:
 with gzip.GzipFile(filename='',mode='wb',fileobj=f,mtime=0) as z:
  with tarfile.open(fileobj=z,mode='w') as archive:
   for path in sorted(source_files):
    contents=path.read_bytes();info=tarfile.TarInfo(str(path.relative_to(O)));info.size=len(contents);info.mtime=0;info.mode=0o644;archive.addfile(info,io.BytesIO(contents))
(D/'LICENSE-exllamav3').write_bytes((R/'benchmarks/kernels/exl3_moe_decode/LICENSE-exllamav3').read_bytes())
manifest={str(p.relative_to(D)):{'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'bytes':p.stat().st_size} for p in sorted(D.rglob('*')) if p.is_file() and p.name!='manifest.json'}
(D/'manifest.json').write_text(json.dumps(manifest,indent=2));print(len(manifest),'files',round(sum(v['bytes'] for v in manifest.values())/2**20,2),'MiB')
