import hashlib,json,shutil,subprocess
from pathlib import Path
O=Path('/tmp/exl3-moe-next-20260911');base=O/'rows64';out=O/'pipeline';out.mkdir(exist_ok=True)
shutil.copytree(base/'upstream',out/'upstream',dirs_exist_ok=True)
code='';variants={}
for family,nosync,nolock,hacc in [('base',False,False,False),('nobar',True,False,False),('nolock',False,True,False),('both',True,True,False),('half',True,True,True)]:
 g=(base/'gemm_next.cuh').read_text().replace('exl3_gemm_rows_next_inner',f'exl3_gemm_{family}_inner')
 if nosync:
  before='        __syncthreads();\n        advance1();';assert g.count(before)==1;g=g.replace(before,'        advance1();')
 if nolock:
  g=g.replace('        barrier_acquire(lock, lock_i);','        if (tiles_n % gridDim.x != 0) barrier_acquire(lock, lock_i);')
  g=g.replace('        barrier_release(lock, lock_d, last);','        if (tiles_n % gridDim.x != 0) barrier_release(lock, lock_d, last);')
 if hacc:g=g.replace('#if defined(__CUDA_ARCH__) && (__CUDA_ARCH__ == 860)','#if defined(__CUDA_ARCH__)')
 (out/f'gemm_{family}.cuh').write_text(g)
 m=(base/'moe_next.cuh').read_text().replace('"gemm_next.cuh"',f'"gemm_{family}.cuh"').replace('exl3_gemm_rows_next_inner',f'exl3_gemm_{family}_inner').replace('exl3_moe_rows_next_kernel',f'exl3_moe_{family}_kernel')
 (out/f'moe_{family}.cuh').write_text(m);code+=f'#include "moe_{family}.cuh"\n'
 options=[(32,32,256)] if not hacc else [(32,32,256),(64,32,256),(64,16,256),(64,32,128)]
 for tm,tk,tn in options:
  name=f'{family}_m{tm}_k{tk}_n{tn}';variants[name]=[tm,tk,tn];code+=f'extern "C" void* exl3_rows_{name}() {{ return (void*)exl3_moe_{family}_kernel<4,{tn},2,2,{tm},{tk},true>; }}\n'
(out/'pipeline.cu').write_text(code)
meta=json.loads((base/'build.json').read_text());cmd=[v.replace(str(base),str(out)).replace('/rows.cu','/pipeline.cu').replace('/rows.so','/pipeline.so') for v in meta['command']]
meta.update(command=cmd,variants=variants,experiment_sha256={p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in [*out.glob('*.cuh'),out/'pipeline.cu',Path(__file__)]})
(out/'build.json').write_text(json.dumps(meta,indent=2))
with (out/'build.log').open('w') as log:subprocess.run(cmd,stdout=log,stderr=subprocess.STDOUT,check=True)
meta['library_sha256']=hashlib.sha256((out/'pipeline.so').read_bytes()).hexdigest();(out/'build.json').write_text(json.dumps(meta,indent=2));print(out/'pipeline.so')
