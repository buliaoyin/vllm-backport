import collections
import gzip
import hashlib
import json
from pathlib import Path

O = Path('/tmp/exl3-moe-next-20260911')
full = json.loads(gzip.decompress((O / 'model-inputs.json.gz').read_bytes()))
long = json.loads(gzip.decompress((O / 'long-inputs.json.gz').read_bytes()))
cases = {c['name']: c for c in full['cases']}
assert all(c == cases[c['name']] for c in long['cases'])
assert long['evals'] == full['evals']
expected_layers = [list(range(0, 11)), list(range(11, 22)), list(range(22, 33)), list(range(33, 45))]
safe_sha = hashlib.sha256((O / 'safe-prefill/pipeline.so').read_bytes()).hexdigest()
decode_sha = hashlib.sha256((O / 'final-decode/decode.so').read_bytes()).hexdigest()
result = {'long_inputs_equal': True, 'quality_inputs_equal': True, 'models': {}}
for name in ('native', 'plain', 'residual', 'hybrid', 'hybrid-c2048'):
    d = json.loads((O / f'{name}-model.json').read_text())
    a = d['args']
    assert a['kv_cache_gib'] == 8 and a['max_model_len'] == 66560
    assert a['chunk_size'] == (2048 if name.endswith('c2048') else 1024)
    assert d['inputs_sha256'] == hashlib.sha256(Path(a['inputs']).read_bytes()).hexdigest()
    assert d['environment']['EXL3_INT8_GEMV'] == '0'
    assert d['environment']['VLLM_PP_LAYER_PARTITION'] == '11,11,11,12'
    for field in ('runtime_before', 'runtime_after'):
        states = sorted(d[field], key=lambda s: s['pp_rank'])
        assert [s['pp_rank'] for s in states] == [0, 1, 2, 3]
        assert [[r['index'] for r in s['decoder_layers']] for s in states] == expected_layers
        if name.startswith('hybrid'):
            assert [s['expert_decode']['activation_mode'] for s in states] == ['plain'] * 3 + ['residual']
            assert all(s['expert_decode']['sha256'] == decode_sha for s in states)
    if name.startswith('hybrid'):
        assert len(d['workspace_sweep']) == 1
        sweep = d['workspace_sweep'][0]
        assert [s['expert_layers'] for s in sweep] == [8, 11, 11, 12]
        assert all(s['row_kernel']['sha256'] == safe_sha for s in sweep[:3])
        assert sweep[3]['row_kernel'] == 'native'
        assert all(s['capacity'] == a['chunk_size'] for s in sweep)
    groups = collections.defaultdict(list)
    checks = 0
    for p in d['perf']:
        groups[(p['variant']['name'], p['case'])].append(p['repeat'])
        c = cases[p['case']]
        assert len(p['rows']) == len(c['inputs'])
        for r, ids in zip(p['rows'], c['inputs']):
            assert r['prompt_tokens'] == len(ids)
            assert r['new_tokens'] == (32 if len(ids) >= 8192 else 128)
            assert r['cached_tokens'] == 0
        assert all(c['matched'] for c in p.get('checks', []))
        checks += len(p.get('checks', []))
    assert all(sorted(g) == [0, 1, 2] for g in groups.values())
    eval_groups = collections.defaultdict(list)
    for r in d['eval']:
        eval_groups[r['variant']].append(r)
    assert all(len(g) == 64 for g in eval_groups.values())
    result['models'][name] = {'performance_groups': len(groups), 'repeats_per_group': 3, 'long_checks_passed': checks, 'long_checks_total': checks, 'cached_tokens': 0, 'actual_layer_counts': [11, 11, 11, 12], 'model_library_checks_passed': True, 'quality': {v: {'correct': sum(r['correct'] for r in rs), 'total': len(rs)} for v, rs in eval_groups.items()}}
for name in ('safe-validation-status.json', 'after-safe-status.json', 'hybrid-c2048-status.json'):
    data = json.loads((O / name).read_text())
    assert data and all(r['exit_code'] == 0 for r in data)
result['all_assertions_passed'] = True
(O / 'final-data-audit.json').write_text(json.dumps(result, indent=2))
print(json.dumps(result, indent=2))
