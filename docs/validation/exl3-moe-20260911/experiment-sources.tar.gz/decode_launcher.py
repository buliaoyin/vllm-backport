import ctypes as ct
from pathlib import Path
import torch
from benchmarks.kernels.exl3_m32.launcher import Dim3
class Decode:
 def __init__(self,extension,library,residual=False,grid=16):
  self.ext=extension;self.lib=ct.CDLL(str(library));self.cuda=ct.CDLL('libcudart.so.13');self.cuda.cudaGetErrorString.restype=ct.c_char_p
  self.residual=residual;self.grid=grid;self.functions={};self.buffers={}
  for name in [('residual' if residual else 'plain')+'_half',('residual' if residual else 'plain')+'_float','combine']:
   f=getattr(self.lib,'exl3_decode_'+name);f.restype=ct.c_void_p;self.functions[name]=f()
   if name!='combine':
    self.check(self.cuda.cudaFuncSetAttribute(ct.c_void_p(self.functions[name]),8,90*1024))
    self.check(self.cuda.cudaFuncSetAttribute(ct.c_void_p(self.functions[name]),9,100))
 def check(self,status):
  if status:raise RuntimeError(self.cuda.cudaGetErrorString(status).decode())
 def launch(self,kernel,tensors,ints,grid,threads,shared):
  values=[ct.c_void_p(t.data_ptr()) for t in tensors]+[ct.c_int(v) for v in ints]
  args=(ct.c_void_p*len(values))(*(ct.addressof(v) for v in values))
  self.check(self.cuda.cudaLaunchKernel(ct.c_void_p(kernel),Dim3(*grid),Dim3(threads,1,1),args,ct.c_size_t(shared),ct.c_void_p(torch.cuda.current_stream().cuda_stream)))
 def project(self,x,ptrs,ids,output,input_group):
  slots=ids.numel();k=x.shape[-1];n=output.shape[-1];rows=k//16;r=(rows*(n//256)+self.grid-1)//self.grid
  rows_max=min(512,((80*1024)//(32+64*(2 if self.residual else 1)))&~7)
  per=min(max((max(r,min(2*r,32))+7)&~7,16),rows_max,(rows+7)&~7)
  split=(rows+per-1)//per;stride=5120+split*n*(2 if self.residual else 1)
  key=(x.device,slots,stride)
  if key not in self.buffers:self.buffers[key]=torch.zeros(slots*stride,device=x.device,dtype=torch.int32)
  workspace=self.buffers[key];shared=per*(32+64*(2 if self.residual else 1))+1024
  kernel=self.functions[('residual' if self.residual else 'plain')+('_float' if output.dtype==torch.float32 else '_half')]
  self.launch(kernel,[x,ptrs[0],output,ptrs[1],ptrs[2],ids,workspace],[k,n,8,input_group,stride],(self.grid,1,slots),256,shared)
 def __call__(self,x,weights,ids,ptrs,workspace,bits,flags,limit):
  assert bits==[4,4,4] and flags==[False,True]*3
  assert x.dtype==torch.bfloat16
  rows,k=x.shape;topk=ids.shape[1];n=workspace[2].shape[-1];slots=rows*topk
  hidden=x.to(torch.float16).contiguous();indices=ids.to(torch.int64).contiguous().flatten();routing=weights.to(torch.float16).contiguous().flatten()
  gate=torch.empty((slots,n),dtype=torch.float16,device=x.device);up=torch.empty_like(gate);activated=torch.empty_like(gate)
  self.project(hidden,ptrs[:3],indices,gate,topk);self.project(hidden,ptrs[3:6],indices,up,topk)
  self.ext.silu_mul(gate,up,activated,limit)
  down=torch.empty((slots,k),dtype=torch.float32,device=x.device);self.project(activated,ptrs[6:9],indices,down,1)
  output=torch.empty_like(x);self.launch(self.functions['combine'],[down,routing,output],[rows,topk,k],((rows*k+255)//256,1,1),256,0)
  return output
