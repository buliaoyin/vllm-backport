import json,statistics,collections
from pathlib import Path
O=Path('/tmp/exl3-moe-next-20260911');R=Path('/home/bul/dev/vllm-backport');summary={}
def aggregate(data,filterfn):
 groups=collections.defaultdict(list)
 for r in data['perf']:
  if filterfn(r):groups[r['case']].append(r)
 return {case:{'input_tps':statistics.median(sum(z['prompt_tokens'] for z in r['rows'])/r['max_ttft'] for r in rs),'output_tps':statistics.median(sum(z['new_tokens']-1 for z in r['rows'])/max(z['decode'] for z in r['rows']) for r in rs),'ttft':statistics.median(r['max_ttft'] for r in rs),'repeats':len(rs)} for case,rs in groups.items()}
for name in ['native','plain','residual','hybrid','hybrid-c2048']:
 p=O/f'{name}-model.json'
 if not p.exists():continue
 d=json.loads(p.read_text());summary[name]=aggregate(d,lambda r:name!='native' or r['variant']['name'] in ['m32_before','m32_after'])
for fmt in ['awq','nvfp4']:
 d=json.loads((R/f'docs/validation/exl3-fixed-pp-20260910/{fmt}-long-pp11-11-11-12-c1024.json').read_text());summary[fmt]=aggregate(d,lambda r:True)
quality={}
a=json.loads((O/'native-model.json').read_text());reference={r['id']:r for r in a['eval'] if r['variant']=='m32_before'}
for name in ['native','plain','residual','hybrid','hybrid-c2048']:
 p=O/f'{name}-model.json'
 if not p.exists():continue
 d=json.loads(p.read_text());groups=collections.defaultdict(list)
 for r in d['eval']:groups[r['variant']].append(r)
 for variant,rs in groups.items():
  quality[name+'/'+variant]={'total':len(rs),'correct':sum(r['correct'] for r in rs),'same_answers':sum(r['predicted']==reference[r['id']]['predicted'] for r in rs),'same_tokens':sum(r['token_ids']==reference[r['id']]['token_ids'] for r in rs),'new_errors': [r['id'] for r in rs if not r['correct'] and reference[r['id']]['correct']], 'unfinished':sum(r['finish_reason']=='length' for r in rs)}
(O/'final-comparison.json').write_text(json.dumps({'throughput':summary,'quality':quality},indent=2))
for mode,d in summary.items():
 print(mode)
 for name,row in d.items():print(name,row['repeats'],round(row['input_tps'],2),round(row['output_tps'],2))
print('QUALITY',quality)
