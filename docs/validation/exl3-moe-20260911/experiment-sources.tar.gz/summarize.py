import json,statistics,collections,gzip
from pathlib import Path
O=Path('/tmp/exl3-moe-next-20260911');R=Path('/home/bul/dev/vllm-backport')
summary={'micro':{},'models':{},'historical':{}}
for name in ['rows64-layer22','pipeline-layer22','tiles-layer22','decode-sm80-layer22','decode-sm80-layer3','decode-sm120-layer22','safe-prefill-layer22','final-benchmark-sm80']:
 d=json.loads((O/f'{name}.json').read_text());summary['micro'][name]={'gpu':d['gpu'],'layer':d.get('layer'), 'records':[{k:v for k,v in r.items() if k!='times_ms'} for r in d['records']]}
for path in O.glob('*-model.json'):
 d=json.loads(path.read_text());groups=collections.defaultdict(list)
 for r in d['perf']:groups[(r['variant']['name'],r['case'])].append(r)
 measures=[]
 for (variant,case),rs in groups.items():
  def stats(fn):
   values=[fn(r) for r in rs];return {'median':statistics.median(values),'min':min(values),'max':max(values)}
  measure={'variant':variant,'case':case,'repeats':len(rs),'input_tps':stats(lambda r:sum(z['prompt_tokens'] for z in r['rows'])/r['max_ttft']), 'ttft':stats(lambda r:r['max_ttft']), 'output_tps':stats(lambda r:sum(z['new_tokens']-1 for z in r['rows'])/max(z['decode'] for z in r['rows'])), 'end_to_end_output_tps':stats(lambda r:r['throughput']),'checks':sum(c['matched'] for r in rs for c in r.get('checks',[])), 'checks_total':sum(len(r.get('checks',[])) for r in rs),'cached_tokens':sum(z['cached_tokens'] for r in rs for z in r['rows'])}
  measures.append(measure)
 evals=collections.defaultdict(list)
 for r in d['eval']:evals[r['variant']].append(r)
 summary['models'][path.stem]={'perf':measures,'eval':{v:{'correct':sum(r['correct'] for r in rs),'total':len(rs),'unfinished':sum(r['finish_reason']=='length' for r in rs)} for v,rs in evals.items()},'runtime_before':d['runtime_before'],'args':d['args']}
for format in ['awq','nvfp4']:
 p=R/f'docs/validation/exl3-fixed-pp-20260910/{format}-long-pp11-11-11-12-c1024.json';d=json.loads(p.read_text());groups=collections.defaultdict(list)
 for r in d['perf']:groups[r['case']].append(r)
 summary['historical'][format]=[{'case':case,'input_tps':statistics.median(r['rows'][0]['prompt_tokens']/r['max_ttft'] for r in rs),'output_tps':statistics.median((r['rows'][0]['new_tokens']-1)/r['rows'][0]['decode'] for r in rs),'ttft':statistics.median(r['max_ttft'] for r in rs)} for case,rs in groups.items()]
(O/'summary.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2))
for mode,d in summary['models'].items():
 print(mode,d['eval'])
 for r in d['perf']:print(r['variant'],r['case'],r['repeats'],round(r['input_tps']['median'],2),round(r['output_tps']['median'],2))
