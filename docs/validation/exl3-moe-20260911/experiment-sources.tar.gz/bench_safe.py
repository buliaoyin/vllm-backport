import common
from pathlib import Path
import sys,json,statistics,hashlib
import torch
from pipeline_launcher import Launcher as Pipeline
from vllm.model_executor.layers.quantization.exl3 import _extension
from benchmarks.kernels.exl3_m32.launcher import Launcher
from benchmarks.kernels.benchmark_exl3_moe import fused_with_chunk
O=common.ROOT;out=O/(sys.argv[1] if len(sys.argv)>1 else 'safe-prefill-layer22.json');index=int(sys.argv[2]) if len(sys.argv)>2 else 22
layer,method,k,n=common.load(index);ext=_extension();native=ext.exl3_moe
sample=torch.load(f'/tmp/exl3-opt-20260910/routes/layer-{index}.pt',weights_only=True,map_location='cuda')
result={'gpu':torch.cuda.get_device_name(),'layer':index,'control_library_sha256':hashlib.sha256((O/'pipeline/pipeline.so').read_bytes()).hexdigest(),'records':[]}
control=Launcher(ext,O/'rows64/rows.so','m32_predicated')
with torch.inference_mode():
 for rows,chunk in [(1024,1024),(2048,2048)]:
  x,w,ids=(sample[a][:rows].contiguous() for a in ['x','weights','ids']);ws=[t.new_empty(t.shape[0],chunk,t.shape[2]) for t in method.workspace]
  args=(x,w,ids,method.ptrs,ws,method.bits,method.flags,10.0);fn=lambda:fused_with_chunk(args,chunk,longest_first=True)
  ext.exl3_moe=control;ref=fn()
  candidates=[('original_base',control),('original_nobar',Pipeline(ext,O/'pipeline/pipeline.so','nobar_m32_k32_n256')),('safe_base',Pipeline(ext,O/'safe-prefill/pipeline.so','base_m32_k32_n256')),('safe_nobar',Pipeline(ext,O/'safe-prefill/pipeline.so','nobar_m32_k32_n256')),('original_base_after',control)]
  for name,impl in candidates:
   ext.exl3_moe=impl;y=fn();err=float((y.float()-ref.float()).norm()/ref.float().norm());r={'rows':rows,'chunk':chunk,'variant':name,'relative_l2':err,'finite':bool(torch.isfinite(y).all())}
   r.update(library=impl.library,library_sha256=hashlib.sha256(Path(impl.library).read_bytes()).hexdigest())
   result['records'].append(r)
   if isinstance(impl,Pipeline):r.update(threads=impl.threads,plan={k:v for k,v in impl.plans[0].items() if k!='locks'})
   if r['finite'] and err<(0.02 if name.startswith('half') else 0.003):
    times=common.graph_times(fn);r.update(median_ms=statistics.median(times),times_ms=times)
   else:r['rejected']='correctness'
   out.write_text(json.dumps(result,indent=2));print({a:b for a,b in r.items() if a!='times_ms'},flush=True)
 ext.exl3_moe=native
