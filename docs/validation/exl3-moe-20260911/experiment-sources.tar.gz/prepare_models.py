import json,gzip
from pathlib import Path
R=Path('/home/bul/dev/vllm-backport');O=Path('/tmp/exl3-moe-next-20260911')
source=(R/'benchmarks/benchmark_exl3.py').read_text()
source=source.replace('args.tokens, True)','case.get("new_tokens", args.tokens), True)').replace('row["new_tokens"] == args.tokens','row["new_tokens"] == case.get("new_tokens", args.tokens)')
a=source.index('    if not args.skip_eval:\n');b=source.index('    print("SAVED"',a)
block=source[a:b].replace('"id": request["id"],','"variant": eval_variant["name"],\n                        "id": request["id"],')
block='\n'.join('    '+line if line else line for line in block.splitlines())+'\n'
source=source[:a]+'''    for eval_variant in [v for v in variants if v.get("eval", True)]:
        backend.llm.collective_rpc("configure_exl3_optimization", args=(eval_variant,))
'''+block+'''    result["runtime_after"] = backend.llm.collective_rpc("get_exl3_runtime_state")
    save()
'''+source[b:]
(O/'benchmark_model.py').write_text(source)
def read(path):return json.loads(gzip.decompress(path.read_bytes())) if path.suffix=='.gz' else json.loads(path.read_text())
d=read(R/'docs/validation/exl3-fixed-pp-20260910/exl3-long-b1-inputs.json.gz')
e=read(R/'docs/validation/exl3-20260910/moe-inputs.json');d['evals']=e['evals']
for c in e['cases']:
 c['new_tokens']=128
 d['cases'].append(c)
(O/'model-inputs.json.gz').write_bytes(gzip.compress(json.dumps(d).encode(),mtime=0))
base={'capacity':1024,'priority':True,'rows_library':str(O/'pipeline/pipeline.so')}
for mode in ['native','plain','residual']:
 variants=[dict(base,name=name,rows_variant=variant,eval=ev) for name,variant,ev in ([('m32_before','base_m32_k32_n256',True),('nobar','nobar_m32_k32_n256',True),('half','half_m32_k32_n256',True),('m32_after','base_m32_k32_n256',False)] if mode=='native' else [('nobar','nobar_m32_k32_n256',True)])]
 (O/f'{mode}-model-variants.json').write_text(json.dumps(variants,indent=2))
