import os,json,subprocess,time,sys
from pathlib import Path
R=Path('/home/bul/dev/vllm-backport');O=Path('/tmp/exl3-moe-next-20260911');status=[]
for mode in sys.argv[1:] or ['native','plain','residual']:
 name=mode+'-model';cmd=[str(R/'.venv/bin/python'),str(O/'benchmark_model.py'),'--backend','vllm','--inputs',str(O/'model-inputs.json.gz'),'--output',str(O/f'{name}.json'),'--pp','4','--expected-layer-counts','11','11','11','12','--chunk-size','1024','--max-model-len','66560','--kv-cache-gib','8','--batch-size','4','--warmups','1','--repeats','3','--tokens','32','--eval-tokens','768','--moe-variants',str(O/f'{mode}-model-variants.json'),'--worker-extension-cls','kernels.exl3_moe_decode.worker.Exl3DecodeWorkerExtension']
 env=dict(os.environ,CUDA_DEVICE_ORDER='PCI_BUS_ID',CUDA_VISIBLE_DEVICES='0,1,2,3',NCCL_P2P_DISABLE='1',VLLM_PP_LAYER_PARTITION='11,11,11,12',OMP_NUM_THREADS='1',EXL3_INT8_GEMV='0',VLLM_DETERMINISTIC_MOE_ALIGN='0',VLLM_EXL3_MOE_MAX_TOKENS='1024',VLLM_EXL3_MOE_PRIORITY='1',VLLM_EXL3_EXPERIMENTAL_DECODE=mode,VLLM_EXL3_DECODE_LIBRARY=str(O/'final-decode/decode.so'),PYTHONPATH=str(R/'benchmarks')+':'+str(R))
 record={'mode':mode,'command':cmd,'environment':{k:v for k,v in env.items() if k.startswith(('CUDA_','NCCL_','VLLM_','EXL3_','OMP_','PYTHONPATH'))},'start':time.time()};status.append(record);(O/'model-status.json').write_text(json.dumps(status,indent=2));print('START',mode,flush=True)
 with (O/f'{name}.log').open('w') as log:r=subprocess.run(cmd,cwd=R,env=env,stdout=log,stderr=subprocess.STDOUT)
 record.update(exit_code=r.returncode,end=time.time());(O/'model-status.json').write_text(json.dumps(status,indent=2));print('DONE',mode,r.returncode,flush=True)
 if r.returncode:raise SystemExit(r.returncode)
