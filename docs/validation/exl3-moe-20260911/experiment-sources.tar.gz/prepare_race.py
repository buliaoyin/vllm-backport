import subprocess,os,json,hashlib,re,time
from pathlib import Path
R=Path('/home/bul/dev/vllm-backport');O=Path('/tmp/exl3-moe-next-20260911');records=[]
def run(name,cmd,env=None):
 print('START',name,flush=True);rec={'name':name,'command':cmd,'start':time.time()};records.append(rec)
 with (O/f'{name}.log').open('w') as log:result=subprocess.run(cmd,cwd=R,env=env,stdout=log,stderr=subprocess.STDOUT)
 rec.update(exit_code=result.returncode,end=time.time());(O/'prepare-race-status.json').write_text(json.dumps(records,indent=2));print('DONE',name,result.returncode,flush=True)
 if result.returncode:raise SystemExit(result.returncode)
for name,script in [('rebuild-decode','build.py'),('rebuild-prefill','build_prefill.py')]:
 if not (O/name/('decode.so' if name == 'rebuild-decode' else 'pipeline.so')).exists():
  run(name,[str(R/'.venv/bin/python'),str(R/'benchmarks/kernels/exl3_moe_decode'/script),'--source','/home/bul/dev/exllamav3','--build-dir',str(O/name),'--nvcc','/usr/local/cuda/bin/nvcc'],dict(os.environ,PYTHONPATH=str(R)))
def sass(library):
 text=subprocess.check_output(['/usr/local/cuda/bin/cuobjdump','--dump-sass',str(library)],text=True)
 values=[(p.splitlines()[0].strip(),re.findall(r'/\* (0x[0-9a-f]{16}) \*/',p)) for p in text.split('Function : ')[1:]]
 assert values and all(words for _,words in values), 'No machine instructions extracted'
 return values
comp={}
for a,b in [('final-decode/decode.so','rebuild-decode/decode.so'),('pipeline/pipeline.so','rebuild-prefill/pipeline.so')]:
 x,y=sass(O/a),sass(O/b);comp[a]={'rebuilt':b,'instructions_identical':x==y,'functions':len(x),'matched_instruction_words':sum(len(c) for _,c in x)}
(O/'rebuild-equivalence.json').write_text(json.dumps(comp,indent=2));print('SASS_EQUIVALENCE',comp,flush=True)
meta=json.loads((O/'pipeline/build.json').read_text());cmd=[s.replace('-gencode=arch=compute_80,code=sm_80','-gencode=arch=compute_120,code=sm_120').replace(str(O/'pipeline/pipeline.so'),str(O/'pipeline/sanitizer-sm120.so')) for s in meta['command']]
run('build-racecheck-sm120',cmd);meta.update(command=cmd,diagnostic_only=True,library_sha256=hashlib.sha256((O/'pipeline/sanitizer-sm120.so').read_bytes()).hexdigest());(O/'racecheck-sm120-build.json').write_text(json.dumps(meta,indent=2))
s=(O/'pipeline_launcher.py').read_text();a='        if torch.cuda.get_device_capability(device) != (8, 0):\n            raise ValueError("Row kernels are compiled and validated for SM80 only")\n';assert s.count(a)==1;s=s.replace(a,'');(O/'diagnostic_launcher.py').write_text(s)
