import hashlib,json,shutil,subprocess
from pathlib import Path
O=Path('/tmp/exl3-moe-next-20260911');base=Path('/tmp/exl3-int8-20260911/final-v9/fp16')
out=O/'rows64';out.mkdir(exist_ok=True)
if not (out/'upstream').exists():shutil.copytree(base/'upstream',out/'upstream')
gemm=(base/'gemm_rows.cuh').read_text().replace('exl3_gemm_rows_v2_inner','exl3_gemm_rows_next_inner').replace('TILESIZE_M == 32, "Row-reuse prototype requires M=32"','TILESIZE_M == 32 || TILESIZE_M == 64, "Expected M32/M64"')
(out/'gemm_next.cuh').write_text(gemm)
moe=(base/'moe_rows.cuh').read_text().replace('"gemm_rows.cuh"','"gemm_next.cuh"').replace('exl3_moe_rows_v2_kernel','exl3_moe_rows_next_kernel').replace('exl3_gemm_rows_v2_inner','exl3_gemm_rows_next_inner').replace('cb,32,ROW_TILE_K','cb,ROW_TILE_M,ROW_TILE_K')
(out/'moe_next.cuh').write_text(moe)
variants={'m32_predicated':'4,256,2,2,32,32,true','m64':'4,256,2,2,64,32,true','m64_k16':'4,256,2,2,64,16,true','m64_n128':'4,128,2,2,64,32,true','m32_k16':'4,256,2,2,32,16,true','m32_n128':'4,128,2,2,32,32,true'}
code='#include "moe_next.cuh"\n'
for name,params in variants.items():code+=f'extern "C" void* exl3_rows_{name}() {{ return (void*)exl3_moe_rows_next_kernel<{params}>; }}\n'
(out/'rows.cu').write_text(code)
meta=json.loads((base/'build.json').read_text());cmd=[v.replace(str(base),str(out)) for v in meta['command']]
meta.update(command=cmd,variants=variants,experiment_sha256={p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in [out/'gemm_next.cuh',out/'moe_next.cuh',out/'rows.cu',Path(__file__)]})
(out/'build.json').write_text(json.dumps(meta,indent=2))
with (out/'build.log').open('w') as log:subprocess.run(cmd,stdout=log,stderr=subprocess.STDOUT,check=True)
meta['library_sha256']=hashlib.sha256((out/'rows.so').read_bytes()).hexdigest();(out/'build.json').write_text(json.dumps(meta,indent=2))
print(out/'rows.so',flush=True)
