import sys
from pathlib import Path
sys.path.insert(0,'/home/bul/dev/vllm-backport')
import torch
from types import SimpleNamespace
from safetensors import safe_open
from vllm.model_executor.layers.quantization.exl3 import Exl3Config,Exl3MoEMethod
from benchmarks.kernels.exl3_m32.benchmark import graph_times
ROOT=Path('/tmp/exl3-moe-next-20260911')
MODEL=Path('/home/bul/dev/models1/zai/turboderp/GLM-5.3-Flash-exl3/4.05bpw')
@torch.inference_mode()
def load(layer_index=22,experts=288):
 prefix=f'model.language_model.layers.{layer_index}.mlp.experts'
 config=Exl3Config({});config.maybe_update_config(str(MODEL))
 k,n=config.matrices[prefix+'.0.gate_proj'].dimensions
 moe=SimpleNamespace(moe_parallel_config=SimpleNamespace(tp_size=1,ep_size=1),activation='silu',swiglu_limit=10.0)
 layer=torch.nn.Module();method=Exl3MoEMethod(config,moe,prefix)
 with torch.device('cuda'):method.create_weights(layer,experts,k,n,torch.bfloat16)
 for shard in MODEL.glob('*.safetensors'):
  with safe_open(shard,framework='pt',device='cpu') as f:
   for name in f.keys():
    if not name.startswith(prefix+'.'):continue
    expert,proj,component=name[len(prefix)+1:].split('.')
    if int(expert)>=experts:continue
    kind={'gate_proj':'w1','up_proj':'w3','down_proj':'w2'}[proj]
    param=getattr(layer,('w2_' if kind=='w2' else 'w13_')+component)
    param.weight_loader(param,f.get_tensor(name),expert_id=int(expert),shard_id=kind)
 method.process_weights_after_loading(layer)
 return layer,method,k,n
