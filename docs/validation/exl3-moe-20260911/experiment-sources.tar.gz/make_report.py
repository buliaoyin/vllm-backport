import json,statistics,collections,csv
from pathlib import Path
R=Path('/home/bul/dev/vllm-backport');O=Path('/tmp/exl3-moe-next-20260911');D=R/'docs/validation/exl3-moe-20260911';D.mkdir(exist_ok=True)
s=json.loads((O/'summary.json').read_text())
lines=['# EXL3 MoE 专项优化验证（2026-09-11）','',
'本轮将格式本身的成本与当前专家内核的限制分开验证。针对 SM80 少量 token 分散到大量专家的场景，实际实现并测试 M64、多种 K/N tile、独立 tile 调度、同步/锁消减、FP16 累加，以及面向 GPU 路由的多专家 INT8 DP4A decode。生产默认路径未切换；实验代码可以显式加载。','',
'## 协议与可比性','',
'- GLM-5.3-Flash EXL3 4.05bpw，288 专家、top-8、hidden 4096、intermediate 2048。45 层中前 3 层为 dense。',
'- GPU0–2：CMP 170HX / SM80；GPU3：RTX PRO 6000 Blackwell / SM120。所有整模型实验实际核验 PP `11/11/11/12`，即层 0–10 / 11–21 / 22–32 / 33–44。',
'- 主对照 chunk 1024，另列 hybrid 的 chunk 2048 调优，KV 8 GiB/GPU，关闭 prefix cache；长输入 B1 为 8K/16K/32K/64K，输出 32 token；256/2048 短输入 B1/B4 输出 128 token。每例预热后测量 3 次。',
'- 所有本轮整模型比较均设 `EXL3_INT8_GEMV=0`，只改变指定的专家路径。`native/plain/residual/hybrid` 使用独立进程，在 CUDA Graph 捕获前安装 decode，runtime 记录各 rank 的模式、grid、实际库 SHA256 和 Python warmup/capture 调用。',
'- B1 输入吞吐 = 输入 token / TTFT；输出吞吐 = (输出 token - 1) / 首 token 到末 token 的时间。整请求输出吞吐另存于 JSON，不能混用。B4 使用总输入 / 最大 TTFT、总 (输出 - 1) / 最大 decode span；可能含其他请求 prefill 的交错时间，不等同单一纯 decode 阶段。',
'- kernel 微测使用真实 prefill 的 layer 22/3 激活与路由（decode 扫描截取前 1/2/4/8 行）、完整 288 专家权重、CUDA Graph、15 次 CUDA Event 计时，每次在计时前写入 256 MiB eviction buffer。时间含完整专家 wrapper 的 GPU 工作，排除 CPU dispatch；前后均测控制组。不同扫描轮次的绝对时间不用于直接计算增益。',
'- AWQ/NVFP4 为 9 月 10 日固定分层历史数据。本轮已逐项核验四个长输入的 token IDs 完全相同，主比较的输出长度、chunk、KV 预算及分层一致，Torch/CUDA 与 GPU 型号一致。二者均为 Marlin W4A16；AWQ 最后一层专家未量化，不能视为等精度权重比较。','',
'## 为什么当前 EXL3 MoE 较慢','',
'1024-token chunk 的 8192 个专家分配平均到 288 个专家，只有约 28.4 行/专家。EXL3 需要在消费压缩权重时执行 trellis/codebook 解码；每个专家又有独立的输入/输出 Hadamard 旋转与缩放，gate/up/down 的中间结果及路由合并也有成本。小 M 限制权重及解码结果复用，不能直接套用 dense 大矩阵结论。','',
'已有 fused MoE 内核和专家调度，并非完全未优化 MoE。但原版普通 `EXL3_INT8_GEMV` 开关没有覆盖集成使用的 `exl3_mgemm` 专家 decode，本轮补上了这个具体缺口。prefill 的主要区间仍是专家 GEMM（包含解码、访存、同步），不能把此前 GEMM 区间占比解释成 Tensor Core 利用率。','',
'## Prefill：逐项实测','',
'以下均为 layer 22、1024 输入行、chunk 1024、完整专家 wrapper，中位数 ms。原始 JSON 保存 512/1024/2048 行及 chunk 1024/2048 的全部样本。','',
'| 扫描 | 变体 | 时间 ms | 相对同轮前控制组 | relative L2 |','|---|---|---:|---:|---:|']
for name,label in [('rows64-layer22','M/K/N'),('tiles-layer22','tile 调度'),('pipeline-layer22','同步/累加')]:
 rs=[r for r in s['micro'][name]['records'] if r['rows']==1024 and r.get('chunk')==1024];base=rs[0]['median_ms']
 for r in rs:
  lines.append(f"| {label} | `{r['variant']}` | {r.get('median_ms',float('nan')):.3f} | {(r.get('median_ms',base)/base-1)*100:+.1f}% 耗时 | {r['relative_l2']:.3g} |")
lines += ['',
'- **M64/K/N 调整未获益。** M64 K32 N256 使用 128 registers，产生 1492 B spill stores / 5318 B spill loads；M32 控制组只有 4 B / 2 B。K16 或 N128 缓解部分压力，但完整 wrapper 仍更慢。FP16 累加的 M64 版本甚至出现 12832 B / 18954 B spill，排除。',
'- **独立 tile 调度未获益。** 原型以专家 × 行块 × 输出列块建立 grid，取消 GEMM 跨 block 锁，拆为 schedule/gather/gate-up/activation/down/scatter 六阶段；数值通过，但完整耗时比 fused M32 更高。这个结果只否定当前布局/流水线原型，不证明所有 persistent/grouped GEMM 都无效。最初 scatter 缺少动态共享内存导致 IMA，修正分配后才采集数据。',
'- **移除冗余 fragment-load barrier 是候选。** 保留三段 shared-memory pipeline 与 `wait_stage` 的 CTA 屏障；下一次 async copy 写另一个 stage，后续 `wait_stage` 在旧 stage 重用前完成读者同步。独立数值和图重放通过，layer22 约减少 4%–5% 耗时。',
'- **只去除不需要的跨 block 锁没有改善。** 仅在输出列 tile 可被 group width 整除、不发生 split-K 输出争用时省略锁；其他形状保留。',
'- **FP16 累加是独立精度取舍。** `half` 同时包含 barrier/lock 改动，用 `both` 作同布局对照；M32 微测有额外小收益，但增加约 0.22% 相对 L2，需看整模型质量和收益。',
'- SASS 确认控制/无 barrier 使用 `HMMA.16816.F32`，half 使用 `HMMA.16816.F16`；静态 `BAR.SYNC` 从 46 条减少到 37 条，HMMA 均为 48 条。静态指令数量不是动态执行次数或时间归因。','',
'## Decode：GPU 路由的多专家 DP4A','',
'新内核按 token/expert assignment 使用 grid.z 读取专家权重/旋转指针，直接读取原始输入行；不在 CPU 回读路由，不逐专家发射 kernel。gate/up/down 分别计算，最后按 routing weights 合并。保留 mul1 codebook，plain 量化激活，residual 追加激活残差补偿。hybrid 在 SM80 使用 plain、SM120 使用 residual，runtime 单独记录实际模式。它与上一轮使用近似 INT8 codebook 的 prefill IMMA 原型不同。','',
'下表给出每个样本扫描 grid=4/8/16/32/64 的最好中位数；这是微测最优值，不能直接解释为服务增益。模型用预先固定的 grid 规则（SM80：1–4 行 32，5–8 行 16；SM120：1/5–8 行 64，2 行 32，3–4 行 16）。','',
'| GPU/层 | 输入行 | native µs | plain 最好 µs / grid | residual 最好 µs / grid | plain / residual L2 |','|---|---:|---:|---:|---:|---:|']
for name in ['decode-sm80-layer22','decode-sm80-layer3','decode-sm120-layer22']:
 rs=s['micro'][name]['records']
 for rows in [1,2,4,8]:
  group=[r for r in rs if r['rows']==rows];base=next(r for r in group if r['variant']=='native');p=min((r for r in group if r['variant'].startswith('plain')),key=lambda r:r['median_ms']);q=min((r for r in group if r['variant'].startswith('residual')),key=lambda r:r['median_ms'])
  lines.append(f"| {name.removeprefix('decode-')} | {rows} | {base['median_ms']*1000:.1f} | {p['median_ms']*1000:.1f} / {p['variant'].split('_g')[1]} | {q['median_ms']*1000:.1f} / {q['variant'].split('_g')[1]} | {p['relative_l2']:.4f} / {q['relative_l2']:.4f} |")
lines += ['', '## 同步警告与修复后的候选', '',
'在 SM120 诊断构建中，保留原 fragment barrier 的控制组与 nobar 都报告了 Hadamard scatter 的 6 组 warp 访问警告；二者数值测试均通过，但不能因此忽略同步契约。警告来自共同继承的 helper：当前迭代读共享 staging buffer 后，下一轮可能先覆写它。本轮在实验副本的最后一次 atomicAdd 后增加 `__syncwarp()`；保留上游 checkout 和已安装扩展作为对照。', '',
'修复版在 33/513 行（含 CUDA Graph 与路由变化）的 SM120 诊断 racecheck 中得到 **0 hazards、0 errors、0 warnings**。新 decode 的 6 项测试也通过 racecheck。SM80 修复库再次通过全部 **91 项 pytest**；CMP 170HX 自身仍不能运行 sanitizer，不能把 SM120 诊断称为 SM80 硬件的直接检查。', '',
'上面的探索数据及 native/plain/residual 模型数据使用修复前实验库；最终 hybrid 的 `nobar_safe` 和 chunk 2048 追加实验使用修复版。表中每个候选保存独立库 SHA256。', '',
'| 行 / chunk | 原控制 ms | 原 nobar ms | 修复控制 ms | 修复 nobar ms |',
'| --- | ---: | ---: | ---: | ---: |']
for rows, chunk in [(1024,1024),(2048,2048)]:
 rs={r['variant']:r for r in s['micro']['safe-prefill-layer22']['records'] if r['rows']==rows and r['chunk']==chunk}
 lines.append(f"| {rows} / {chunk} | {rs['original_base']['median_ms']:.3f} | {rs['original_nobar']['median_ms']:.3f} | {rs['safe_base']['median_ms']:.3f} | {rs['safe_nobar']['median_ms']:.3f} |")
lines += ['', '在这两种形状下，补充 warp 同步给 nobar 带来的额外耗时约 0.1%，保留了主要性能收益。修复前原型曾完成 SASS 重建等价检查（decode 10 个函数、prefill 8 个函数）；安全修复有意增加同步指令，另行完成正确性、racecheck 和微测。', '']
lines += ['',
'SASS 显示新专家投影使用 `IDP.4A.U8.S8`；plain/residual 分别为 48/96 条静态 DP4A 指令。不是 IMMA Tensor Core prefill，也不能靠看到 FP16 内核中的 codebook DP4A 解码指令来判断已启用该路径。','',
'## 整模型结果','',
'后续表格由保存的逐请求数据计算，单位均为 token/s，取 3 次中位数。','',
'| 模式 / prefill | chunk | 输入 / batch | 输入吞吐 | 输出吞吐 | TTFT s |','|---|---:|---|---:|---:|---:|']
for mode,d in s['models'].items():
 for r in d['perf']:
  lines.append(f"| {mode.removesuffix('-model')} / {r['variant']} | {d['args']['chunk_size']} | {r['case']} | {r['input_tps']['median']:.2f} | {r['output_tps']['median']:.2f} | {r['ttft']['median']:.4f} |")
lines += ['', '| 历史格式 | 输入 | 输入吞吐 | 输出吞吐 | TTFT s |','|---|---|---:|---:|---:|']
for fmt,rs in s['historical'].items():
 for r in rs:lines.append(f"| {fmt} Marlin | {r['case']} | {r['input_tps']:.2f} | {r['output_tps']:.2f} | {r['ttft']:.4f} |")
lines += ['', '## 数值和模型质量', '', '| 模式 / prefill | GSM8K 正确 / 完成 | 达输出上限未结束 |', '|---|---:|---:|']
for mode,d in s['models'].items():
 for v,r in d['eval'].items():lines.append(f"| {mode.removesuffix('-model')} / {v} | {r['correct']} / {r['total']} | {r['unfinished']} |")
lines += ['',
'质量样本为相同的 64 道题，greedy、最多 768 输出 token，B4。保留完整输出 token IDs、文本、答案与停止原因；64 道题只提供局部回归证据，不构成广泛等精度结论。长输入另外检查埋入数字检索，完整计数见 `summary.json`。',
'', '## 验证、源码和复现', '',
'- SM80：同步修复后现有与新增合计 91 项 pytest 通过；SM120：6 项新 decode 测试通过。独立 reference 重建权重并显式做 Hadamard，另测变化输入/路由的图重放。',
'- Blackwell `compute-sanitizer --tool memcheck` 的 6 项测试通过，`ERROR SUMMARY: 0 errors`。CMP 170HX 报 GPU debugging features disabled，退出 99；不能计作 memcheck 或 racecheck 通过。',
'- 构建、运行及数据保存于本目录的 `exl3-moe-20260911/`；`manifest.json` 记录逐文件 SHA256。`experiment-sources.tar.gz` 保留临时构建脚本和生成的 CUDA 变体；上游头文件来自 build.json 中固定版本及哈希，原版 checkout 未修改。',
'- [decode 与 prefill 构建/使用说明](../../benchmarks/kernels/exl3_moe_decode/README.md)。生产默认实现不变；实验 worker 必须显式指定，decode 模式必须在模型 Graph 捕获前确定。',
'- [之前 M32 工作](exl3-sm80-m32-20260911.md)、[上一轮 INT8 prefill](exl3-int8-20260911.md)、[固定分层 NVFP4/AWQ 对照](exl3-fixed-pp-comparison-20260910.md)、[此前调参及缓存实验](exl3-optimization-20260910.md)。',
'', '前一轮容量/优先级/组宽、Triton 路由、简单热专家拆分、FP16 热点缓存等已实测，本轮没有无差别重复。跨请求聚合与专家并行会改变服务调度或部署，未把不同分层/拓扑的成绩混入本轮；仍不能声称穷尽全部算法和硬件配置。','']
f=json.loads((O/'final-comparison.json').read_text())
t=f['throughput']
lead=['## 最终结论与建议', '',
'当前实现对 SM80 的稀疏专家小矩阵确有性能缺口，格式本身的 trellis 解码与 Hadamard 也带来额外成本。本轮有效候选为：保留 FP32 累加的 M32 prefill、减少冗余同步并补全 warp 同步契约，以及 GPU 路由的多专家 DP4A decode。最终 hybrid 使用 SM80 plain / SM120 residual。', '',
'以下均为 B1、PP `11/11/11/12`、chunk 1024，单元格为 **输入 / 输出 token/s**。M32 基线合并同一进程前后两组控制的 6 次样本；其他列各 3 次中位数。基线已包含上一轮 M32 优化，不是最初 M16 或原版默认 INT8 配置。NVFP4/AWQ 使用核验过配置及输入的历史样本。', '',
'| 输入 | EXL3 M32 基线 | EXL3 本轮 hybrid + 安全同步 | NVFP4 Marlin | AWQ Marlin |',
'| --- | ---: | ---: | ---: | ---: |']
for n in (8192,16384,32768,65536):
 case=f'p{n}_b1'
 cells=[f"{t[mode][case]['input_tps']:.1f} / {t[mode][case]['output_tps']:.2f}" for mode in ('native','hybrid','nvfp4','awq')]
 lead.append('| '+str(n//1024)+'K | '+' | '.join(cells)+' |')
lead += ['',
'同 chunk 下，整模型输入吞吐提高 **3.8%–4.1%**，输出提高 **12.3%–12.9%**。单独 nobar 的 prefill 整模型收益约 2%–3%；最终组合的全部差值不能归因于一条 barrier。64K 最终输入仍低于 NVFP4/AWQ 约 32%/35%，输出低约 15%/16%，尚未追平 Marlin。', '',
'### Chunk 2048 是长度相关的配置选择', '',
'这一组继续固定 PP、KV 预算、token IDs、输出长度和 hybrid 内核，修改调度 chunk 与专家容量为 2048。下面的相对变化以本轮 hybrid/chunk 1024 为基准；它与历史 NVFP4/AWQ 不是相同 chunk 的格式对照。', '',
'| 输入 | chunk 1024 输入 / 输出 | chunk 2048 输入 / 输出 | 输入变化 | chunk 2048 TTFT s |',
'| --- | ---: | ---: | ---: | ---: |']
for n in (8192,16384,32768,65536):
 a,b=(t[mode][f'p{n}_b1'] for mode in ('hybrid','hybrid-c2048'))
 lead.append(f"| {n//1024}K | {a['input_tps']:.1f} / {a['output_tps']:.2f} | {b['input_tps']:.1f} / {b['output_tps']:.2f} | {(b['input_tps']/a['input_tps']-1)*100:+.1f}% | {b['ttft']:.3f} |")
lead += ['',
'64K 输入达到 **4067.7 token/s**，TTFT 为 **16.111 s**，相对原 M32/chunk 1024 输入吞吐提高 15.5%。但是 8K 比本轮 chunk 1024 慢 5.9%，因此不统一改成 2048；目前证据支持长输入使用 2048、较短输入保留 1024，尚未实现自动切换策略。专家 workspace 随容量翻倍：每张 SM80 从 192 MiB 到 384 MiB，SM120 从 552 MiB 到 1104 MiB，KV 仍为 8 GiB/GPU。', '',
'两组最终 hybrid 各完成 64/64 GSM8K 与 12/12 长输入检索检查，无达到输出上限而未结束的样本；相对 M32 基线没有新增错题。基线为 63/64，但不能把这个小样本差异解释为精度提升。每组只有 15/64 道题输出 token 序列与基线完全一致，模型输出并非逐 token 等价。', '',
'建议保留 hybrid + 修复后的 FP32 nobar 为显式实验选项；不采用 M64、当前独立 tile 调度或 FP16 累加。本轮覆盖多个具体原型，尚未验证持久化调度、专家并行或跨请求聚合等更大范围设计。', '']
i=lines.index('## 协议与可比性');lines[i:i]=lead
quality=['', '| 模式 / prefill | 答案相同 / 64 | token 序列相同 / 64 | 基线答对而此版本答错的题 ID |', '| --- | ---: | ---: | --- |']
for name,d in f['quality'].items():
 quality.append(f"| {name} | {d['same_answers']} | {d['same_tokens']} | {', '.join(map(str,d['new_errors'])) or '无'} |")
quality += ['', '基线错题为 ID 9；plain 的错题为 ID 14，half 的错题为 ID 12。虽然这三个模式的总分都是 63/64，错误并不相同，不能只看总分就断言无回归。最终 hybrid 两个 chunk 的这 64 道题均通过。', '']
i=lines.index('## 验证、源码和复现');lines[i:i]=quality
lines=['| '+' | '.join(cell.strip() for cell in line.strip('|').split('|'))+' |' if line.startswith('|') else line for line in lines]
(R/'docs/validation/exl3-moe-20260911.md').write_text('\n'.join(lines))
with (O/'micro-summary.csv').open('w') as f:
 w=csv.writer(f);w.writerow(['suite','rows','chunk','variant','median_ms','relative_l2'])
 for name,d in s['micro'].items():
  for r in d['records']:w.writerow([name,r['rows'],r.get('chunk'),r['variant'],r.get('median_ms'),r['relative_l2']])
print('report updated')
