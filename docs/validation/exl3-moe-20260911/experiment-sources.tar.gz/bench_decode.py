import common
import sys,json,statistics,hashlib
import torch
from decode_launcher import Decode
from vllm.model_executor.layers.quantization.exl3 import _exl3_moe_decode,_extension
O=common.ROOT;out=O/(sys.argv[1] if len(sys.argv)>1 else 'decode-sm80-layer22.json');index=int(sys.argv[2]) if len(sys.argv)>2 else 22
layer,method,k,n=common.load(index);ext=_extension();torch.manual_seed(71)
sample=torch.load(f'/tmp/exl3-opt-20260910/routes/layer-{index}.pt',weights_only=True,map_location='cuda')
result={'gpu':torch.cuda.get_device_name(),'torch':str(torch.__version__),'layer':index,'library_sha256':hashlib.sha256((O/'decode/decode.so').read_bytes()).hexdigest(),'records':[]}
with torch.inference_mode():
 for rows in [1,2,4,8]:
  x,w,ids=(sample[a][:rows].contiguous() for a in ['x','weights','ids']);args=(x,w,ids,method.ptrs,method.workspace,method.bits,method.flags,10.0)
  ref=_exl3_moe_decode(*args)
  candidates=[('native',_exl3_moe_decode)]+[(f'{"residual" if residual else "plain"}_g{grid}',Decode(ext,O/'decode/decode.so',residual,grid)) for residual in [False,True] for grid in [4,8,16,32,64]]+[('native_after',_exl3_moe_decode)]
  for name,impl in candidates:
   fn=lambda:impl(*args);y=fn();err=float((y.float()-ref.float()).norm()/ref.float().norm());r={'rows':rows,'variant':name,'relative_l2':err,'finite':bool(torch.isfinite(y).all())}
   result['records'].append(r)
   if r['finite'] and err<0.02:
    times=common.graph_times(fn);r.update(median_ms=statistics.median(times),times_ms=times)
   else:r['rejected']='correctness'
   out.write_text(json.dumps(result,indent=2));print({a:b for a,b in r.items() if a!='times_ms'},flush=True)
