#include "moe_next.cuh"
extern "C" void* exl3_rows_m32_predicated() { return (void*)exl3_moe_rows_next_kernel<4,256,2,2,32,32,true>; }
extern "C" void* exl3_rows_m64() { return (void*)exl3_moe_rows_next_kernel<4,256,2,2,64,32,true>; }
extern "C" void* exl3_rows_m64_k16() { return (void*)exl3_moe_rows_next_kernel<4,256,2,2,64,16,true>; }
extern "C" void* exl3_rows_m64_n128() { return (void*)exl3_moe_rows_next_kernel<4,128,2,2,64,32,true>; }
extern "C" void* exl3_rows_m32_k16() { return (void*)exl3_moe_rows_next_kernel<4,256,2,2,32,16,true>; }
extern "C" void* exl3_rows_m32_n128() { return (void*)exl3_moe_rows_next_kernel<4,128,2,2,32,32,true>; }
