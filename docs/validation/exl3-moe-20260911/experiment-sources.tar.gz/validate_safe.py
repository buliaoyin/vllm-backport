import json,subprocess,os,time
from pathlib import Path
R=Path('/home/bul/dev/vllm-backport');O=Path('/tmp/exl3-moe-next-20260911');records=[]
def run(name,cmd,env=None):
 print('START',name,flush=True);record={'name':name,'command':cmd,'start':time.time()};records.append(record)
 with (O/f'{name}.log').open('w') as log:result=subprocess.run(cmd,cwd=R,env=env,stdout=log,stderr=subprocess.STDOUT)
 record.update(exit_code=result.returncode,end=time.time());(O/'safe-validation-status.json').write_text(json.dumps(records,indent=2));print('DONE',name,result.returncode,flush=True)
 if result.returncode:raise SystemExit(result.returncode)
meta=json.loads((O/'safe-prefill/build.json').read_text());cmd=[s.replace('-gencode=arch=compute_80,code=sm_80','-gencode=arch=compute_120,code=sm_120').replace(str(O/'safe-prefill/pipeline.so'),str(O/'safe-prefill/sanitizer-sm120.so')) for s in meta['command']]
run('build-safe-sm120',cmd)
env=dict(os.environ,OMP_NUM_THREADS='1',CUDA_DEVICE_ORDER='PCI_BUS_ID',PYTHONPATH=str(O)+':'+str(R),VLLM_EXL3_TEST_DECODE_LIBRARY=str(O/'rebuild-decode/decode.so'),VLLM_EXL3_TEST_PIPELINE_LIBRARY=str(O/'safe-prefill/pipeline.so'),VLLM_EXL3_TEST_ROWS_LIBRARY=str(O/'rows64/rows.so'),VLLM_EXL3_TEST_INT8_LIBRARY='/tmp/exl3-int8-20260911/final-v9/int8.so')
run('safe-tests-sm80',[str(R/'.venv/bin/python'),'-m','pytest','tests/quantization/test_exl3.py','-q'],dict(env,CUDA_VISIBLE_DEVICES='0'))
run('racecheck-safe-sm120',['/usr/local/cuda/bin/compute-sanitizer','--tool','racecheck','--error-exitcode','99','--target-processes','all',str(R/'.venv/bin/python'),str(O/'check_pipeline_race.py')],dict(env,CUDA_VISIBLE_DEVICES='3',EXL3_RACE_LIBRARY=str(O/'safe-prefill/sanitizer-sm120.so'),EXL3_RACE_RESULT='racecheck-safe-sm120-result.json'))
run('racecheck-decode-sm120',['/usr/local/cuda/bin/compute-sanitizer','--tool','racecheck','--error-exitcode','99','--target-processes','all',str(R/'.venv/bin/python'),'-m','pytest','tests/quantization/test_exl3.py','-k','experimental_expert_int8_decode','-q'],dict(env,CUDA_VISIBLE_DEVICES='3'))
run('safe-prefill-bench',[str(R/'.venv/bin/python'),str(O/'bench_safe.py')],dict(env,CUDA_VISIBLE_DEVICES='0'))
run('final-benchmark-sm80',[str(R/'.venv/bin/python'),'benchmarks/kernels/benchmark_exl3_moe.py','--checkpoint','/home/bul/dev/models1/zai/turboderp/GLM-5.3-Flash-exl3/4.05bpw','--prefix','model.language_model.layers.22.mlp.experts','--route-sample','/tmp/exl3-opt-20260910/routes/layer-22.pt','--decode-kernel-library',str(O/'rebuild-decode/decode.so'),'--decode-rows','1','4','--decode-grids','32','--output',str(O/'final-benchmark-sm80.json')],dict(env,CUDA_VISIBLE_DEVICES='0',EXL3_INT8_GEMV='0'))
