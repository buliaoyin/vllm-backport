#include "moe_base.cuh"
extern "C" void* exl3_rows_base_m32_k32_n256() { return (void*)exl3_moe_base_kernel<4,256,2,2,32,32,true>; }
#include "moe_nobar.cuh"
extern "C" void* exl3_rows_nobar_m32_k32_n256() { return (void*)exl3_moe_nobar_kernel<4,256,2,2,32,32,true>; }
#include "moe_nolock.cuh"
extern "C" void* exl3_rows_nolock_m32_k32_n256() { return (void*)exl3_moe_nolock_kernel<4,256,2,2,32,32,true>; }
#include "moe_both.cuh"
extern "C" void* exl3_rows_both_m32_k32_n256() { return (void*)exl3_moe_both_kernel<4,256,2,2,32,32,true>; }
#include "moe_half.cuh"
extern "C" void* exl3_rows_half_m32_k32_n256() { return (void*)exl3_moe_half_kernel<4,256,2,2,32,32,true>; }
extern "C" void* exl3_rows_half_m64_k32_n256() { return (void*)exl3_moe_half_kernel<4,256,2,2,64,32,true>; }
extern "C" void* exl3_rows_half_m64_k16_n256() { return (void*)exl3_moe_half_kernel<4,256,2,2,64,16,true>; }
extern "C" void* exl3_rows_half_m64_k32_n128() { return (void*)exl3_moe_half_kernel<4,128,2,2,64,32,true>; }
