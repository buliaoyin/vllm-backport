import hashlib,json,os,subprocess,time
from pathlib import Path
R=Path('/home/bul/dev/vllm-backport');O=Path('/tmp/exl3-target4700-20260911');B=O/'kernels-batched-int8-r1';P=str(R/'.venv/bin/python')
(O/'batched-int8-r1a-sources.json').write_text(json.dumps({str(p.relative_to(R)):hashlib.sha256(p.read_bytes()).hexdigest() for p in (R/'benchmarks/kernels/exl3_prefill_int8').glob('*.py')},indent=2))
status=[]
def run(name,cmd,env=None):
 rec={'name':name,'command':cmd,'start':time.time()};status.append(rec);(O/'batched-int8-r1a-status.json').write_text(json.dumps(status,indent=2));print('START',name,flush=True)
 with (O/(name+'.log')).open('w') as log:p=subprocess.run(cmd,cwd=R,env=env,stdout=log,stderr=subprocess.STDOUT,timeout=900)
 rec.update(end=time.time(),exit_code=p.returncode);(O/'batched-int8-r1a-status.json').write_text(json.dumps(status,indent=2));print('DONE',name,p.returncode,flush=True)
 if p.returncode:raise SystemExit(p.returncode)
env={k:v for k,v in os.environ.items() if not k.startswith(('EXL3_','VLLM_EXL3_'))};env.update(CUDA_VISIBLE_DEVICES='0',CUDA_DEVICE_ORDER='PCI_BUS_ID',EXL3_INT8_GEMV='0',OMP_NUM_THREADS='1',PYTHONPATH=str(R),VLLM_EXL3_TEST_BATCHED_INT8_LIBRARY=str(B/'helpers.so'),VLLM_TRITON_USE_TD='0')
run('batched-int8-r1a-tests',[P,'-m','pytest','tests/quantization/test_exl3.py','-q','-x','-k','experimental_batched_int8_prefill'],env)
env['VLLM_EXL3_MOE_MAX_TOKENS']='8192'
for layer in (22,3):
 run('batched-int8-r1a-layer'+str(layer),[P,'-m','benchmarks.kernels.exl3_prefill_int8.benchmark','--checkpoint','/home/bul/dev/models1/zai/turboderp/GLM-5.3-Flash-exl3/4.05bpw','--prefix',f'model.language_model.layers.{layer}.mlp.experts','--routes',str(O/f'routes-c2048/layer-{layer}.pt'),'--library',str(B/'helpers.so'),'--output',str(O/f'batched-int8-r1a-layer{layer}.json'),'--rows','2048','4096','8192','--repeats','15'],env)
for kind,library in [('fp16',O/'kernels-fp16-commit/helpers.so'),('int8',B/'helpers.so')]:
 run('phase-profile-'+kind,[P,'-m','benchmarks.kernels.exl3_prefill_fp16.profile','--backend',kind,'--checkpoint','/home/bul/dev/models1/zai/turboderp/GLM-5.3-Flash-exl3/4.05bpw','--prefix','model.language_model.layers.22.mlp.experts','--routes',str(O/'routes-c2048/layer-22.pt'),'--library',str(library),'--rows','8192','--output',str(O/f'phase-profile-{kind}.json')],env)
