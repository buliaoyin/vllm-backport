import gzip,hashlib,json,shutil,subprocess
from pathlib import Path
R=Path('/home/bul/dev/vllm-backport');O=Path('/tmp/exl3-target4700-20260911');A=R/'docs/validation/exl3-target4700-20260911';A.mkdir(exist_ok=True)
fixed=['baseline-summary.json','chunk-summary.json','chunk-status.json','timeline-analysis.json','timeline-status.json','candidate-status.json','candidate-sources.json','kernel-resources.json','resident-status.json','wide-resume-status.json','cached-status.json','cached-n256-status.json','adaptive-status.json','fp16-status.json']
for pattern in ['c2048-*.json','c3072.json','c4096.json','c8192.json','timeline-exl3-2048.json','timeline-awq-*.json','resident-layer*.json','wide-r2a-layer*.json','cached-layer*.json','cached-n256-layer*.json','adaptive-layer*.json','fp16-layer*.json','model-k16*.json','model-m64-cache-4096.json','model-default-after.json']:
 fixed.extend(f.name for f in O.glob(pattern))
fixed.extend(['resident-tests.log','wide-r2a-tests.log','cached-tests.log','cached-n256-tests.log','adaptive-tests.log','commit-correctness-pass.log','commit-precommit-pass.log','commit-mypy312.log'])
fixed.extend(['analyze_timeline.py','run_model_candidates.py','benchmark_model.py','run_fp16.py','run_fp16_models.py','run_batched_int8.py','archive_checkpoint.py'])
fixed += ['inputs.json.gz', 'fp16-model-status.json', 'fp16-model-sources.json',
          'batched-int8-r1a-status.json', 'batched-int8-r1a-sources.json',
          'batched-int8-final-tests.log', 'batched-int8-r1a-tests.log',
          'batched-int8-model-sources.json', 'run_batched_int8_models.py',
          'run_batched_int8_r1a.py', 'run_batched_int8_quality.py',
          'run_final_confirmation.py', 'plot_timeline.py']
fixed += ['quality-status.json', 'confirmation-status.json', 'batched-int8-model-status.json',
          'quality-candidate-selection.json', 'confirmation-inputs.json.gz',
          'final_analysis.py', 'final-analysis.json', 'final-source-check.json',
          'final-source-before-lint.json', 'final-check-files.json',
          'final-precommit-pass.log', 'final-mypy312.log',
          'check_benchmark_cli.py', 'final-benchmark-cli.log',
          'confirmation-runner.log', 'quality-runner.log']
fixed.extend(f.name for f in O.glob('measured-source-*.py'))
for pattern in ['phase-profile-*-external.json','batched-int8-r1a-layer*.json']:
 fixed.extend(f.name for f in O.glob(pattern))
for status_file in ['fp16-model-status.json','batched-int8-model-status.json','quality-status.json','confirmation-status.json']:
 if (O/status_file).exists():
  for rec in json.loads((O/status_file).read_text()):
   f=O/(rec['name']+'.json')
   if rec.get('exit_code')==0 and f.exists():fixed.append(f.name)
manifest=[]
for name in sorted(set(fixed)):
 src=O/name
 if not src.exists():continue
 data=src.read_bytes();dst=A/(name if name.endswith('.gz') else name+'.gz');dst.write_bytes(data if name.endswith('.gz') else gzip.compress(data,mtime=0))
 manifest.append({'source':str(src),'artifact':dst.name,'original_sha256':hashlib.sha256(data).hexdigest(),'artifact_sha256':hashlib.sha256(dst.read_bytes()).hexdigest()})
for folder in ['kernels-r1','kernels-r2','kernels-r3a','kernels-r4','kernels-r5','kernels-fp16-commit','kernels-batched-int8-r1']:
 for name in ['build.json','build.log']:
  src=O/folder/name
  if not src.exists():continue
  data=src.read_bytes();dst=A/(folder+'-'+name+'.gz');dst.write_bytes(gzip.compress(data,mtime=0))
  manifest.append({'source':str(src),'artifact':dst.name,'original_sha256':hashlib.sha256(data).hexdigest(),'artifact_sha256':hashlib.sha256(dst.read_bytes()).hexdigest()})
for folder in ['benchmarks/kernels/exl3_prefill_int8','benchmarks/kernels/exl3_prefill_fp16']:
 for src in (R/folder).glob('*'):
  if not src.is_file():continue
  data=src.read_bytes();dst=A/('source-'+str(src.relative_to(R)).replace('/','_')+'.gz')
  dst.write_bytes(gzip.compress(data,mtime=0));manifest.append({'source':str(src),'artifact':dst.name,'original_sha256':hashlib.sha256(data).hexdigest(),'artifact_sha256':hashlib.sha256(dst.read_bytes()).hexdigest()})
for relative in ['benchmarks/benchmark_exl3.py', 'tests/quantization/test_exl3.py']:
 src=R/relative
 data=src.read_bytes();dst=A/('source-'+relative.replace('/','_')+'.gz')
 dst.write_bytes(gzip.compress(data,mtime=0))
 manifest.append({'source':str(src),'artifact':dst.name,'original_sha256':hashlib.sha256(data).hexdigest(),'artifact_sha256':hashlib.sha256(dst.read_bytes()).hexdigest()})
figure=A/'timeline.png'
manifest.append({'source':str(figure),'artifact':figure.name,'original_sha256':hashlib.sha256(figure.read_bytes()).hexdigest(),'artifact_sha256':hashlib.sha256(figure.read_bytes()).hexdigest()})
(A/'manifest.json').write_text(json.dumps({'checkpoint_revision':subprocess.check_output(['git','rev-parse','HEAD'],cwd=R,text=True).strip(),'scope':'Final validation: independent 64K confirmation, B1 GSM8K, shorter-input sweeps, kernel tests and phase profiles. Production defaults unchanged. checkpoint_revision is the parent revision; measured-source snapshots and source snapshots identify the uncommitted experiment used in these runs.','artifacts':manifest},indent=2))
print(len(manifest),'archived artifacts;',sum(f.stat().st_size for f in A.iterdir()),'bytes')
