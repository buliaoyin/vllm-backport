from pathlib import Path
import json
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.patches import Patch
O=Path('/tmp/exl3-target4700-20260911');A=Path('/home/bul/dev/vllm-backport/docs/validation/exl3-target4700-20260911')
fig,axes=plt.subplots(2,1,figsize=(13,6.2),sharex=True,layout='constrained')
for ax,name,title,color in zip(axes,['timeline-exl3-2048','timeline-awq-2048'],['EXL3 default','AWQ Marlin'],['#b75628','#327ba8']):
 d=json.loads((O/(name+'.json')).read_text());ranks=d['event_profile']['ranks'];experts={'moe_m32','exl3_moe','marlin_gemm'}
 t0=min(r['anchor_host_midpoint_ms']+e['start_ms'] for r in ranks for e in r['timeline'] if e['label'].startswith('layer:'))
 for i,r in enumerate(ranks):
  for selected,fc,height in [(lambda e:e['label'].startswith('layer:'),'#d6dce3',.70),(lambda e:e['label'] in experts,color,.46)]:
   spans=[((r['anchor_host_midpoint_ms']+e['start_ms']-t0)/1000,(e['end_ms']-e['start_ms'])/1000) for e in r['timeline'] if selected(e)]
   ax.broken_barh(spans,(3-i-height/2,height),facecolors=fc,edgecolors='none')
 ax.set_title(title,loc='left',fontweight='bold');ax.set_yticks([3,2,1,0],['GPU0 / SM80','GPU1 / SM80','GPU2 / SM80','GPU3 / SM120']);ax.set_ylim(-.65,3.65);ax.grid(axis='x',alpha=.18);ax.set_axisbelow(True)
 ax.spines[['top','right','left']].set_visible(False)
axes[-1].set_xlabel('Seconds from first decoder layer (calibrated CUDA events)')
axes[-1].set_xlim(0,16.5)
fig.suptitle('64K prefill | chunk 2048 | fixed PP 11/11/11/12',fontweight='bold')
fig.legend(handles=[Patch(color='#d6dce3',label='Decoder layer intervals'),Patch(color='#b75628',label='EXL3 expert kernels'),Patch(color='#327ba8',label='AWQ expert kernels')],loc='outside lower center',ncol=3,frameon=False)
fig.savefig(A/'timeline.png',dpi=170)
print(A/'timeline.png')
