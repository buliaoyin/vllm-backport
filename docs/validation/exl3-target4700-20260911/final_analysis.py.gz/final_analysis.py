import gzip
import hashlib
import json
import statistics
from pathlib import Path

ROOT = Path('/home/bul/dev/vllm-backport')
OUT = Path('/tmp/exl3-target4700-20260911')

def read(name):
    return json.loads((OUT / (name + '.json')).read_text())

def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def placement(data):
    actual = [sorted(layer['index'] for layer in rank['decoder_layers'])
              for rank in sorted(data['runtime_before'], key=lambda rank: rank['pp_rank'])]
    expected = [list(range(0, 11)), list(range(11, 22)),
                list(range(22, 33)), list(range(33, 45))]
    assert actual == expected, actual
    assert data['args']['kv_cache_gib'] == 8
    assert data['args']['pp'] == 4
    return actual

baseline = read('confirmation-default')
candidate = read('confirmation-batched-int8')
confirmation = {}
for name, data, repeats in [('default', baseline, 3), ('batched_int8', candidate, 5)]:
    placement(data)
    assert len(data['perf']) == repeats
    samples = []
    for record in data['perf']:
        assert record['case'] == 'p65536_b1' and len(record['rows']) == 1
        row = record['rows'][0]
        assert row['prompt_tokens'] == 65536 and row['new_tokens'] == 32
        assert row['cached_tokens'] == 0 and all(check['matched'] for check in record['checks'])
        samples.append(65536 / row['ttft'])
    confirmation[name] = {'samples_prompt_tokens_per_second': samples,
                          'median_prompt_tokens_per_second': statistics.median(samples),
                          'median_ttft_seconds': statistics.median(r['rows'][0]['ttft'] for r in data['perf'])}
assert all(value >= 4700 for value in confirmation['batched_int8']['samples_prompt_tokens_per_second'])
confirmation['gain_percent'] = 100 * (confirmation['batched_int8']['median_prompt_tokens_per_second'] /
                                    confirmation['default']['median_prompt_tokens_per_second'] - 1)

full_inputs = json.loads(gzip.decompress((OUT / 'inputs.json.gz').read_bytes()))
confirmation_inputs = json.loads(gzip.decompress((OUT / 'confirmation-inputs.json.gz').read_bytes()))
assert confirmation_inputs['cases'] == [c for c in full_inputs['cases'] if c['name'] == 'p65536_b1']
assert baseline['inputs_sha256'] == candidate['inputs_sha256'] == digest(OUT / 'confirmation-inputs.json.gz')

quality_data = [read('quality-default'), read('quality-batched-int8')]
quality = {}
for name, data in zip(['default', 'batched_int8'], quality_data):
    placement(data)
    assert data['inputs_sha256'] == digest(OUT / 'inputs.json.gz')
    assert data['args']['eval_batch_size'] == 1 and data['args']['eval_tokens'] == 768
    assert len(data['eval']) == 64
    quality[name] = {'correct': sum(row['correct'] for row in data['eval']),
                     'total': len(data['eval']),
                     'wrong_ids': [row['id'] for row in data['eval'] if not row['correct']],
                     'truncated': sum(row['finish_reason'] == 'length' for row in data['eval'])}
    assert quality[name]['truncated'] == 0
q0, q1 = [data['eval'] for data in quality_data]
assert [r['id'] for r in q0] == [r['id'] for r in q1]
quality['same_answers'] = sum(a['predicted'] == b['predicted'] for a, b in zip(q0, q1))
quality['same_token_sequences'] = sum(a['token_ids'] == b['token_ids'] for a, b in zip(q0, q1))
quality['new_wrong_ids'] = [b['id'] for a, b in zip(q0, q1) if a['correct'] and not b['correct']]
assert not quality['new_wrong_ids']

runtime = {}
for name, data, minimum in [('confirmation', candidate, 4096), ('quality', quality_data[1], 9)]:
    ranks = []
    for rank in sorted(data['runtime_after'], key=lambda r: r['pp_rank']):
        backend = rank['batched_int8_prefill']
        cache_bytes = sum(device['bytes'] for device in rank['linear_cache']['devices'].values())
        if rank['pp_rank'] < 3:
            assert backend['variant'] == 'm64n128k64'
            assert backend['minimum_rows'] == minimum and backend['calls'] > 0
            assert backend['fallback_calls'] == 0
            assert all(kernel['imma'] for kernel in backend['gemm_kernels'].values())
        else:
            assert backend is None and cache_bytes == 0
        ranks.append({'pp_rank': rank['pp_rank'], 'native_workspace_bytes': rank['workspace_bytes'],
                      'ordinary_cache_bytes': cache_bytes, 'backend': backend})
    runtime[name] = ranks

status = {}
for name, count in [('confirmation-status', 2), ('quality-status', 2)]:
    records = read(name)
    assert len(records) == count and all(record.get('exit_code') == 0 for record in records)
    status[name] = [{'name': record['name'], 'exit_code': record['exit_code']} for record in records]

sweep = {}
for path in sorted(OUT.glob('model-*.json')):
    data = json.loads(path.read_text())
    if 'perf' not in data or not data['perf']:
        continue
    placement(data)
    lengths = {}
    for record in data['perf']:
        row = record['rows'][0]
        assert len(record['rows']) == 1 and row['cached_tokens'] == 0
        assert all(check['matched'] for check in record['checks'])
        lengths.setdefault(str(row['prompt_tokens']), []).append(row['prompt_tokens'] / row['ttft'])
    sweep[path.stem] = {length: {'repeats': len(values), 'median': statistics.median(values)}
                        for length, values in lengths.items()}

production_library = ROOT / 'vllm/_exl3_C.abi3.so'
assert digest(production_library) == '9e62ea06512b1c1a89a2966d25f429597735993cb0af3ef59aa07082113600a9'
result = {'metric': 'prompt tokens / TTFT; independent confirmation excludes diagnostic event request',
          'confirmation': confirmation, 'quality': quality, 'runtime': runtime,
          'sweep': sweep, 'status': status, 'layer_indices': placement(candidate),
          'production_library_sha256': digest(production_library),
          'measurement_script_sha256': digest(OUT / 'benchmark_model.py'),
          'confirmation_inputs_sha256': digest(OUT / 'confirmation-inputs.json.gz')}
(OUT / 'final-analysis.json').write_text(json.dumps(result, indent=2))
print(json.dumps({'confirmation': confirmation, 'quality': quality, 'full_model_runs': len(sweep)}, indent=2))
