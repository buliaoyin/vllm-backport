import json,statistics
from pathlib import Path
O=Path(__file__).parent
results=[]
for path in sorted(O.glob('timeline-*.json')):
 if path.name.startswith('timeline-inputs-') or path.name=='timeline-status.json':continue
 d=json.loads(path.read_text())
 if 'event_profile' not in d:continue
 stages=[];summaries=[]
 for rank,rt in zip(d['event_profile']['ranks'],d['runtime_before']):
  layers=[e for e in rank['timeline'] if e['label'].startswith('layer:')]
  names=['layer:'+x['name'] for x in rt['decoder_layers']]
  n=len(names);assert len(layers)%n==0
  expert_labels={'moe_m32','exl3_moe','marlin_gemm'}
  expert=[e for e in rank['timeline'] if e['label'] in expert_labels]
  anchor=rank['anchor_host_midpoint_ms'];nodes=[]
  for j in range(len(layers)//n):
   ls=layers[j*n:(j+1)*n];assert [e['label'] for e in ls]==names
   start,end=ls[0]['start_ms'],ls[-1]['end_ms']
   active=[e for e in expert if e['start_ms']>=start-0.001 and e['end_ms']<=end+0.001]
   nodes.append(dict(start=start+anchor,end=end+anchor,expert_ms=sum(e['end_ms']-e['start_ms'] for e in active),layer_ms=sum(e['end_ms']-e['start_ms'] for e in ls)))
  stages.append(nodes)
  summaries.append(dict(rank=rt['pp_rank'],layer_ms=sum(e['end_ms']-e['start_ms'] for e in layers),expert_ms=sum(e['end_ms']-e['start_ms'] for e in expert),uncertainty_ms=rank['anchor_uncertainty_ms'],chunks=len(nodes)))
 # A flow-shop path, using observed stage completion order. Scheduler gaps are
 # explicit; they may change if a kernel is accelerated, so this is not proof
 # of a counterfactual request latency.
 n=len(stages[0]);assert all(len(s)==n for s in stages)
 r,j=3,n-1;critical=[];negative=[]
 while True:
  node=stages[r][j];prev=[]
  if r:prev.append((stages[r-1][j]['end'],r-1,j))
  if j:prev.append((stages[r][j-1]['end'],r,j-1))
  gap=0 if not prev else node['start']-max(prev)[0]
  if gap<-.1:negative.append((r,j,gap))
  critical.append(dict(rank=r,chunk=j,**node,gap_ms=gap))
  if not prev:break
  _,r,j=max(prev)
 span=stages[-1][-1]['end']-stages[0][0]['start']
 result=dict(name=path.stem,clean_prefill_tps=statistics.median(65536/r['max_ttft'] for r in d['perf']),request_ms=1000*d['event_profile']['seconds'],layer_span_ms=span,ranks=summaries,observed_flowshop_path_expert_ms=sum(x['expert_ms'] for x in critical),observed_flowshop_path_layer_ms=sum(x['layer_ms'] for x in critical),observed_flowshop_path_gap_ms=sum(x['gap_ms'] for x in critical),negative_gaps=negative,path=critical)
 results.append(result)
 print(result['name'],'clean',round(result['clean_prefill_tps'],1),'profile',round(result['request_ms'],1),'span',round(span,1))
 for row in summaries:print(row)
 print('Approx path: expert',round(result['observed_flowshop_path_expert_ms'],1),'layers',round(result['observed_flowshop_path_layer_ms'],1),'gap',round(result['observed_flowshop_path_gap_ms'],1),'negative gaps',negative)
(O/'timeline-analysis.json').write_text(json.dumps(results,indent=2))
