import contextlib
import importlib.util
import io
import json
import sys
import tempfile
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import patch

ROOT = Path('/home/bul/dev/vllm-backport')
spec = importlib.util.spec_from_file_location('exl3_benchmark_check', ROOT / 'benchmarks/benchmark_exl3.py')
module = importlib.util.module_from_spec(spec)
spec.loader.exec_module(module)

with tempfile.TemporaryDirectory(prefix='exl3-cli-check-') as temporary:
    base = Path(temporary)
    inputs = base / 'inputs.json'
    inputs.write_text(json.dumps({'model': 'unused', 'eos_ids': [], 'cases': [],
                                 'evals': [{'id': i, 'input_ids': [1], 'answer': '42'} for i in range(5)]}))
    checks = []
    for backend, explicit_batch, extension in [('vllm', None, False), ('vllm', 1, True),
                                              ('exllamav3', 1, False)]:
        batches, rpc = [], []
        class FakeBackend:
            def __init__(self, args, data):
                self.module_devices = []
                if backend == 'vllm':
                    def collective(method):
                        rpc.append(method)
                        return [{'calls': len(batches)}]
                    config = SimpleNamespace(scheduler_config=SimpleNamespace(max_num_batched_tokens=6144))
                    self.llm = SimpleNamespace(collective_rpc=collective,
                                               llm_engine=SimpleNamespace(vllm_config=config))
            def generate(self, ids, max_tokens, fixed):
                assert not fixed and max_tokens == 768
                batches.append(len(ids))
                return 0.0, [{'text': '42'} for _ in ids]
        output = base / f'{backend}-{explicit_batch}.json'
        args = ['benchmark_exl3.py', '--backend', backend, '--inputs', str(inputs),
                '--output', str(output), '--skip-perf', '--batch-size', '4', '--chunk-size', '6144']
        if explicit_batch:
            args += ['--eval-batch-size', str(explicit_batch)]
        if extension:
            args += ['--worker-extension-cls', 'unused.example.Worker']
        fake_modules = {'exllamav3': SimpleNamespace(),
                        'exllamav3.version': SimpleNamespace(__version__='fixture')}
        with patch.object(sys, 'argv', args), patch.object(module, 'VllmBackend', FakeBackend), \
             patch.object(module, 'ExllamaBackend', FakeBackend), \
             patch.object(module.torch.accelerator, 'device_count', return_value=0), \
             patch.object(module.importlib.metadata, 'version', return_value='fixture'), \
             patch.dict(sys.modules, fake_modules), contextlib.redirect_stdout(io.StringIO()):
            module.main()
        result = json.loads(output.read_text())
        assert batches == ([1] * 5 if explicit_batch == 1 else [4, 1])
        assert len(result['eval']) == 5 and all(r['correct'] for r in result['eval'])
        assert len(rpc) == (2 if extension else 0)
        assert ('runtime_after' in result) == extension
        assert ('resolved_chunk_size' in result) == (backend == 'vllm')
        checks.append({'backend': backend, 'eval_batch': explicit_batch, 'extension': extension, 'batches': batches})
    for invalid in [0, 5]:
        with patch.object(sys, 'argv', ['benchmark_exl3.py', '--backend', 'vllm', '--inputs', str(inputs),
                                      '--output', str(base / 'invalid.json'), '--eval-batch-size', str(invalid)]), \
             contextlib.redirect_stderr(io.StringIO()):
            try:
                module.main()
            except SystemExit as error:
                assert error.code == 2
            else:
                raise AssertionError('Invalid batch accepted')
    print(json.dumps({'passed': 5, 'scope': 'CPU benchmark control flow; no GPU/model simulation claim', 'cases': checks}, indent=2))
