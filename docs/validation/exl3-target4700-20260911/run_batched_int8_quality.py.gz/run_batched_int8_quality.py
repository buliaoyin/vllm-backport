import json,os,statistics,subprocess,time
from pathlib import Path
R=Path('/home/bul/dev/vllm-backport');O=Path('/tmp/exl3-target4700-20260911');P=str(R/'.venv/bin/python');B=O/'kernels-batched-int8-r1/helpers.so'
while True:
 records=json.loads((O/'batched-int8-model-status.json').read_text())
 if any(r.get('exit_code',0)!=0 for r in records):raise RuntimeError('INT8 candidate validation failed')
 models=[r for r in records if r['name'].startswith('model-batched-int8-cache-')]
 if len(models)==3 and all(r.get('exit_code')==0 for r in models):break
 time.sleep(5)
scores=[]
for r in models:
 d=json.loads((O/(r['name']+'.json')).read_text());scores.append((statistics.median(65536/p['rows'][0]['ttft'] for p in d['perf'] if p['case']=='p65536_b1'),int(r['name'].split('-')[-1])))
best_tps,best_chunk=max(scores)
(O/'quality-candidate-selection.json').write_text(json.dumps({'best_tps':best_tps,'chunk':best_chunk,'all_candidates':scores,'eval_minimum_rows':9,'reason':'Force the new prefill arithmetic on every GSM8K prompt; short prompts would otherwise fall back.'},indent=2))
status=[]
for name,chunk,prototype in [('quality-default',2048,False),('quality-batched-int8',best_chunk,True)]:
 env={k:v for k,v in os.environ.items() if not k.startswith(('EXL3_','VLLM_EXL3_'))}
 env.update(CUDA_DEVICE_ORDER='PCI_BUS_ID',CUDA_VISIBLE_DEVICES='0,1,2,3',OMP_NUM_THREADS='1',NCCL_P2P_DISABLE='1',VLLM_PP_LAYER_PARTITION='11,11,11,12',VLLM_EXL3_MOE_MAX_TOKENS=str(chunk),PYTHONPATH=str(R)+'/benchmarks:'+str(R),VLLM_TRITON_USE_TD='0')
 worker='benchmarks.kernels.exl3_prefill.worker.WorkerExtension'
 if prototype:
  env.update(VLLM_EXL3_BATCHED_INT8_LIBRARY=str(B),VLLM_EXL3_BATCHED_INT8_CONFIG='m64n128k64',VLLM_EXL3_LINEAR_CACHE_GIB='4',VLLM_EXL3_BATCHED_INT8_MIN_ROWS='9')
  worker='benchmarks.kernels.exl3_prefill_int8.worker.WorkerExtension'
 cmd=[P,str(O/'benchmark_model.py'),'--backend','vllm','--inputs',str(O/'inputs.json.gz'),'--output',str(O/f'{name}.json'),'--pp','4','--expected-layer-counts','11','11','11','12','--max-model-len','66560','--kv-cache-gib','8','--batch-size','4','--chunk-size',str(chunk),'--tokens','32','--skip-perf','--eval-batch-size','1','--eval-tokens','768','--worker-extension-cls',worker]
 rec={'name':name,'command':cmd,'environment':{k:v for k,v in env.items() if k.startswith(('CUDA_','EXL3_','VLLM_','NCCL_','OMP_','PYTHONPATH'))},'start':time.time()};status.append(rec);(O/'quality-status.json').write_text(json.dumps(status,indent=2));print('START',name,flush=True)
 with (O/f'{name}.log').open('w') as log:p=subprocess.run(cmd,cwd=R,env=env,stdout=log,stderr=subprocess.STDOUT,timeout=1500)
 rec.update(exit_code=p.returncode,end=time.time());(O/'quality-status.json').write_text(json.dumps(status,indent=2));print('DONE',name,p.returncode,flush=True)
 if p.returncode:raise SystemExit(p.returncode)
 d=json.loads((O/f'{name}.json').read_text());assert len(d['eval'])==64
 if prototype:
  for rt in d['runtime_after']:
   if rt['pp_rank']<3:
    assert rt['batched_int8_prefill']['minimum_rows']==9
    assert rt['batched_int8_prefill']['calls']>=512
