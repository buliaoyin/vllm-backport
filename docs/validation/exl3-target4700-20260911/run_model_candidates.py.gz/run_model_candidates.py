import hashlib,json,os,subprocess,time
from pathlib import Path
R=Path('/home/bul/dev/vllm-backport');O=Path('/tmp/exl3-target4700-20260911');P=str(R/'.venv/bin/python')
source_files=[*Path(R/'benchmarks/kernels/exl3_prefill').glob('*.py'),R/'vllm/model_executor/layers/quantization/exl3.py',R/'benchmarks/exl3_profile_worker.py',R/'vllm/_exl3_C.abi3.so']
(O/'candidate-sources.json').write_text(json.dumps({str(f):hashlib.sha256(f.read_bytes()).hexdigest() for f in source_files},indent=2))
status=[]
for name,variant,library,chunk,cache in [
 ('model-k16-2048','k16_resident','kernels-r1',2048,0),
 ('model-k16-cache-2048','k16_resident','kernels-r1',2048,4),
 ('model-k16-cache-3072','k16_resident','kernels-r1',3072,4),
 ('model-m64-cache-4096','cached_m64_n256_k128','kernels-r4',4096,4),
 ('model-default-after',None,None,2048,0),
]:
 env={k:v for k,v in os.environ.items() if not k.startswith(('EXL3_','VLLM_EXL3_'))}
 env.update(CUDA_DEVICE_ORDER='PCI_BUS_ID',CUDA_VISIBLE_DEVICES='0,1,2,3',OMP_NUM_THREADS='1',NCCL_P2P_DISABLE='1',VLLM_PP_LAYER_PARTITION='11,11,11,12',VLLM_EXL3_MOE_MAX_TOKENS=str(chunk),PYTHONPATH=str(R)+'/benchmarks:'+str(R))
 if variant:env.update(VLLM_EXL3_EXPERIMENTAL_PREFILL=variant,VLLM_EXL3_PREFILL_LIBRARY=str(O/library/'prefill.so'))
 if cache:env['VLLM_EXL3_LINEAR_CACHE_GIB']=str(cache)
 cmd=[P,str(O/'benchmark_model.py'),'--backend','vllm','--inputs',str(O/'inputs.json.gz'),'--output',str(O/f'{name}.json'),'--pp','4','--expected-layer-counts','11','11','11','12','--max-model-len','66560','--kv-cache-gib','8','--batch-size','4','--chunk-size',str(chunk),'--warmups','1','--repeats','3','--tokens','32','--skip-eval','--worker-extension-cls','benchmarks.kernels.exl3_prefill.worker.WorkerExtension']
 rec={'name':name,'command':cmd,'environment':{k:v for k,v in env.items() if k.startswith(('CUDA_','EXL3_','VLLM_','NCCL_','OMP_','PYTHONPATH'))},'start':time.time()};status.append(rec);(O/'candidate-status.json').write_text(json.dumps(status,indent=2));print('START',name,flush=True)
 with (O/f'{name}.log').open('w') as log:p=subprocess.run(cmd,cwd=R,env=env,stdout=log,stderr=subprocess.STDOUT,timeout=600)
 rec.update(exit_code=p.returncode,end=time.time());(O/'candidate-status.json').write_text(json.dumps(status,indent=2));print('DONE',name,p.returncode,flush=True)
 if p.returncode:raise SystemExit(p.returncode)
 data=json.loads((O/f'{name}.json').read_text())
 assert all(c['matched'] for row in data['perf'] for c in row['checks'])
 for rt in data['runtime_after']:
  if variant and rt['pp_rank']<3:
   assert rt['prefill_experiment']['variant']==variant
   assert rt['prefill_experiment']['workspace_bytes']>0
  if cache and rt['pp_rank']<3:
   assert rt['linear_cache']['hits']>0
   assert sum(d['bytes'] for d in rt['linear_cache']['devices'].values())>0
