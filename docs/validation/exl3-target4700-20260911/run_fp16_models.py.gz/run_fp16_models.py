import hashlib,json,os,subprocess,time
from pathlib import Path
R=Path('/home/bul/dev/vllm-backport');O=Path('/tmp/exl3-target4700-20260911');P=str(R/'.venv/bin/python')
sources=[*Path(R/'benchmarks/kernels/exl3_prefill').glob('*.py'),*Path(R/'benchmarks/kernels/exl3_prefill_fp16').glob('*.py'),R/'vllm/model_executor/layers/quantization/exl3.py',R/'benchmarks/exl3_profile_worker.py',R/'vllm/_exl3_C.abi3.so']
(O/'fp16-model-sources.json').write_text(json.dumps({str(f):hashlib.sha256(f.read_bytes()).hexdigest() for f in sources},indent=2))
status=[]
for name,chunk,cache in [('model-fp16-8192',8192,0),('model-fp16-cache-8192',8192,4),('model-fp16-cache-6144',6144,4),('model-fp16-cache-4096',4096,4)]:
 env={k:v for k,v in os.environ.items() if not k.startswith(('EXL3_','VLLM_EXL3_'))}
 env.update(CUDA_DEVICE_ORDER='PCI_BUS_ID',CUDA_VISIBLE_DEVICES='0,1,2,3',OMP_NUM_THREADS='1',NCCL_P2P_DISABLE='1',VLLM_PP_LAYER_PARTITION='11,11,11,12',VLLM_EXL3_MOE_MAX_TOKENS=str(chunk),PYTHONPATH=str(R)+'/benchmarks:'+str(R),VLLM_EXL3_FP16_LIBRARY=str(O/'kernels-fp16-commit/helpers.so'),VLLM_EXL3_FP16_CONFIG='m64n128k64',VLLM_TRITON_USE_TD='0')
 if cache:env['VLLM_EXL3_LINEAR_CACHE_GIB']=str(cache)
 cmd=[P,str(O/'benchmark_model.py'),'--backend','vllm','--inputs',str(O/'inputs.json.gz'),'--output',str(O/f'{name}.json'),'--pp','4','--expected-layer-counts','11','11','11','12','--max-model-len','66560','--kv-cache-gib','8','--batch-size','4','--chunk-size',str(chunk),'--warmups','1','--repeats','3','--tokens','32','--skip-eval','--worker-extension-cls','benchmarks.kernels.exl3_prefill_fp16.worker.WorkerExtension']
 rec={'name':name,'command':cmd,'environment':{k:v for k,v in env.items() if k.startswith(('CUDA_','EXL3_','VLLM_','NCCL_','OMP_','PYTHONPATH'))},'start':time.time()};status.append(rec);(O/'fp16-model-status.json').write_text(json.dumps(status,indent=2));print('START',name,flush=True)
 with (O/f'{name}.log').open('w') as log:p=subprocess.run(cmd,cwd=R,env=env,stdout=log,stderr=subprocess.STDOUT,timeout=600)
 rec.update(exit_code=p.returncode,end=time.time());(O/'fp16-model-status.json').write_text(json.dumps(status,indent=2));print('DONE',name,p.returncode,flush=True)
 if p.returncode:raise SystemExit(p.returncode)
 data=json.loads((O/f'{name}.json').read_text())
 assert all(c['matched'] for row in data['perf'] for c in row['checks'])
 for rt in data['runtime_after']:
  if rt['pp_rank']<3:
   assert rt['fp16_prefill']['calls']>0 and rt['fp16_prefill']['workspace_bytes']>0
  else:assert rt['fp16_prefill'] is None
