import gzip,hashlib,json,os,subprocess,time
from pathlib import Path
R=Path('/home/bul/dev/vllm-backport');O=Path('/tmp/exl3-target4700-20260911');P=str(R/'.venv/bin/python');B=O/'kernels-batched-int8-r1/helpers.so'
while True:
 f=O/'quality-status.json'
 if f.exists():
  records=json.loads(f.read_text())
  if any(r.get('exit_code',0)!=0 for r in records):raise RuntimeError('Quality runner failed')
  if len(records)==2 and all(r.get('exit_code')==0 for r in records):break
 time.sleep(5)
selection=json.loads((O/'quality-candidate-selection.json').read_text());chunk=selection['chunk']
data=json.loads(gzip.decompress((O/'inputs.json.gz').read_bytes()));data['cases']=[c for c in data['cases'] if c['name']=='p65536_b1'];assert len(data['cases'])==1
inputs=O/'confirmation-inputs.json.gz';inputs.write_bytes(gzip.compress(json.dumps(data).encode(),mtime=0))
status=[]
for name,chunk_size,prototype,repeats in [('confirmation-default',2048,False,3),('confirmation-batched-int8',chunk,True,5)]:
 env={k:v for k,v in os.environ.items() if not k.startswith(('EXL3_','VLLM_EXL3_'))}
 env.update(CUDA_DEVICE_ORDER='PCI_BUS_ID',CUDA_VISIBLE_DEVICES='0,1,2,3',OMP_NUM_THREADS='1',NCCL_P2P_DISABLE='1',VLLM_PP_LAYER_PARTITION='11,11,11,12',VLLM_EXL3_MOE_MAX_TOKENS=str(chunk_size),PYTHONPATH=str(R)+'/benchmarks:'+str(R),VLLM_TRITON_USE_TD='0')
 worker='benchmarks.kernels.exl3_prefill.worker.WorkerExtension'
 if prototype:
  env.update(VLLM_EXL3_BATCHED_INT8_LIBRARY=str(B),VLLM_EXL3_BATCHED_INT8_CONFIG='m64n128k64',VLLM_EXL3_LINEAR_CACHE_GIB='4',VLLM_EXL3_BATCHED_INT8_MIN_ROWS='4096')
  worker='benchmarks.kernels.exl3_prefill_int8.worker.WorkerExtension'
 cmd=[P,str(O/'benchmark_model.py'),'--backend','vllm','--inputs',str(inputs),'--output',str(O/f'{name}.json'),'--pp','4','--expected-layer-counts','11','11','11','12','--max-model-len','66560','--kv-cache-gib','8','--batch-size','4','--chunk-size',str(chunk_size),'--warmups','1','--repeats',str(repeats),'--tokens','32','--skip-eval','--worker-extension-cls',worker]
 if prototype:cmd+=['--event-profile']
 rec={'name':name,'command':cmd,'environment':{k:v for k,v in env.items() if k.startswith(('CUDA_','EXL3_','VLLM_','NCCL_','OMP_','PYTHONPATH'))},'start':time.time()};status.append(rec);(O/'confirmation-status.json').write_text(json.dumps(status,indent=2));print('START',name,flush=True)
 with (O/f'{name}.log').open('w') as log:p=subprocess.run(cmd,cwd=R,env=env,stdout=log,stderr=subprocess.STDOUT,timeout=900)
 rec.update(exit_code=p.returncode,end=time.time());(O/'confirmation-status.json').write_text(json.dumps(status,indent=2));print('DONE',name,p.returncode,flush=True)
 if p.returncode:raise SystemExit(p.returncode)
 d=json.loads((O/f'{name}.json').read_text());assert all(c['matched'] for r in d['perf'] for c in r['checks'])
 if prototype:
  for rt in d['runtime_after']:
   if rt['pp_rank']<3:assert rt['batched_int8_prefill']['minimum_rows']==4096
