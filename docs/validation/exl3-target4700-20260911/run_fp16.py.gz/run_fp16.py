import json,os,subprocess,time
from pathlib import Path
R=Path('/home/bul/dev/vllm-backport');O=Path('/tmp/exl3-target4700-20260911');B=O/'kernels-fp16-r1';P=str(R/'.venv/bin/python')
while True:
 records=json.loads((O/'candidate-status.json').read_text())
 if any(r.get('exit_code',0)!=0 for r in records):raise RuntimeError('Model candidate failed')
 if len(records)==5 and all(r.get('exit_code')==0 for r in records):break
 time.sleep(5)
status=[]
def run(name,cmd,env=None):
 rec={'name':name,'command':cmd,'start':time.time()};status.append(rec);(O/'fp16-status.json').write_text(json.dumps(status,indent=2));print('START',name,flush=True)
 with (O/(name+'.log')).open('w') as log:p=subprocess.run(cmd,cwd=R,env=env,stdout=log,stderr=subprocess.STDOUT,timeout=900)
 rec.update(end=time.time(),exit_code=p.returncode);(O/'fp16-status.json').write_text(json.dumps(status,indent=2));print('DONE',name,p.returncode,flush=True)
 if p.returncode:raise SystemExit(p.returncode)
run('build-fp16-r1',[P,'benchmarks/kernels/exl3_prefill_fp16/build.py','--build-dir',str(B)])
env={k:v for k,v in os.environ.items() if not k.startswith(('EXL3_','VLLM_EXL3_'))};env.update(CUDA_VISIBLE_DEVICES='0',CUDA_DEVICE_ORDER='PCI_BUS_ID',EXL3_INT8_GEMV='0',OMP_NUM_THREADS='1',PYTHONPATH=str(R),VLLM_EXL3_TEST_FP16_PREFILL_LIBRARY=str(B/'helpers.so'),VLLM_TRITON_USE_TD='0')
run('fp16-tests',[P,'-m','pytest','tests/quantization/test_exl3.py','-q','-x','-k','experimental_batched_fp16_prefill'],env)
env['VLLM_EXL3_MOE_MAX_TOKENS']='8192'
for layer in (22,3):
 run('fp16-layer'+str(layer),[P,'-m','benchmarks.kernels.exl3_prefill_fp16.benchmark','--checkpoint','/home/bul/dev/models1/zai/turboderp/GLM-5.3-Flash-exl3/4.05bpw','--prefix',f'model.language_model.layers.{layer}.mlp.experts','--routes',str(O/f'routes-c2048/layer-{layer}.pt'),'--library',str(B/'helpers.so'),'--output',str(O/f'fp16-layer{layer}.json'),'--rows','2048','4096','8192','--repeats','15'],env)
