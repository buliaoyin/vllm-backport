import hashlib,json,os,subprocess,time
from pathlib import Path
R=Path('/home/bul/dev/vllm-backport');O=Path('/tmp/exl3-target4700-20260911');P=str(R/'.venv/bin/python');B=O/'kernels-batched-int8-r1/helpers.so'
status=[]
def run(name,cmd,env):
 rec={'name':name,'command':cmd,'environment':{k:v for k,v in env.items() if k.startswith(('CUDA_','EXL3_','VLLM_','NCCL_','OMP_','PYTHONPATH'))},'start':time.time()};status.append(rec);(O/'batched-int8-model-status.json').write_text(json.dumps(status,indent=2));print('START',name,flush=True)
 with (O/(name+'.log')).open('w') as log:p=subprocess.run(cmd,cwd=R,env=env,stdout=log,stderr=subprocess.STDOUT,timeout=900)
 rec.update(exit_code=p.returncode,end=time.time());(O/'batched-int8-model-status.json').write_text(json.dumps(status,indent=2));print('DONE',name,p.returncode,flush=True)
 if p.returncode:raise SystemExit(p.returncode)
source_files=[*Path(R/'benchmarks/kernels/exl3_prefill_int8').glob('*.py'),R/'benchmarks/kernels/exl3_prefill_fp16/backend.py',R/'benchmarks/kernels/exl3_prefill/worker.py',R/'benchmarks/kernels/exl3_prefill/linear_cache.py',R/'vllm/model_executor/layers/quantization/exl3.py']
(O/'batched-int8-model-sources.json').write_text(json.dumps({str(f):hashlib.sha256(f.read_bytes()).hexdigest() for f in source_files},indent=2))
env={k:v for k,v in os.environ.items() if not k.startswith(('EXL3_','VLLM_EXL3_'))};env.update(CUDA_VISIBLE_DEVICES='0',CUDA_DEVICE_ORDER='PCI_BUS_ID',EXL3_INT8_GEMV='0',OMP_NUM_THREADS='1',PYTHONPATH=str(R),VLLM_EXL3_TEST_BATCHED_INT8_LIBRARY=str(B),VLLM_TRITON_USE_TD='0')
run('batched-int8-final-tests',[P,'-m','pytest','tests/quantization/test_exl3.py','-q','-x','-k','experimental_batched_int8_prefill'],env)
env['VLLM_EXL3_MOE_MAX_TOKENS']='8192'
for kind,lib in [('fp16',O/'kernels-fp16-commit/helpers.so'),('int8',B)]:
 run('phase-profile-'+kind+'-external',[P,'-m','benchmarks.kernels.exl3_prefill_fp16.profile','--backend',kind,'--checkpoint','/home/bul/dev/models1/zai/turboderp/GLM-5.3-Flash-exl3/4.05bpw','--prefix','model.language_model.layers.22.mlp.experts','--routes',str(O/'routes-c2048/layer-22.pt'),'--library',str(lib),'--rows','8192','--output',str(O/f'phase-profile-{kind}-external.json')],env)
for chunk in (6144,8192,4096):
 name=f'model-batched-int8-cache-{chunk}'
 env={k:v for k,v in os.environ.items() if not k.startswith(('EXL3_','VLLM_EXL3_'))}
 env.update(CUDA_DEVICE_ORDER='PCI_BUS_ID',CUDA_VISIBLE_DEVICES='0,1,2,3',OMP_NUM_THREADS='1',NCCL_P2P_DISABLE='1',VLLM_PP_LAYER_PARTITION='11,11,11,12',VLLM_EXL3_MOE_MAX_TOKENS=str(chunk),PYTHONPATH=str(R)+'/benchmarks:'+str(R),VLLM_EXL3_BATCHED_INT8_LIBRARY=str(B),VLLM_EXL3_BATCHED_INT8_CONFIG='m64n128k64',VLLM_EXL3_LINEAR_CACHE_GIB='4',VLLM_TRITON_USE_TD='0')
 cmd=[P,str(O/'benchmark_model.py'),'--backend','vllm','--inputs',str(O/'inputs.json.gz'),'--output',str(O/f'{name}.json'),'--pp','4','--expected-layer-counts','11','11','11','12','--max-model-len','66560','--kv-cache-gib','8','--batch-size','4','--chunk-size',str(chunk),'--warmups','1','--repeats','3','--tokens','32','--skip-eval','--worker-extension-cls','benchmarks.kernels.exl3_prefill_int8.worker.WorkerExtension']
 run(name,cmd,env)
 data=json.loads((O/f'{name}.json').read_text())
 assert all(c['matched'] for row in data['perf'] for c in row['checks'])
 for rt in data['runtime_after']:
  if rt['pp_rank']<3:
   assert rt['batched_int8_prefill']['calls']>0
   assert all(m['imma'] for m in rt['batched_int8_prefill']['gemm_kernels'].values())
  else:assert rt['batched_int8_prefill'] is None
