from pathlib import Path
p=Path('benchmarks/kernels/benchmark_exl3_moe.py');s=p.read_text().replace('import argparse\n','import argparse\nimport itertools\n')
s=s.replace('def fused_with_chunk(inputs, chunk_size):','def fused_with_chunk(inputs, chunk_size, groups=-1, splits=1, split_threshold=0, packing="sort", longest_first=False):')
s=s.replace('        order = torch.argsort(ids, stable=True)\n        counts = torch.zeros(ptrs[0].numel() + 1, dtype=torch.int64, device=x.device)', '''        chunk_ptrs = ptrs
        if splits > 1:
            sub_ids = torch.arange(hidden.shape[0], device=x.device).repeat_interleave(topk_ids.shape[1]) % splits
            if split_threshold:
                original_counts = torch.zeros(ptrs[0].numel() // splits + 1, dtype=torch.int64, device=x.device)
                original_counts.scatter_add_(0, ids, torch.ones_like(ids))
                sub_ids = torch.where(original_counts[ids] >= split_threshold, sub_ids, 0)
            ids = ids * splits + sub_ids
        counts = torch.zeros(ptrs[0].numel() + 1, dtype=torch.int64, device=x.device)''')
s=s.replace('        counts.scatter_add_(0, ids, torch.ones_like(ids))\n        tokens = torch.div(order, topk_ids.shape[1], rounding_mode="floor")', '''        counts.scatter_add_(0, ids, torch.ones_like(ids))
        if longest_first:
            permutation = torch.argsort(counts[:-1], descending=True, stable=True)
            inverse = torch.empty_like(permutation)
            inverse.scatter_(0, permutation, torch.arange(permutation.numel(), device=x.device))
            ids = inverse[ids]
            counts = torch.cat((counts[:-1][permutation], counts[-1:]))
            chunk_ptrs = [ptr[permutation] for ptr in ptrs]
        if packing == "align":
            from vllm.model_executor.layers.fused_moe.moe_align_block_size import moe_align_block_size
            order = moe_align_block_size(ids.view(-1, topk_ids.shape[1]), 1, ptrs[0].numel())[0].long()
        else:
            order = torch.argsort(ids, stable=True)
        tokens = torch.div(order, topk_ids.shape[1], rounding_mode="floor")''')
s=s.replace('            *ptrs,\n            *flags,\n            limit,\n            -1,','            *chunk_ptrs,\n            *flags,\n            limit,\n            groups,',1)
s=s.replace('        x = torch.randn(rows, k, device="cuda", dtype=torch.bfloat16)\n        scores =', '        x = torch.randn(rows, k, device="cuda", dtype=torch.bfloat16)\n        scores =',1)
s=s.replace('        weights = torch.rand(rows, 8, device="cuda").softmax(-1)\n        inputs = (', '''        weights = torch.rand(rows, 8, device="cuda").softmax(-1)
        if args.route_sample:
            sample = torch.load(args.route_sample, weights_only=True, map_location="cuda")
            assert rows <= sample["x"].shape[0]
            x, weights, ids = (sample[name][:rows].contiguous() for name in ("x", "weights", "ids"))
        inputs = (''',1)
s=s.replace('        reference = _exl3_moe_fused(*inputs)', '        reference = fused_with_chunk(inputs, 128)',1)
s=s.replace('        for chunk in args.prefill_chunks:', '''        candidates = list(itertools.product(args.prefill_chunks, args.prefill_groups, args.expert_splits, args.split_thresholds, args.packing, args.longest_first))
        for chunk, groups, splits, threshold, packing, longest_first in candidates:
            if splits == 1 and threshold:
                continue''',1)
s=s.replace('            candidate_inputs = (*inputs[:4], workspace, *inputs[5:])','            pointers = [ptr.repeat_interleave(splits) for ptr in method.ptrs] if splits > 1 else method.ptrs\n            candidate_inputs = (*inputs[:3], pointers, workspace, *inputs[5:])\n            options = (chunk, groups, splits, threshold, packing, bool(longest_first))',1)
s=s.replace('                "workspace_rows": capacity,','                "groups": groups,\n                "splits": splits,\n                "split_threshold": threshold,\n                "packing": packing,\n                "longest_first": bool(longest_first),\n                "workspace_rows": capacity,',1)
s=s.replace('fused_with_chunk(candidate_inputs, chunk)','fused_with_chunk(candidate_inputs, *options)')
s=s.replace('input_args=(candidate_inputs, chunk),','input_args=(candidate_inputs, *options),')
s=s.replace('        "routing": args.routing,','        "routing": str(args.route_sample) if args.route_sample else args.routing,')
s=s.replace('    parser.add_argument("--routing", choices=["uniform", "hot"], default="uniform")','''    parser.add_argument("--routing", choices=["uniform", "hot"], default="uniform")
    parser.add_argument("--route-sample", type=Path)
    parser.add_argument("--prefill-groups", type=int, nargs="+", default=[-1])
    parser.add_argument("--expert-splits", type=int, nargs="+", default=[1])
    parser.add_argument("--split-thresholds", type=int, nargs="+", default=[0])
    parser.add_argument("--packing", choices=["sort", "align"], nargs="+", default=["sort"])
    parser.add_argument("--longest-first", type=int, choices=[0, 1], nargs="+", default=[0])''')
p.write_text(s)
