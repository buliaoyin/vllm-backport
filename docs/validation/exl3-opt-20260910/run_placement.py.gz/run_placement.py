import gzip,hashlib,json,os,subprocess,time
from pathlib import Path
root=Path('/tmp/exl3-opt-20260910')
sources=['vllm/model_executor/layers/quantization/exl3.py','vllm/envs.py','benchmarks/benchmark_exl3.py','benchmarks/exl3_profile_worker.py','benchmarks/kernels/benchmark_exl3_moe.py']
jobs=[
 ('equal-c1024','11,11,11,12',1024,1024),
 ('pp19-c1024','10,8,8,19',1024,1024),
 ('pp21-c1024','10,7,7,21',1024,1024),
 ('pp21-c512','10,7,7,21',512,512),
 ('pp21-c2048','10,7,7,21',2048,2048),
]
status=[]
for name,partition,chunk,capacity in jobs:
 cmd=['.venv/bin/python','benchmarks/benchmark_exl3.py','--backend','vllm','--inputs',str(root/'moe-8k-b1-b4.json.gz'),'--output',str(root/f'{name}.json'),'--pp','4','--chunk-size',str(chunk),'--max-model-len','16384','--kv-cache-gib','4','--batch-size','4','--warmups','1','--repeats','3','--tokens','32','--skip-eval','--event-profile']
 env=dict(os.environ,CUDA_DEVICE_ORDER='PCI_BUS_ID',CUDA_VISIBLE_DEVICES='0,1,2,3',NCCL_P2P_DISABLE='1',VLLM_PP_LAYER_PARTITION=partition,OMP_NUM_THREADS='1',EXL3_INT8_GEMV='0',VLLM_DETERMINISTIC_MOE_ALIGN='0',VLLM_EXL3_MOE_MAX_TOKENS=str(capacity),VLLM_EXL3_MOE_PRIORITY='1')
 source_hashes={}
 for path in sources:
  data=Path(path).read_bytes();sha=hashlib.sha256(data).hexdigest();source_hashes[path]=sha
  dest=root/'placement-sources'/f'{sha}-{Path(path).name}.gz';dest.parent.mkdir(exist_ok=True);dest.write_bytes(gzip.compress(data))
 record={'name':name,'partition':partition,'chunk':chunk,'capacity':capacity,'command':cmd,'source_sha256':source_hashes,'start':time.time()}
 print('RUN',name,flush=True)
 with (root/f'{name}.log').open('w') as f:proc=subprocess.run(cmd,env=env,stdout=f,stderr=subprocess.STDOUT)
 record.update(exit_code=proc.returncode,end=time.time());status.append(record);(root/'placement-status.json').write_text(json.dumps(status,indent=2));print('DONE',name,proc.returncode,flush=True)
 if proc.returncode:break
