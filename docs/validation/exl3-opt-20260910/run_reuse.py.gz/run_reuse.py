import gzip,hashlib,json,os,subprocess
from pathlib import Path
r=Path('/tmp/exl3-opt-20260910');status=[]
for gpu,layer in ((0,3),(3,44)):
 for reuse in (False,True):
  name=f'reuse-{int(reuse)}-gpu{gpu}'
  cmd=['.venv/bin/python','benchmarks/kernels/benchmark_exl3_moe.py','--checkpoint','/home/bul/dev/models1/zai/turboderp/GLM-5.3-Flash-exl3/4.05bpw','--prefix',f'model.language_model.layers.{layer}.mlp.experts','--route-sample',str(r/'routes'/f'layer-{layer}.pt'),'--expand-workspace','--prefill-rows','2048','--prefill-chunks','512','1024','2048','--longest-first','1','--output',str(r/f'{name}.json')]
  if reuse:cmd+=['--reuse-buffers']
  with (r/f'{name}.log').open('w') as f:proc=subprocess.run(cmd,env=dict(os.environ,CUDA_VISIBLE_DEVICES=str(gpu),CUDA_DEVICE_ORDER='PCI_BUS_ID',OMP_NUM_THREADS='1',EXL3_INT8_GEMV='0'),stdout=f,stderr=subprocess.STDOUT)
  status.append({'name':name,'exit_code':proc.returncode,'command':cmd});(r/'reuse-status.json').write_text(json.dumps(status,indent=2));print(name,proc.returncode,flush=True)
  if proc.returncode:raise SystemExit(proc.returncode)
name='reuse-model'
cmd=['.venv/bin/python','benchmarks/benchmark_exl3.py','--backend','vllm','--inputs',str(r/'moe-8k-b1-b4.json.gz'),'--output',str(r/f'{name}.json'),'--pp','4','--chunk-size','1024','--max-model-len','16384','--kv-cache-gib','4','--batch-size','4','--warmups','1','--repeats','3','--tokens','32','--skip-eval','--moe-variants',str(r/'reuse_variants.json')]
env=dict(os.environ,CUDA_DEVICE_ORDER='PCI_BUS_ID',CUDA_VISIBLE_DEVICES='0,1,2,3',NCCL_P2P_DISABLE='1',VLLM_PP_LAYER_PARTITION='10,7,7,21',OMP_NUM_THREADS='1',EXL3_INT8_GEMV='0',VLLM_DETERMINISTIC_MOE_ALIGN='0',VLLM_EXL3_MOE_MAX_TOKENS='1024',VLLM_EXL3_MOE_PRIORITY='1')
source_hashes={}
for path in ['vllm/model_executor/layers/quantization/exl3.py','vllm/envs.py','benchmarks/benchmark_exl3.py','benchmarks/exl3_profile_worker.py','benchmarks/kernels/benchmark_exl3_moe.py']:
 data=Path(path).read_bytes();sha=hashlib.sha256(data).hexdigest();source_hashes[path]=sha;dest=r/'reuse-sources'/f'{sha}-{Path(path).name}.gz';dest.parent.mkdir(exist_ok=True);dest.write_bytes(gzip.compress(data))
with (r/f'{name}.log').open('w') as f:proc=subprocess.run(cmd,env=env,stdout=f,stderr=subprocess.STDOUT)
status.append({'name':name,'exit_code':proc.returncode,'command':cmd,'source_sha256':source_hashes});(r/'reuse-status.json').write_text(json.dumps(status,indent=2));print(name,proc.returncode,flush=True)
