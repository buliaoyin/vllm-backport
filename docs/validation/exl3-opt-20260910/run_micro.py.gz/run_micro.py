import json
import os
import subprocess
from pathlib import Path
root=Path('/tmp/exl3-opt-20260910')
model='/home/bul/dev/models1/zai/turboderp/GLM-5.3-Flash-exl3/4.05bpw'
jobs=[]
for gpu,layer in [(0,3),(3,44)]:
    common=['.venv/bin/python','benchmarks/kernels/benchmark_exl3_moe.py','--checkpoint',model,'--prefix',f'model.language_model.layers.{layer}.mlp.experts','--route-sample',str(root/'routes'/f'layer-{layer}.pt'),'--expand-workspace']
    jobs.append((gpu,f'micro-groups-gpu{gpu}',common+['--prefill-rows','2048','--prefill-chunks','256','512','1024','2048','--prefill-groups','-1','4','8','16']))
    jobs.append((gpu,f'micro-split-gpu{gpu}',common+['--prefill-rows','2048','--prefill-chunks','512','1024','2048','--expert-splits','1','2','4','--split-thresholds','0','64','128','--longest-first','0']))
    jobs.append((gpu,f'micro-pack-gpu{gpu}',common+['--prefill-rows','2048','--prefill-chunks','512','1024','--packing','sort','align','--longest-first','0','1']))
status=[]
for gpu,name,cmd in jobs:
    cmd += ['--output',str(root/f'{name}.json')]
    env=dict(os.environ,CUDA_DEVICE_ORDER='PCI_BUS_ID',CUDA_VISIBLE_DEVICES=str(gpu),EXL3_INT8_GEMV='0',OMP_NUM_THREADS='1',VLLM_DETERMINISTIC_MOE_ALIGN='0')
    print('RUN',name,flush=True)
    with (root/f'{name}.log').open('w') as log:
        result=subprocess.run(cmd,env=env,stdout=log,stderr=subprocess.STDOUT)
    status.append({'name':name,'gpu':gpu,'exit_code':result.returncode,'command':cmd})
    (root/'micro-status.json').write_text(json.dumps(status,indent=2))
    print('DONE',name,result.returncode,flush=True)
    if result.returncode:
        break
