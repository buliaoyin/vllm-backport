import json
import statistics
import sys
from pathlib import Path
import torch
from flashinfer.testing import bench_gpu_time_with_cudagraph
sys.path.insert(0, '/home/bul/dev/vllm-backport/benchmarks/kernels')
import benchmark_exl3_moe as bench
from exl3_tile_launch import Launcher

ROOT = Path('/tmp/exl3-opt-20260910')

@torch.inference_mode()
def ablate(layer, method, args, k, n):
    ext = bench._extension()
    native = ext.exl3_moe
    data = torch.load(args.route_sample, weights_only=True, map_location='cuda')
    x, weights, ids = (data[name][:2048].contiguous() for name in ('x','weights','ids'))
    inputs = (x,weights,ids,method.ptrs,method.workspace,method.bits,method.flags,10.0)
    reference = bench.fused_with_chunk(inputs,128)
    configs = [(32,256,'fixed','native',8,None),(32,256,'fixed','default',8,None)]
    for tile_k in (32,16):
        if tile_k==16 and not (ROOT/'moe_k16.so').exists():continue
        for tile_n in (256,128):
            for groups in ('default','resident'):
                configs.append((tile_k,tile_n,'needed',groups,8,'moe_k16.so' if tile_k==16 else None))
            if tile_k==16:
                configs.append((tile_k,tile_n,'needed','resident',16,'moe_k16.so'))
    assert (ROOT/'moe_k16_minblocks2.so').exists()
    for tile_n in (256,128):
        for width in (8,16):
            configs.append((16,tile_n,'needed','resident',width,'moe_k16_minblocks2.so'))
    result={'gpu':torch.cuda.get_device_name(),'routing':str(args.route_sample),'rows':[], 'timer':'CUDA graph events; all wrapper GPU operations included','reference':'native K32/N256, 128-token chunks','kernel_abi':'ExLlamaV3 1.4.8 at 6ff3a17','shape':[2048,k,n],'bits':method.bits}
    for tile_k,tile_n,shared,group_mode,width,library in configs:
        if group_mode=='native':
            launcher=None
            plan={}
            groups=method.workspace[0].shape[0]
        else:
            launcher=Launcher(ext,tile_n,shared,tile_k,str(ROOT/library) if library else None,width)
            plan=launcher.plan(torch.cuda.current_device(),method.bits,method.flags)
            groups=plan['max_groups'] if group_mode=='resident' else method.workspace[0].shape[0]
        workspace=[t.new_empty((groups,1024,t.shape[2])) for t in method.workspace]
        test_inputs=(*inputs[:4],workspace,*inputs[5:])
        ext.exl3_moe=launcher or native
        try:
            def calculate(inputs):
                return bench.fused_with_chunk(inputs,1024,longest_first=True)
            actual=calculate(test_inputs)
            relative=((actual.float()-reference.float()).norm()/reference.float().norm()).item()
            assert torch.isfinite(actual).all() and relative<0.01, (tile_k,tile_n,shared,groups,relative)
            for _ in range(3):calculate(test_inputs)
            times=bench_gpu_time_with_cudagraph(calculate,input_args=(test_inputs,),cold_l2_cache=True,num_iters_within_graph=1,dry_run_iters=3,repeat_iters=15)
            item={'library':library,'tile_k':tile_k,'tile_n':tile_n,'shared':shared,'group_mode':group_mode,'groups':groups,'width':width,'relative_l2':relative,'median_ms':statistics.median(times),'min_ms':min(times),'max_ms':max(times),'plan':{key:value for key,value in plan.items() if key not in ('kernel','locks')}}
            result['rows'].append(item);print(item,flush=True);args.output.write_text(json.dumps(result,indent=2))
        finally:
            ext.exl3_moe=native

bench.prefill_ablation=ablate
if __name__=='__main__':bench.main()
