from pathlib import Path
p=Path('benchmarks/exl3_profile_worker.py')
s=p.read_text()
s += '''

    def set_exl3_workspace_capacity(self, capacity):
        """Sweep capacity without reloading weights; eager prefill uses this buffer."""
        from vllm.model_executor.layers.quantization.exl3 import Exl3MoEMethod

        torch.accelerator.synchronize()
        workspaces = {}
        methods = []
        for module in self.get_model().modules():
            method = getattr(module, "quant_method", None)
            if not isinstance(method, Exl3MoEMethod):
                continue
            old = method.workspace
            key = (old[0].device, old[0].shape[2], old[2].shape[2])
            if key not in workspaces:
                workspaces[key] = [
                    t.new_empty((t.shape[0], capacity, t.shape[2])) for t in old
                ]
            method.workspace = workspaces[key]
            methods.append(method)
        return {
            "gpu": torch.cuda.get_device_name(),
            "capacity": capacity,
            "expert_layers": len(methods),
            "workspace_bytes": sum(
                t.numel() * t.element_size()
                for workspace in workspaces.values()
                for t in workspace
            ),
        }

    def start_exl3_route_capture(self, directory):
        """Capture four real prefill chunks at representative depths, outside timing."""
        from pathlib import Path

        from vllm.model_executor.layers.quantization.exl3 import Exl3MoEMethod

        state = {"original": Exl3MoEMethod.apply, "layers": {}, "directory": directory}
        self._exl3_route_capture = state
        Path(directory).mkdir(parents=True, exist_ok=True)

        def capture(method, layer, x, topk_weights, topk_ids, *args, **kwargs):
            layer_id = int(method.prefix.split(".layers.")[1].split(".")[0])
            if layer_id in (3, 22, 44) and x.shape[0] > 8:
                samples = state["layers"].setdefault(method.prefix, [])
                if len(samples) < 4:
                    samples.append(tuple(t.detach().clone() for t in (x, topk_weights, topk_ids)))
            return state["original"](method, layer, x, topk_weights, topk_ids, *args, **kwargs)

        Exl3MoEMethod.apply = capture

    def finish_exl3_route_capture(self):
        from pathlib import Path

        from vllm.model_executor.layers.quantization.exl3 import Exl3MoEMethod

        state = self._exl3_route_capture
        Exl3MoEMethod.apply = state["original"]
        paths = []
        for prefix, samples in state["layers"].items():
            layer_id = int(prefix.split(".layers.")[1].split(".")[0])
            path = Path(state["directory"]) / f"layer-{layer_id}.pt"
            values = [torch.cat([sample[i] for sample in samples]).cpu() for i in range(3)]
            torch.save({"prefix": prefix, "x": values[0], "weights": values[1], "ids": values[2]}, path)
            paths.append(str(path))
        del self._exl3_route_capture
        return paths
'''
p.write_text(s)
p=Path('benchmarks/benchmark_exl3.py');s=p.read_text()
s=s.replace('        if args.profile_dir:\n            sys.path.insert', '        extension = args.profile_dir or args.moe_workspace_sizes or args.capture_routing_dir\n        if extension:\n            sys.path.insert',1)
s=s.replace('                if args.profile_dir\n                else ""', '                if extension\n                else ""',1)
s=s.replace('    parser.add_argument("--profile-tokens", type=int, default=1)', '    parser.add_argument("--profile-tokens", type=int, default=1)\n    parser.add_argument("--moe-workspace-sizes", type=int, nargs="+")\n    parser.add_argument("--capture-routing-dir", type=Path)')
s=s.replace('    if not args.skip_perf:\n        for case in data["cases"]:', '    for capacity in args.moe_workspace_sizes or [None]:\n        if capacity is not None:\n            result.setdefault("workspace_sweep", []).append(\n                backend.llm.collective_rpc("set_exl3_workspace_capacity", args=(capacity,))\n            )\n        for case in ([] if args.skip_perf else data["cases"]):')
s=s.replace('                    "case": case["name"],\n                    "repeat": repeat,', '                    "case": case["name"],\n                    "workspace_capacity": capacity,\n                    "repeat": repeat,')
s=s.replace('    if args.profile_dir:\n        backend.llm.start_profile()', '    if args.capture_routing_dir:\n        backend.llm.collective_rpc(\n            "start_exl3_route_capture", args=(str(args.capture_routing_dir.resolve()),)\n        )\n        backend.generate(data["cases"][0]["inputs"], 1, True)\n        result["routing_samples"] = backend.llm.collective_rpc("finish_exl3_route_capture")\n        save()\n    if args.profile_dir:\n        backend.llm.start_profile()')
p.write_text(s)
