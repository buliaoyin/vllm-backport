from exl3_profile_worker import Exl3ProfileWorkerExtension
class TileModelWorker(Exl3ProfileWorkerExtension):
 def configure_exl3_optimization(self,options):
  import torch
  from vllm.model_executor.layers.quantization.exl3 import _extension,Exl3MoEMethod
  from exl3_tile_launch import Launcher
  ext=_extension()
  if hasattr(self,'_tile_native'):
   ext.exl3_moe=self._tile_native
   for method,old in self._tile_previous:method.workspace=old
   del self._tile_native,self._tile_previous
  result=Exl3ProfileWorkerExtension.configure_exl3_optimization(self,options)
  mode=options.get('tile_mode')
  if mode:
   is_ampere=torch.cuda.get_device_capability()[0]==8
   k16=mode=='mixed' and is_ampere
   launcher=Launcher(ext,256,'needed',16 if k16 else 32,'/tmp/exl3-opt-20260910/moe_k16_minblocks2.so' if k16 else None,8)
   previous=[];workspaces={};plans=[]
   for module in self.get_model().modules():
    method=getattr(module,'quant_method',None)
    if not isinstance(method,Exl3MoEMethod):continue
    assert method.bits==[4,4,4] and method.flags==[False,True]*3,(method.prefix,method.bits,method.flags)
    plan=launcher.plan(method.ptrs[0].device.index,method.bits,method.flags)
    old=method.workspace;groups=plan['max_groups'] if k16 else old[0].shape[0]
    key=(groups,old[0].shape[1],old[0].shape[2],old[2].shape[2])
    if key not in workspaces:
     workspaces[key]=[t.new_empty((groups,*t.shape[1:])) for t in old]
     plans.append({k:v for k,v in plan.items() if k not in ('kernel','locks')})
    previous.append((method,old));method.workspace=workspaces[key]
   self._tile_native=ext.exl3_moe;self._tile_previous=previous;ext.exl3_moe=launcher
   result['tile']={'mode':mode,'k16':k16,'plans':plans,'workspace_bytes':sum(t.numel()*t.element_size() for ws in workspaces.values() for t in ws)}
  return result
