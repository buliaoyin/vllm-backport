import json
from pathlib import Path
r=Path('/tmp/exl3-opt-20260910');d=json.loads((r/'summary.json').read_text());p=Path('docs/validation/exl3-optimization-20260910.md');s=p.read_text()
def case(name,key):return next(x for x in d['models'][name]['cases'] if x['case']==key)
configs=[('10/7/7/21','EXL3','pp21-c1024'),('10/7/7/21','NVFP4','nvfp4-pp21-c1024'),('11/8/8/18','EXL3','exl3-pp18-c1024'),('11/8/8/18','AWQ','awq-pp18-c1024')]
lines=['## 与 NVFP4 / AWQ 的新对照','','均为外层 chunk=1024、max model len=16384、KV 4 GiB/GPU、max sequences=4、相同输入 token IDs；每行三次计时。按相同 PP 的两行比较。','','| PP 分层 | 格式 | 8K B1 TTFT（秒） | B1 prefill token/s | 8K B4 最大 TTFT（秒） |','| --- | --- | ---: | ---: | ---: |']
for pp,fmt,name in configs:
 a,b=case(name,'p8192_b1'),case(name,'p8192_b4');assert a['repeats']==b['repeats']==3
 lines.append(f"| {pp} | {fmt} | {a['max_ttft_median']:.4f} | {a['prefill_tps']:.1f} | {b['max_ttft_median']:.4f} |")
nv_ratio=case('pp21-c1024','p8192_b1')['max_ttft_median']/case('nvfp4-pp21-c1024','p8192_b1')['max_ttft_median']
awq_ratio=case('exl3-pp18-c1024','p8192_b1')['max_ttft_median']/case('awq-pp18-c1024','p8192_b1')['max_ttft_median']
ex_ms=sum(x['sum_ms']['exl3_moe'] for x in d['models']['pp21-c1024']['profile']);nv_ms=sum(x['sum_ms']['marlin_gemm'] for x in d['models']['nvfp4-pp21-c1024']['profile'])
lines.extend(['',f'调优后的同 PP 比较中，EXL3 的 8K B1 TTFT 仍为 NVFP4 的 {nv_ratio:.2f} 倍、AWQ 的 {awq_ratio:.2f} 倍。此前 NVFP4/AWQ 的 1.94/1.82 秒使用不同的 PP/chunk 组合，不能直接与调优后的 EXL3 当作同配置比较。','',f'在 10/7/7/21、1024 chunk 的独立事件采样中，EXL3 专家 kernel 的四卡区间和为 {ex_ms/1000:.4f} GPU 秒，NVFP4 的 Marlin GEMM 为 {nv_ms/1000:.4f} GPU 秒，约 {ex_ms/nv_ms:.2f} 倍。它们是各 rank 计算区间的和，不能当作请求墙钟。优化后的剩余瓶颈仍主要在专家计算。','', 'AWQ 将 21 层放到 Blackwell 时，在模型构造阶段已用约 94.65 GiB，再申请 4.50 GiB 失败，未进入性能计时。采用 18 层后完成测试，EXL3 同配置补测。AWQ 的最后一层 routed experts 未量化，显存分配不能直接照搬 EXL3。该失败已归档，不将启动失败记录为低吞吐。','', '两种对照的量化专家都选择 Marlin W4A16；这不是原生 W4A4 FP4 性能对比。三个 checkpoint 的量化覆盖与重建后的权重不同，AWQ 还有一个未量化专家层，注意力/shared 的权重表示也不同。剩余差距包含 trellis 解码、Hadamard、M=16 GEMM 与组同步等实现成本；未做 kernel 内部拆时，不能给这些因素分别编造耗时百分比。量化覆盖详情见[此前定位报告](exl3-prefill-analysis-20260910.md)。',''])
section='\n'.join(lines)+'\n'
marker='## 与 NVFP4 / AWQ 的新对照'
if marker in s:s=s[:s.index(marker)]+s[s.index('## 正确性与精度'):]
s=s.replace('## 正确性与精度\n',section+'## 正确性与精度\n')
checkline=f"本轮累计 {d['micro_total_cases']} 个微基准配置通过数值比较；{d['checks']['retrieval_passed']}/{d['checks']['retrieval']} 次计时请求的检索检查通过，输出长度与零缓存命中检查通过。计数包含不同配置及重复测量，不是同等数量的独立任务。相关文件 pre-commit 与 Python 3.12 mypy 通过。\n\n"
s=s.replace('`tests/quantization/test_exl3.py` 在 GPU0',checkline+'`tests/quantization/test_exl3.py` 在 GPU0')
p.write_text(s)
print('Written matched comparator table and final validation totals')
