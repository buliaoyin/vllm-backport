import gzip,hashlib,json,os,subprocess,time
from pathlib import Path
r=Path('/tmp/exl3-opt-20260910');status=[]
for fmt in ('awq','exl3'):
 name=fmt+'-pp18-c1024'
 cmd=['.venv/bin/python','benchmarks/benchmark_exl3.py','--backend','vllm','--inputs',str(r/f'{fmt}-8k-inputs.json.gz'),'--output',str(r/f'{name}.json'),'--pp','4','--chunk-size','1024','--max-model-len','16384','--kv-cache-gib','4','--batch-size','4','--warmups','1','--repeats','3','--tokens','32','--skip-eval','--event-profile']
 env=dict(os.environ,CUDA_DEVICE_ORDER='PCI_BUS_ID',CUDA_VISIBLE_DEVICES='0,1,2,3',NCCL_P2P_DISABLE='1',VLLM_PP_LAYER_PARTITION='11,8,8,18',OMP_NUM_THREADS='1',EXL3_INT8_GEMV='0',VLLM_DETERMINISTIC_MOE_ALIGN='0',VLLM_EXL3_MOE_MAX_TOKENS='1024',VLLM_EXL3_MOE_PRIORITY='1')
 print('RUN',name,flush=True);start=time.time()
 with (r/f'{name}.log').open('w') as f:proc=subprocess.run(cmd,env=env,stdout=f,stderr=subprocess.STDOUT)
 status.append({'name':name,'exit_code':proc.returncode,'command':cmd,'environment':{k:env[k] for k in env if k.startswith(('VLLM_','CUDA_','EXL3_','NCCL_','OMP_'))},'start':start,'end':time.time()});(r/'comparator-pp18-status.json').write_text(json.dumps(status,indent=2));print('DONE',name,proc.returncode,flush=True)
 if proc.returncode:break
