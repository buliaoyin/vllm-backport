import json
from pathlib import Path
r=Path('/tmp/exl3-opt-20260910');p=Path('docs/validation/exl3-optimization-20260910.md');s=p.read_text()
section='''## 共享内存、tile 和寄存器实验

进一步编译/测试 K tile=16/32、N tile=128/256、实际共享内存容量、group width=8/16，以及至少两个 block/SM 的 launch bounds，共 32 个微基准配置。

原版固定申请 90 KiB 动态共享内存。按 `exl3_gemm_inner.cuh` 的 A/B 三阶段缓冲与 C 布局，4-bit K32/N256 实际需要 31 KiB，K32/N128 为 17 KiB；K16/N256 和 K16/N128 分别为 23.5 和 12.5 KiB。但原 K32 kernel 为 512 线程、每线程 128 寄存器，CUDA occupancy API 仍报告只能驻留一个 block/SM，单独减共享内存不能解决寄存器限制。

K16 使用 256 线程；通过 `__launch_bounds__(256, 2)` 将寄存器限制在 128，实测可驻留两个 block/SM。候选启动的 grid 严格不超过 occupancy API 报告的容量，并遵守最多 64 个专家组，避免组间 barrier 死锁。实际 SM 数为 CMP 70、Blackwell 188，不能把原版的 64/184 个启动 block 误认为物理 SM 数。

- CMP：原 kernel 43.78 ms；K32/N128 约 64.00 ms；普通 K16/N256 约 57.61 ms；限制寄存器并使用 17 组的 K16/N256 为 42.01 ms，约快 4%。
- Blackwell：原 kernel 14.02 ms；只降到 31 KiB 为 13.61 ms；双驻留 K16/N256、47 组为 17.33 ms，加宽到 16 block/组为 14.56 ms。
- 新 tile 的最大 relative L2 约 0.00119，所有候选均通过阈值 0.01。完整寄存器、spill 与 occupancy 记录已保存。

整模型再次按“原版、31 KiB、CMP K16 + Blackwell 31 KiB、恢复原版”运行；所有配置使用保留的 1024 容量和优先级、PP=10/7/7/21：

| 专家 kernel | 8K B1 TTFT（秒） | 8K B4 最大 TTFT（秒） |
| --- | ---: | ---: |
| 原版，前测 | 2.5865 | 8.6725 |
| 31 KiB | 2.6025 | 8.7202 |
| CMP K16，Blackwell 31 KiB | 2.5919 | 8.6121 |
| 原版，后测 | 2.6974 | 8.9822 |

kernel 小收益没有形成稳定的整模型优势，基线前后有约 4% 波动。它们保留为实验，不进入生产路径。实验 launcher 依赖 ExLlamaV3 1.4.8 的私有 C++ 符号，显式检查版本；K16 模板在 `/tmp` 独立编译、使用独立符号名，未覆盖原版扩展。这也是不把实验 launcher 作为公共依赖的原因。

'''
if '## 共享内存、tile 和寄存器实验' not in s:s=s.replace('## 正确性与精度\n',section+'## 正确性与精度\n')
p.write_text(s)
