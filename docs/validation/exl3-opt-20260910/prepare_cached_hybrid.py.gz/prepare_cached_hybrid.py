from pathlib import Path
r=Path('/tmp/exl3-opt-20260910');s=Path('benchmarks/kernels/benchmark_exl3_moe.py').read_text()
cold=s[s.index('def fused_with_chunk('):s.index('def fused_with_reused_buffers(')].rstrip()
cold=cold.replace('def fused_with_chunk(', 'def cold_fused(').replace('                ids = inverse[ids]', '                inverse = torch.cat((inverse, inverse.new_full((1,), inverse.numel())))\n                ids = inverse[ids]')
kernel=s[s.index('@triton.jit\ndef _hot_grouped_gemm'):s.index('def hybrid_with_chunk(')].rstrip()
kernel=kernel.replace('_hot_grouped_gemm','_cached_grouped_gemm').replace('    Experts,','    Experts,\n    MatrixIndices,').replace('    count = tl.load(Counts + expert)','    count = tl.load(Counts + expert)\n    matrix_index = tl.load(MatrixIndices + group)').replace('B + group * K * N','B + matrix_index * K * N')
hybrid=s[s.index('def hybrid_with_chunk('):s.index('def hybrid_ablation(')].rstrip()
hybrid=hybrid.replace('def hybrid_with_chunk(inputs, chunk_size, hot_count, projections, grouped=False):', 'def hybrid_cached(inputs, chunk_size, hot_count, caches, mapping):\n    grouped = True').replace('result = fused_with_chunk(cold_inputs, chunk_size)', 'result = cold_fused(cold_inputs, chunk_size, longest_first=True)')
a=hybrid.index('            packed, suh, svh =');b=hybrid.index('            rotated =',a)
hybrid=hybrid[:a]+'''            matrix, all_suh, all_svh = caches[index]
            matrix_indices = mapping[hot]
            suh, svh = all_suh[matrix_indices], all_svh[matrix_indices]
            k, n = suh.shape[1], svh.shape[1]
'''+hybrid[b:]
hybrid=hybrid.replace('_hot_grouped_gemm[','_cached_grouped_gemm[').replace('                    hot,\n                    hidden.shape[0],','                    hot,\n                    matrix_indices,\n                    hidden.shape[0],')
header='''import torch
import triton
import triton.language as tl
from benchmark_exl3_moe import _extension, triton_routes
'''
(r/'cached_hybrid.py').write_text(header+'\n'+cold+'\n\n'+kernel+'\n\n'+hybrid+'\n')
