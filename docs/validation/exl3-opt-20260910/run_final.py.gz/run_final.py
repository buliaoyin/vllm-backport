import gzip,hashlib,json,os,subprocess,time
from pathlib import Path
r=Path('/tmp/exl3-opt-20260910');status=[]
for name,inputs,chunk in [('long-final','moe-long-eval64.json.gz',1024),('long-c2048','moe-64k-only.json.gz',2048)]:
 cmd=['.venv/bin/python','benchmarks/benchmark_exl3.py','--backend','vllm','--inputs',str(r/inputs),'--output',str(r/f'{name}.json'),'--pp','4','--chunk-size',str(chunk),'--max-model-len','66560','--kv-cache-gib','8','--batch-size','4','--warmups','1','--repeats','3','--tokens','32','--eval-tokens','768','--event-profile']
 env=dict(os.environ,CUDA_DEVICE_ORDER='PCI_BUS_ID',CUDA_VISIBLE_DEVICES='0,1,2,3',NCCL_P2P_DISABLE='1',VLLM_PP_LAYER_PARTITION='10,7,7,21',OMP_NUM_THREADS='1',EXL3_INT8_GEMV='0',VLLM_DETERMINISTIC_MOE_ALIGN='0',VLLM_EXL3_MOE_MAX_TOKENS=str(chunk),VLLM_EXL3_MOE_PRIORITY='1')
 source_hashes={}
 for path in ['vllm/model_executor/layers/quantization/exl3.py','vllm/envs.py','benchmarks/benchmark_exl3.py','benchmarks/exl3_profile_worker.py','benchmarks/kernels/benchmark_exl3_moe.py','tests/quantization/test_exl3.py']:
  data=Path(path).read_bytes();sha=hashlib.sha256(data).hexdigest();source_hashes[path]=sha;dest=r/'final-sources'/f'{sha}-{Path(path).name}.gz';dest.parent.mkdir(exist_ok=True);dest.write_bytes(gzip.compress(data))
 print('RUN',name,flush=True);start=time.time()
 with (r/f'{name}.log').open('w') as f:proc=subprocess.run(cmd,env=env,stdout=f,stderr=subprocess.STDOUT)
 status.append({'name':name,'exit_code':proc.returncode,'command':cmd,'source_sha256':source_hashes,'start':start,'end':time.time()});(r/'final-status.json').write_text(json.dumps(status,indent=2));print('DONE',name,proc.returncode,flush=True)
 if proc.returncode:break
