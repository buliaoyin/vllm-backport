import os,json,subprocess
from pathlib import Path
r=Path('/tmp/exl3-opt-20260910');status=[]
for gpu,layer in ((0,3),(3,44)):
 name=f'tile-gpu{gpu}'
 cmd=['.venv/bin/python',str(r/'tile_benchmark.py'),'--checkpoint','/home/bul/dev/models1/zai/turboderp/GLM-5.3-Flash-exl3/4.05bpw','--prefix',f'model.language_model.layers.{layer}.mlp.experts','--route-sample',str(r/'routes'/f'layer-{layer}.pt'),'--prefill-rows','2048','--output',str(r/f'{name}.json')]
 with (r/f'{name}.log').open('w') as f:proc=subprocess.run(cmd,env=dict(os.environ,CUDA_VISIBLE_DEVICES=str(gpu),CUDA_DEVICE_ORDER='PCI_BUS_ID',OMP_NUM_THREADS='1',EXL3_INT8_GEMV='0'),stdout=f,stderr=subprocess.STDOUT)
 status.append({'name':name,'exit_code':proc.returncode,'command':cmd});(r/'tile-status.json').write_text(json.dumps(status,indent=2));print(name,proc.returncode,flush=True)
 if proc.returncode:break
