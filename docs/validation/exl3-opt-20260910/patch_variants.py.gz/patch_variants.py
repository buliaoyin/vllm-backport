from pathlib import Path
p=Path('benchmarks/exl3_profile_worker.py');s=p.read_text()
s += '''

    def configure_exl3_optimization(self, options):
        """Experimental switches; the final production path is validated separately."""
        from kernels.benchmark_exl3_moe import fused_with_chunk

        from vllm.model_executor.layers.quantization import exl3

        result = self.set_exl3_workspace_capacity(options["capacity"])
        if not hasattr(self, "_exl3_original_fused"):
            self._exl3_original_fused = exl3._exl3_moe_fused
        if any(key in options for key in ("groups", "splits", "packing", "longest_first")):
            splits = options.get("splits", 1)
            is_blackwell = torch.cuda.get_device_capability()[0] >= 10
            if options.get("blackwell_only") and not is_blackwell:
                splits = 1
            pointers = {}
            for module in self.get_model().modules():
                method = getattr(module, "quant_method", None)
                if isinstance(method, exl3.Exl3MoEMethod):
                    pointers[method.ptrs[0].data_ptr()] = [p.repeat_interleave(splits) for p in method.ptrs] if splits > 1 else method.ptrs

            def candidate(x, weights, ids, ptrs, workspace, bits, flags, limit):
                inputs = (x, weights, ids, pointers[ptrs[0].data_ptr()], workspace, bits, flags, limit)
                return fused_with_chunk(inputs, workspace[0].shape[1], options.get("groups", -1), splits, options.get("split_threshold", 0), options.get("packing", "sort"), options.get("longest_first", False))

            exl3._exl3_moe_fused = candidate
        else:
            exl3._exl3_moe_fused = self._exl3_original_fused
        result["options"] = options
        return result
'''
p.write_text(s)
p=Path('benchmarks/benchmark_exl3.py');s=p.read_text()
s=s.replace('args.profile_dir or args.moe_workspace_sizes or args.capture_routing_dir','args.profile_dir or args.moe_workspace_sizes or args.moe_variants or args.capture_routing_dir')
s=s.replace('    parser.add_argument("--moe-workspace-sizes", type=int, nargs="+")','    parser.add_argument("--moe-workspace-sizes", type=int, nargs="+")\n    parser.add_argument("--moe-variants", type=Path)')
s=s.replace('    for capacity in args.moe_workspace_sizes or [None]:\n        if capacity is not None:\n            result.setdefault("workspace_sweep", []).append(\n                backend.llm.collective_rpc("set_exl3_workspace_capacity", args=(capacity,))\n            )', '''    variants = json.loads(args.moe_variants.read_text()) if args.moe_variants else [{"capacity": capacity} for capacity in args.moe_workspace_sizes or [None]]
    for variant in variants:
        capacity = variant["capacity"]
        if capacity is not None:
            result.setdefault("workspace_sweep", []).append(
                backend.llm.collective_rpc("configure_exl3_optimization", args=(variant,))
            )''')
s=s.replace('                    "workspace_capacity": capacity,','                    "workspace_capacity": capacity,\n                    "variant": variant,')
p.write_text(s)
