from pathlib import Path
p=Path('benchmarks/exl3_profile_worker.py');s=p.read_text()
s=s.replace('        result["options"] = options\n        return result','        result["linear"] = self.set_exl3_linear_experiment(options.get("linear_mode", "none"), options.get("shared_overlap", False))\n        result["options"] = options\n        return result')
s += '''

    def set_exl3_linear_experiment(self, mode, overlap):
        from vllm.model_executor.layers.fused_moe.runner.shared_experts import SharedExperts, SharedExpertsOrder
        from vllm.model_executor.layers.quantization import exl3
        from vllm.utils.torch_utils import aux_stream

        if not hasattr(self, "_exl3_original_linear_apply"):
            self._exl3_original_linear_apply = exl3.Exl3LinearMethod.apply
            self._exl3_original_shared_order = SharedExperts._determine_shared_experts_order
            self._exl3_linear_caches = {}
        original = self._exl3_original_linear_apply
        ext = exl3._extension()
        caches = self._exl3_linear_caches
        if mode in ("rotated", "original") and mode not in caches:
            cache = {}
            for module in self.get_model().modules():
                method = getattr(module, "quant_method", None)
                if not isinstance(method, exl3.Exl3LinearMethod):
                    continue
                if any(part.name.endswith("lm_head") for part in method.parts):
                    continue
                values = []
                for part, weights in zip(method.parts, method.weights):
                    if not part.quantized:
                        values.append(None)
                        continue
                    value = torch.empty(part.dimensions, device=weights["trellis"].device, dtype=torch.float16)
                    bits = weights["trellis"].shape[-1] // 16
                    flags = ("mcg" in weights, "mul1" in weights)
                    if mode == "rotated":
                        ext.reconstruct_slice(value, weights["trellis"], bits, *flags, 0)
                    else:
                        ext.reconstruct_had_slice(value, weights["trellis"], weights["suh"], weights["svh"], bits, *flags, 0)
                    values.append(value)
                cache[id(method)] = values
            caches[mode] = cache

        def calculate(method, layer, x, bias=None):
            rows = x.numel() // x.shape[-1]
            if rows <= 144 or mode == "none" or any(part.name.endswith("lm_head") for part in method.parts):
                return original(method, layer, x, bias)
            outputs = []
            inp = x.reshape(-1, x.shape[-1]).half().contiguous()
            for index, (part, weights) in enumerate(zip(method.parts, method.weights)):
                if not part.quantized:
                    y = torch.nn.functional.linear(x, weights["weight"].to(x.dtype))
                else:
                    k, n = part.dimensions
                    if mode == "fused":
                        weight = torch.empty((k, n), device=x.device, dtype=torch.float16)
                        ext.reconstruct_had_slice(weight, weights["trellis"], weights["suh"], weights["svh"], weights["trellis"].shape[-1] // 16, "mcg" in weights, "mul1" in weights, 0)
                    else:
                        weight = caches[mode][id(method)][index]
                    if mode == "rotated":
                        rotated = torch.empty_like(inp)
                        ext.had_r_128(inp, rotated, weights["suh"], None, 1.0)
                        y = torch.mm(rotated, weight)
                        ext.had_r_128(y, y, None, weights["svh"], 1.0)
                    else:
                        y = torch.mm(inp, weight)
                    y = y.view(*x.shape[:-1], n).to(x.dtype)
                outputs.append(y)
            result = torch.cat(outputs, dim=-1) if len(outputs) > 1 else outputs[0]
            return result if bias is None else result + bias

        exl3.Exl3LinearMethod.apply = calculate if mode != "none" else original
        original_order = self._exl3_original_shared_order
        if overlap:
            assert mode in ("original", "rotated")
            for module in self.get_model().modules():
                if isinstance(module, SharedExperts):
                    module._stream = aux_stream()

            def prefill_order(shared, hidden):
                if hidden.shape[0] > 144:
                    return SharedExpertsOrder.MULTI_STREAM_OVERLAPPED
                return original_order(shared, hidden)

            SharedExperts._determine_shared_experts_order = prefill_order
        else:
            SharedExperts._determine_shared_experts_order = original_order
        torch.accelerator.synchronize()
        return {"mode": mode, "overlap": overlap, "cache_bytes": sum(t.numel()*t.element_size() for values in caches.get(mode, {}).values() for t in values if t is not None)}
'''
p.write_text(s)
