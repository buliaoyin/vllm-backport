from pathlib import Path
p=Path('vllm/envs.py');s=p.read_text().replace('    VLLM_EXL3_MOE_MAX_TOKENS: int = 512','    VLLM_EXL3_MOE_MAX_TOKENS: int = 1024\n    VLLM_EXL3_MOE_PRIORITY: bool = True')
s=s.replace('    # Whether to use atomicAdd reduce in gptq/awq marlin kernel.\n    # Maximum EXL3', '    # Maximum EXL3')
s=s.replace('os.getenv("VLLM_EXL3_MOE_MAX_TOKENS", "512")','os.getenv("VLLM_EXL3_MOE_MAX_TOKENS", "1024")')
s=s.replace('    "VLLM_MARLIN_USE_ATOMIC_ADD": lambda: (', '    # Schedule larger EXL3 experts first to reduce the final wave of work.\n    "VLLM_EXL3_MOE_PRIORITY": lambda: (\n        os.getenv("VLLM_EXL3_MOE_PRIORITY", "1") == "1"\n    ),\n    # Whether to use atomicAdd reduce in gptq/awq marlin kernel.\n    "VLLM_MARLIN_USE_ATOMIC_ADD": lambda: (',1)
p.write_text(s)
p=Path('vllm/model_executor/layers/quantization/exl3.py');s=p.read_text().replace('from vllm import envs\n','from vllm import envs\nfrom vllm.config import get_current_vllm_config_or_none\n')
s=s.replace('        key = (device, self.hidden_size, self.intermediate_size, capacity)', '        vllm_config = get_current_vllm_config_or_none()\n        if vllm_config is not None:\n            capacity = min(\n                capacity, vllm_config.scheduler_config.max_num_batched_tokens\n            )\n        key = (device, self.hidden_size, self.intermediate_size, capacity)')
s=s.replace('        order = torch.argsort(ids, stable=True)\n        counts = torch.zeros(experts + 1, dtype=torch.int64, device=x.device)\n        counts.scatter_add_(0, ids, torch.ones_like(ids))\n        tokens =', '''        counts = torch.zeros(experts + 1, dtype=torch.int64, device=x.device)
        counts.scatter_add_(0, ids, torch.ones_like(ids))
        chunk_ptrs = ptrs
        if envs.VLLM_EXL3_MOE_PRIORITY and hidden.shape[0] >= 256:
            permutation = torch.argsort(counts[:-1], descending=True, stable=True)
            inverse = torch.empty_like(permutation)
            inverse.scatter_(
                0, permutation, torch.arange(experts, device=x.device)
            )
            ids = inverse[ids]
            counts = torch.cat((counts[:-1][permutation], counts[-1:]))
            chunk_ptrs = [ptr[permutation] for ptr in ptrs]
        order = torch.argsort(ids, stable=True)
        tokens =''')
# Match the unique fused extension call, leaving decode pointers intact.
s=s.replace('            *ptrs,\n            *flags,\n            limit,\n            -1,', '            *chunk_ptrs,\n            *flags,\n            limit,\n            -1,')
p.write_text(s)
p=Path('tests/quantization/test_exl3.py');s=p.read_text()
s=s.replace('torch.zeros(rows, device="cuda", dtype=torch.long),\n            torch.arange(rows, device="cuda") % 2 + 1,','torch.full((rows,), 2, device="cuda", dtype=torch.long),\n            torch.arange(rows, device="cuda") % 2,')
s=s.replace('ids[:, 1].copy_(3 - ids[:, 1])','ids[:, 1].copy_(1 - ids[:, 1])')
p.write_text(s)
