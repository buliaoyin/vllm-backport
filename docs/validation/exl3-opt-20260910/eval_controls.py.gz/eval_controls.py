import argparse,gzip,hashlib,json,os,sys
from pathlib import Path
from types import SimpleNamespace
sys.path.insert(0, '/home/bul/dev/vllm-backport/benchmarks')
from benchmark_exl3 import VllmBackend,answer_value
r=Path('/tmp/exl3-opt-20260910')
def main():
    p=argparse.ArgumentParser();p.add_argument('--output',type=Path,required=True);cli=p.parse_args()
    data=json.loads(gzip.decompress((r/'moe-long-eval64.json.gz').read_bytes()))
    batch=data['evals'][12:16]
    args=SimpleNamespace(profile_dir=None,event_profile=True,moe_workspace_sizes=None,moe_variants=None,capture_routing_dir=None,max_model_len=66560,batch_size=4,pp=4,chunk_size=1024,eager=False,kv_cache_gib=8)
    result={'placement':os.environ['VLLM_PP_LAYER_PARTITION'],'args':vars(args),'input_sha256':hashlib.sha256((r/'moe-long-eval64.json.gz').read_bytes()).hexdigest(),'batch_ids':[x['id'] for x in batch],'variants':[]}
    backend=VllmBackend(args,data)
    variants=[{'capacity':1024,'priority':True},{'capacity':1024,'priority':False},{'capacity':128,'priority':False},{'capacity':128,'priority':True}]
    for repeat in range(2):
     for variant in variants:
      state=backend.llm.collective_rpc('configure_exl3_optimization',args=(variant,))
      elapsed,rows=backend.generate([x['input_ids'] for x in batch],768,False)
      for request,row in zip(batch,rows):
       predicted=answer_value(row['text']);row.update(id=request['id'],predicted=predicted,expected=request['answer'],correct=predicted is not None and float(predicted)==float(request['answer']))
      record={'repeat':repeat,'variant':variant,'runtime':state,'seconds':elapsed,'eval':rows};result['variants'].append(record)
      cli.output.write_text(json.dumps(result,indent=2));print('EVAL',repeat,variant,[(x['id'],x['predicted'],x['correct']) for x in rows],flush=True)

if __name__ == '__main__':
    main()
