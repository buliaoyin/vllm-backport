from pathlib import Path
p=Path('benchmarks/kernels/benchmark_exl3_moe.py');s=p.read_text()
pos=s.index('\n\ndef prefill_ablation')
s=s[:pos]+'''

def hybrid_with_chunk(inputs, chunk_size, hot_count, projections):
    """Reconstruct a fixed number of GPU-selected hot experts, with no CPU readback."""
    x, weights, ids, ptrs, workspace, bits, flags, limit = inputs
    ext = _extension()
    output = torch.empty_like(x)
    experts = ptrs[0].numel()
    for start in range(0, x.shape[0], chunk_size):
        hidden = x[start : start + chunk_size]
        chunk_ids = ids[start : start + chunk_size].long()
        chunk_weights = weights[start : start + chunk_size]
        counts = torch.zeros(experts + 1, dtype=torch.int64, device=x.device)
        counts.scatter_add_(0, chunk_ids.flatten(), torch.ones_like(chunk_ids.flatten()))
        hot = counts[:-1].topk(hot_count).indices
        selected = torch.zeros(experts + 1, dtype=torch.bool, device=x.device)
        selected[hot] = True
        cold_ids = torch.where(selected[chunk_ids], experts, chunk_ids)
        cold_inputs = (hidden.float(), chunk_weights, cold_ids, ptrs, workspace, bits, flags, limit)
        result = fused_with_chunk(cold_inputs, chunk_size)
        order = torch.argsort(chunk_ids.flatten(), stable=True)
        offsets = counts.cumsum(0) - counts
        positions = offsets[hot, None] + torch.arange(hidden.shape[0], device=x.device)[None, :]
        valid = torch.arange(hidden.shape[0], device=x.device)[None, :] < counts[hot, None]
        assignment = order[positions.clamp(max=order.numel()-1)]
        tokens = assignment // chunk_ids.shape[1]
        routing = chunk_weights.flatten()[assignment].half() * valid
        gathered = hidden[tokens].half()

        def project(value, index):
            packed, suh, svh = (t[hot].contiguous() for t in projections[index])
            k, n = suh.shape[1], svh.shape[1]
            matrix = torch.empty((hot_count, k, n), dtype=torch.float16, device=x.device)
            for i in range(hot_count):
                ext.reconstruct_slice(matrix[i], packed[i], bits[index], *flags[index*2:index*2+2], 0)
            rotated = torch.empty_like(value)
            ext.had_r_128((value * suh[:, None, :]).reshape(-1, k), rotated.view(-1, k), None, None, 1.0)
            projected = torch.bmm(rotated, matrix)
            ext.had_r_128(projected.view(-1, n), projected.view(-1, n), None, None, 1.0)
            return projected * svh[:, None, :]

        gate = project(gathered, 0)
        up = project(gathered, 1)
        if limit:
            gate = gate.clamp(max=limit)
            up = up.clamp(-limit, limit)
        activated = (torch.nn.functional.silu(gate.float()) * up).half()
        down = project(activated, 2)
        result.index_add_(0, tokens.flatten(), (down.float() * routing[:, :, None]).reshape(-1, x.shape[1]))
        output[start : start + hidden.shape[0]].copy_(result)
    return output


def hybrid_ablation(layer, method, args, k, n):
    projections = []
    for kind in ("w1", "w3", "w2"):
        part = []
        for component in ("trellis", "suh", "svh"):
            name, offset, size, shape = method.views[kind, component]
            part.append(getattr(layer, name).data.narrow(0, offset, size * args.experts).view(args.experts, *shape))
        projections.append(part)
    sample = torch.load(args.route_sample, weights_only=True, map_location="cuda")
    result = {"gpu": torch.cuda.get_device_name(), "routing": str(args.route_sample), "timer": "CUDA graph events", "hot_selection": "GPU top-k per chunk, no host sync", "rows": []}
    for rows in args.prefill_rows:
        x, weights, ids = (sample[name][:rows].contiguous() for name in ("x", "weights", "ids"))
        base_inputs = (x, weights, ids, method.ptrs, method.workspace, method.bits, method.flags, 10.0)
        reference = fused_with_chunk(base_inputs, 128)
        for chunk, hot_count in itertools.product(args.prefill_chunks, args.hybrid_experts):
            workspace = [t.new_empty((t.shape[0], chunk, t.shape[2])) for t in method.workspace]
            inputs = (*base_inputs[:4], workspace, *base_inputs[5:])
            def calculate(inputs, chunk=chunk, hot_count=hot_count):
                return hybrid_with_chunk(inputs, chunk, hot_count, projections) if hot_count else fused_with_chunk(inputs, chunk)
            actual = calculate(inputs)
            relative = ((actual.float()-reference.float()).norm()/reference.float().norm()).item()
            assert relative < 0.01, (rows, chunk, hot_count, relative)
            for _ in range(3):
                calculate(inputs)
            times = bench_gpu_time_with_cudagraph(calculate, input_args=(inputs,), cold_l2_cache=True, num_iters_within_graph=1, dry_run_iters=3, repeat_iters=15)
            record = {"tokens": rows, "chunk": chunk, "hot_experts": hot_count, "relative_l2": relative, "median_ms": statistics.median(times)}
            result["rows"].append(record)
            print(record, flush=True)
            args.output.write_text(json.dumps(result, indent=2))
''' + s[pos:]
s=s.replace('    parser.add_argument("--route-sample", type=Path)', '    parser.add_argument("--route-sample", type=Path)\n    parser.add_argument("--hybrid-experts", type=int, nargs="+")')
s=s.replace('    if args.prefill_rows:\n        prefill_ablation(', '    if args.hybrid_experts:\n        hybrid_ablation(layer, method, args, k, n)\n        return\n    if args.prefill_rows:\n        prefill_ablation(')
p.write_text(s)
