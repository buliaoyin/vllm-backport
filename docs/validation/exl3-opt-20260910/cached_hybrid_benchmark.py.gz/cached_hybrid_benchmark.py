import json,statistics,sys
from pathlib import Path
import torch
from flashinfer.testing import bench_gpu_time_with_cudagraph
sys.path.insert(0,'/home/bul/dev/vllm-backport/benchmarks/kernels')
import benchmark_exl3_moe as bench
from cached_hybrid import hybrid_cached
@torch.inference_mode()
def ablate(layer,method,args,k,n):
 data=torch.load(args.route_sample,weights_only=True,map_location='cuda');x,weights,ids=(data[name][:2048].contiguous() for name in ('x','weights','ids'))
 workspace=[t.new_empty((t.shape[0],1024,t.shape[2])) for t in method.workspace]
 inputs=(x,weights,ids,method.ptrs,workspace,method.bits,method.flags,10.0)
 reference=bench.fused_with_chunk(inputs,128);ext=bench._extension();projections=[]
 for kind in ('w1','w3','w2'):
  part=[]
  for component in ('trellis','suh','svh'):
   name,offset,size,shape=method.views[kind,component];part.append(getattr(layer,name).data.narrow(0,offset,size*args.experts).view(args.experts,*shape))
  projections.append(part)
 result={'gpu':torch.cuda.get_device_name(),'routing':str(args.route_sample),'scope':'full GPU wrapper; CUDA graph events','selection':'Optimistic cache: union of top H experts from both measured chunks is decoded before timing; calibration uses measured input','rows':[]}
 for h in (0,2,4,8):
  caches=[];cache_bytes=0;hot_ids=[];mapping=None
  if h:
   hist=[torch.bincount(v.flatten(),minlength=args.experts) for v in ids.split(1024)]
   hot=torch.cat([v.topk(h).indices for v in hist]).unique();hot_ids=hot.tolist();mapping=torch.full((args.experts,),-1,device=x.device,dtype=torch.int64);mapping[hot]=torch.arange(hot.numel(),device=x.device)
   for index,(packed,suh,svh) in enumerate(projections):
    matrices=torch.empty((hot.numel(),suh.shape[1],svh.shape[1]),device=x.device,dtype=torch.float16)
    for i,e in enumerate(hot_ids):ext.reconstruct_slice(matrices[i],packed[e],method.bits[index],*method.flags[index*2:index*2+2],0)
    cache=(matrices,suh[hot].contiguous(),svh[hot].contiguous());caches.append(cache);cache_bytes+=sum(t.numel()*t.element_size() for t in cache)
  def calculate(inputs):
   return hybrid_cached(inputs,1024,h,caches,mapping) if h else bench.fused_with_chunk(inputs,1024,longest_first=True)
  actual=calculate(inputs);relative=((actual.float()-reference.float()).norm()/reference.float().norm()).item();assert torch.isfinite(actual).all() and relative<0.01,(h,relative)
  for _ in range(3):calculate(inputs)
  times=bench_gpu_time_with_cudagraph(calculate,input_args=(inputs,),cold_l2_cache=True,num_iters_within_graph=1,dry_run_iters=3,repeat_iters=15)
  item={'hot_experts':h,'cached_experts':hot_ids,'cache_bytes':cache_bytes,'relative_l2':relative,'median_ms':statistics.median(times),'min_ms':min(times),'max_ms':max(times)};result['rows'].append(item);args.output.write_text(json.dumps(result,indent=2));print(item,flush=True)
bench.prefill_ablation=ablate
if __name__=='__main__':bench.main()
