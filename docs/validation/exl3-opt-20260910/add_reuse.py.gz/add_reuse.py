from pathlib import Path
p=Path('benchmarks/kernels/benchmark_exl3_moe.py');s=p.read_text().replace('from pathlib import Path\n', 'from functools import partial\nfrom pathlib import Path\n')
pos=s.index('\n\n@triton.jit\ndef _hot_grouped_gemm')
s=s[:pos]+'''

def fused_with_reused_buffers(inputs, chunk_size, groups=-1, splits=1, split_threshold=0, packing="sort", longest_first=True, *, pool):
    """Reuse bounded internal buffers; every returned output still owns its storage."""
    assert splits == 1 and not split_threshold and packing == "sort"
    x, topk_weights, topk_ids, ptrs, workspace, bits, flags, limit = inputs
    ext = _extension()
    experts, topk = ptrs[0].numel(), topk_ids.shape[1]
    key = (x.device, chunk_size, x.shape[1], experts, topk)
    if key not in pool:
        def empty(shape, dtype):
            return torch.empty(shape, dtype=dtype, device=x.device)
        pool[key] = {
            "hidden": empty((chunk_size, x.shape[1]), torch.float16),
            "result": empty((chunk_size, x.shape[1]), torch.float32),
            "ids": empty(chunk_size * topk, torch.int64),
            "mapped_ids": empty(chunk_size * topk, torch.int64),
            "weights": empty(chunk_size * topk, torch.float16),
            "sorted_weights": empty(chunk_size * topk, torch.float16),
            "counts": empty(experts + 1, torch.int64),
            "sorted_counts": empty(experts + 1, torch.int64),
            "permutation": empty(experts, torch.int64),
            "inverse": empty(experts, torch.int64),
            "sorted_ids": empty(chunk_size * topk, torch.int64),
            "order": empty(chunk_size * topk, torch.int64),
            "tokens": empty(chunk_size * topk, torch.int64),
            "ones": torch.ones(chunk_size * topk, dtype=torch.int64, device=x.device),
            "range": torch.arange(experts, device=x.device),
            "ptrs": [torch.empty_like(p) for p in ptrs],
        }
    scratch = pool[key]
    output = torch.empty_like(x)
    for start in range(0, x.shape[0], chunk_size):
        rows = min(chunk_size, x.shape[0] - start)
        slots = rows * topk
        hidden = scratch["hidden"][:rows]
        hidden.copy_(x[start:start+rows])
        ids = scratch["ids"][:slots]
        ids.copy_(topk_ids[start:start+rows].flatten())
        weights = scratch["weights"][:slots]
        weights.copy_(topk_weights[start:start+rows].flatten())
        counts = scratch["counts"].zero_()
        counts.scatter_add_(0, ids, scratch["ones"][:slots])
        chunk_ptrs = ptrs
        if longest_first:
            sorted_counts = scratch["sorted_counts"]
            sorted_counts[-1:].zero_()
            permutation = scratch["permutation"]
            torch.sort(counts[:-1], stable=True, descending=True, out=(sorted_counts[:-1], permutation))
            inverse = scratch["inverse"]
            inverse.scatter_(0, permutation, scratch["range"])
            torch.index_select(inverse, 0, ids, out=scratch["mapped_ids"][:slots])
            ids = scratch["mapped_ids"][:slots]
            counts = sorted_counts
            chunk_ptrs = scratch["ptrs"]
            for source, dest in zip(ptrs, chunk_ptrs):
                torch.index_select(source, 0, permutation, out=dest)
        order = scratch["order"][:slots]
        torch.sort(ids, stable=True, out=(scratch["sorted_ids"][:slots], order))
        tokens = scratch["tokens"][:slots]
        torch.div(order, topk, rounding_mode="floor", out=tokens)
        sorted_weights = scratch["sorted_weights"][:slots]
        torch.index_select(weights, 0, order, out=sorted_weights)
        result = scratch["result"][:rows].zero_()
        ext.exl3_moe(hidden, result, counts, tokens, sorted_weights, *workspace, 0, *bits, *chunk_ptrs, *flags, limit, groups)
        output[start:start+rows].copy_(result)
    return output
''' +s[pos:]
s=s.replace('def prefill_ablation(layer, method, args, k, n):\n', 'def prefill_ablation(layer, method, args, k, n):\n    candidate_fn = partial(fused_with_reused_buffers, pool={}) if args.reuse_buffers else fused_with_chunk\n')
s=s.replace('fused_with_chunk(candidate_inputs, *options)','candidate_fn(candidate_inputs, *options)')
s=s.replace('                    fused_with_chunk,\n                    input_args=(candidate_inputs, *options),','                    candidate_fn,\n                    input_args=(candidate_inputs, *options),')
s=s.replace('    parser.add_argument("--hybrid-grouped", action="store_true")','    parser.add_argument("--hybrid-grouped", action="store_true")\n    parser.add_argument("--reuse-buffers", action="store_true")')
s=s.replace('        "routing": str(args.route_sample) if args.route_sample else args.routing,','        "routing": str(args.route_sample) if args.route_sample else args.routing,\n        "reuse_buffers": args.reuse_buffers,')
p.write_text(s)
p=Path('benchmarks/exl3_profile_worker.py');s=p.read_text()
s=s.replace('        from kernels.benchmark_exl3_moe import fused_with_chunk','        from functools import partial\n\n        from kernels.benchmark_exl3_moe import fused_with_chunk, fused_with_reused_buffers')
s=s.replace('("groups", "splits", "packing", "longest_first")','("groups", "splits", "packing", "longest_first", "reuse_buffers")')
s=s.replace('            def candidate(x, weights, ids, ptrs, workspace, bits, flags, limit):', '            fused = partial(fused_with_reused_buffers, pool={}) if options.get("reuse_buffers") else fused_with_chunk\n\n            def candidate(x, weights, ids, ptrs, workspace, bits, flags, limit):')
s=s.replace('                return fused_with_chunk(\n', '                return fused(\n')
p.write_text(s)
