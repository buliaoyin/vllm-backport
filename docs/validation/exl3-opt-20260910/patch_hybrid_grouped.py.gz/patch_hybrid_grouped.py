from pathlib import Path
p=Path('benchmarks/kernels/benchmark_exl3_moe.py');s=p.read_text()
pos=s.index('\n\ndef hybrid_with_chunk')
s=s[:pos]+'''

@triton.jit
def _hot_grouped_gemm(A, B, C, Counts, Experts, M: tl.constexpr, N: tl.constexpr, K: tl.constexpr, BM: tl.constexpr, BN: tl.constexpr, BK: tl.constexpr):
    group = tl.program_id(1)
    tile = tl.program_id(0)
    row_tile = tile // tl.cdiv(N, BN)
    col_tile = tile % tl.cdiv(N, BN)
    expert = tl.load(Experts + group)
    count = tl.load(Counts + expert)
    if row_tile * BM < count:
        rows = row_tile * BM + tl.arange(0, BM)
        cols = col_tile * BN + tl.arange(0, BN)
        ks = tl.arange(0, BK)
        accumulator = tl.full((BM, BN), 0, tl.float32)
        for start in range(tl.cdiv(K, BK)):
            offsets_k = start * BK + ks
            a = tl.load(A + group * M * K + rows[:, None] * K + offsets_k[None, :], (rows[:, None] < count) & (offsets_k[None, :] < K), 0)
            b = tl.load(B + group * K * N + offsets_k[:, None] * N + cols[None, :], (offsets_k[:, None] < K) & (cols[None, :] < N), 0)
            accumulator += tl.dot(a, b)
        tl.store(C + group * M * N + rows[:, None] * N + cols[None, :], accumulator.to(C.dtype.element_ty), (rows[:, None] < count) & (cols[None, :] < N))
''' + s[pos:]
s=s.replace('def hybrid_with_chunk(inputs, chunk_size, hot_count, projections):','def hybrid_with_chunk(inputs, chunk_size, hot_count, projections, grouped=False):')
s=s.replace('            projected = torch.bmm(rotated, matrix)','''            if grouped:
                projected = torch.empty((hot_count, hidden.shape[0], n), device=x.device, dtype=torch.float16)
                _hot_grouped_gemm[(triton.cdiv(hidden.shape[0], 32) * triton.cdiv(n, 128), hot_count)](rotated, matrix, projected, counts, hot, hidden.shape[0], n, k, 32, 128, 64, num_warps=4)
            else:
                projected = torch.bmm(rotated, matrix)''')
s=s.replace('        down = project(activated, 2)\n        result.index_add_', '        down = project(activated, 2).masked_fill(~valid[:, :, None], 0)\n        result.index_add_')
s=s.replace('hybrid_with_chunk(inputs, chunk, hot_count, projections) if hot_count', 'hybrid_with_chunk(inputs, chunk, hot_count, projections, args.hybrid_grouped) if hot_count')
s=s.replace('"hot_experts": hot_count, "relative_l2"','"hot_experts": hot_count, "grouped": args.hybrid_grouped, "relative_l2"')
s=s.replace('    parser.add_argument("--hybrid-experts", type=int, nargs="+")','    parser.add_argument("--hybrid-experts", type=int, nargs="+")\n    parser.add_argument("--hybrid-grouped", action="store_true")')
p.write_text(s)
r=Path('/tmp/exl3-opt-20260910/run_hybrid.py');t=r.read_text().replace("f'hybrid-gpu{gpu}'", "f'hybrid-grouped-gpu{gpu}'").replace("'--hybrid-experts','0','2','4','8'", "'--hybrid-grouped','--hybrid-experts','0','2','4','8'").replace("root/'hybrid-status.json'", "root/'hybrid-grouped-status.json'")
Path('/tmp/exl3-opt-20260910/run_hybrid_grouped.py').write_text(t)
