import os,subprocess,json
from pathlib import Path
root=Path('/tmp/exl3-opt-20260910')
status=[]
for gpu in (0,3):
 name=f'linear-gpu{gpu}'
 cmd=['.venv/bin/python','benchmarks/kernels/benchmark_exl3.py','--checkpoint','/home/bul/dev/models1/zai/turboderp/GLM-5.3-Flash-exl3/4.05bpw','--prefill-rows','128','256','512','1024','2048','--output',str(root/f'{name}.json')]
 for key in ('model.language_model.layers.0.self_attn.qkv_proj','model.language_model.layers.3.mlp.shared_experts.gate_proj','model.language_model.layers.3.self_attn.q_b_proj'):
  cmd+=['--matrix',key]
 with (root/f'{name}.log').open('w') as log:
  proc=subprocess.run(cmd,env=dict(os.environ,CUDA_VISIBLE_DEVICES=str(gpu),CUDA_DEVICE_ORDER='PCI_BUS_ID',OMP_NUM_THREADS='1',EXL3_INT8_GEMV='0'),stdout=log,stderr=subprocess.STDOUT)
 status.append({'name':name,'exit_code':proc.returncode,'command':cmd})
 (root/'linear-status.json').write_text(json.dumps(status,indent=2))
 print(name,proc.returncode,flush=True)
 if proc.returncode:break
