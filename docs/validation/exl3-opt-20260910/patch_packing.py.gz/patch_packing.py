from pathlib import Path
p=Path('benchmarks/kernels/benchmark_exl3_moe.py');s=p.read_text().replace('from safetensors import safe_open','from safetensors import safe_open\n\nfrom vllm.triton_utils import tl, triton')
pos=s.index('\n\ndef fused_with_chunk')
s=s[:pos]+'''

@triton.jit
def _route_counts(Ids, Counts, Assignments: tl.constexpr, Experts: tl.constexpr, Block: tl.constexpr):
    expert = tl.program_id(0)
    offsets = tl.arange(0, Block)
    ids = tl.load(Ids + offsets, offsets < Assignments, -1)
    count = tl.sum((ids == expert).to(tl.int32), 0)
    tl.store(Counts + expert, count)


@triton.jit
def _route_pack(Ids, Weights, Counts, Tokens, SortedWeights, Pointers, SortedPointers, Assignments: tl.constexpr, Experts: tl.constexpr, TopK: tl.constexpr, Block: tl.constexpr, ExpertBlock: tl.constexpr, Longest: tl.constexpr):
    expert = tl.program_id(0)
    expert_offsets = tl.arange(0, ExpertBlock)
    counts = tl.load(Counts + expert_offsets, expert_offsets < Experts, 0)
    count = tl.load(Counts + expert)
    if Longest:
        precedes = (counts > count) | ((counts == count) & (expert_offsets < expert))
        precedes = precedes & (expert_offsets < Experts)
        rank = tl.sum(precedes.to(tl.int32), 0)
        offset = tl.sum(tl.where(precedes, counts, 0), 0)
        for component in range(9):
            ptr = tl.load(Pointers + component * Experts + expert)
            tl.store(SortedPointers + component * Experts + rank, ptr)
        tl.store(SortedPointers + 9 * Experts + rank, count)
    else:
        offset = tl.sum(tl.where(expert_offsets < expert, counts, 0), 0)
    offsets = tl.arange(0, Block)
    ids = tl.load(Ids + offsets, offsets < Assignments, -1)
    selected = ids == expert
    positions = offset + tl.cumsum(selected.to(tl.int32), 0) - 1
    weights = tl.load(Weights + offsets, offsets < Assignments, 0)
    tl.store(Tokens + positions, offsets // TopK, selected)
    tl.store(SortedWeights + positions, weights, selected)


def triton_routes(ids, weights, ptrs, topk, longest_first):
    experts = ptrs[0].numel()
    counts = torch.empty(experts + 1, dtype=torch.int64, device=ids.device)
    tokens = torch.empty_like(ids)
    sorted_weights = torch.empty_like(weights)
    pointers = torch.stack(ptrs) if longest_first else ptrs[0]
    # Last row is the permuted histogram; keep a zero sentinel for the extension.
    sorted_pointers = torch.zeros((10, experts + 1), dtype=torch.int64, device=ids.device) if longest_first else pointers
    # Packed pointer stride excludes the trailing histogram sentinel.
    packed = torch.zeros(10 * experts + 1, dtype=torch.int64, device=ids.device) if longest_first else pointers
    _route_counts[(experts + 1,)](ids, counts, ids.numel(), experts, triton.next_power_of_2(ids.numel()))
    _route_pack[(experts,)](ids, weights, counts, tokens, sorted_weights, pointers, packed, ids.numel(), experts, topk, triton.next_power_of_2(ids.numel()), triton.next_power_of_2(experts), longest_first)
    if longest_first:
        ptrs = list(packed[:9 * experts].view(9, experts).unbind(0))
        counts = packed[9 * experts:]
    return counts, tokens, sorted_weights, ptrs
''' + s[pos:]
start=s.index('        if packing == "align":')
end=s.index('        result = torch.zeros_like',start)
s=s[:start]+'''        if packing == "triton":
            counts, tokens, sorted_weights, chunk_ptrs = triton_routes(ids, weights, chunk_ptrs, topk_ids.shape[1], False)
        else:
            if packing == "align":
                from vllm.model_executor.layers.fused_moe.moe_align_block_size import moe_align_block_size
                order = moe_align_block_size(ids.view(-1, topk_ids.shape[1]), 1, ptrs[0].numel())[0].long()
            else:
                order = torch.argsort(ids, stable=True)
            tokens = torch.div(order, topk_ids.shape[1], rounding_mode="floor")
            sorted_weights = weights[order]
''' + s[end:]
s=s.replace('            weights[order],\n            *workspace,','            sorted_weights,\n            *workspace,',1)
s=s.replace('choices=["sort", "align"], nargs="+"','choices=["sort", "align", "triton"], nargs="+"')
# Triton packs and prioritizes in two kernels; avoid the torch histogram/permutation.
start=s.index('        counts = torch.zeros(ptrs[0].numel() + 1',s.index('def fused_with_chunk'))
end=s.index('        result = torch.zeros_like',start)
old=s[start:end]
# Indent the existing path into an else and replace the redundant triton block inside it.
old=old.replace('        if packing == "triton":\n            counts, tokens, sorted_weights, chunk_ptrs = triton_routes(ids, weights, chunk_ptrs, topk_ids.shape[1], False)\n        else:\n', '')
# Correct the nested tail after removing its else.
pos=old.index('            if packing == "align":')
old=old[:pos]+''.join(line[4:] if line.startswith('    ') else line for line in old[pos:].splitlines(keepends=True))
s=s[:start]+'''        if packing == "triton":
            counts, tokens, sorted_weights, chunk_ptrs = triton_routes(ids, weights, chunk_ptrs, topk_ids.shape[1], longest_first)
        else:
'''+''.join('    '+line if line.strip() else line for line in old.splitlines(keepends=True))+s[end:]
s=s.replace('    sorted_pointers = torch.zeros((10, experts + 1), dtype=torch.int64, device=ids.device) if longest_first else pointers\n','')
p.write_text(s)
