import collections
import json
import statistics
from pathlib import Path
root = Path('/tmp/exl3-opt-20260910')
model_names = ['moe-c512-sweep','moe-c1024-variants','equal-c1024','pp19-c1024','pp21-c1024','pp21-c512','pp21-c2048','reuse-model','long-final','long-c2048','eval-final','tile-model','nvfp4-pp21-c1024','awq-pp21-c1024','awq-pp18-c1024','exl3-pp18-c1024']
result = {'models': {}, 'micro': {}, 'checks': {'retrieval': 0, 'retrieval_passed': 0, 'generated_tokens_valid': True, 'zero_cache_hits': True}}
for name in model_names:
    file = root / (name + '.json')
    if not file.exists():
        continue
    data = json.loads(file.read_text())
    groups = collections.defaultdict(list)
    for record in data.get('perf', []):
        label = record.get('variant', {}).get('name')
        if not label:
            capacity = record.get('workspace_capacity')
            label = f'capacity{capacity}' if capacity else 'production'
        groups[label, record['case']].append(record)
        for row in record['rows']:
            result['checks']['generated_tokens_valid'] &= row['new_tokens'] == data['args']['tokens']
            result['checks']['zero_cache_hits'] &= row['cached_tokens'] == 0
        for check in record.get('checks', []):
            result['checks']['retrieval'] += 1
            result['checks']['retrieval_passed'] += int(check['matched'])
    summary = {'cases': [], 'profile': [], 'runtime': data.get('runtime_before', []), 'args': data['args'], 'environment': data.get('environment', {}), 'benchmark_source_sha256': data.get('benchmark_source_sha256')}
    for (label, case), rows in groups.items():
        item = {'variant': label, 'case': case, 'repeats': len(rows), 'max_ttft_median': statistics.median(r['max_ttft'] for r in rows), 'max_ttft_min': min(r['max_ttft'] for r in rows), 'max_ttft_max': max(r['max_ttft'] for r in rows), 'checks': sum(len(r.get('checks', [])) for r in rows), 'checks_passed': sum(c['matched'] for r in rows for c in r.get('checks', []))}
        if len(rows[0]['rows']) == 1:
            item['prefill_tps'] = statistics.median(r['rows'][0]['prompt_tokens'] / r['rows'][0]['prefill'] for r in rows)
            item['decode_tps'] = statistics.median((r['rows'][0]['new_tokens']-1) / r['rows'][0]['decode'] for r in rows)
        summary['cases'].append(item)
    if 'event_profile' in data:
        summary['profile_wall_seconds'] = data['event_profile']['seconds']
        for rank in data['event_profile'].get('ranks', []):
            summary['profile'].append({'gpu': rank['gpu'], 'sum_ms': {label: sum(samples) for label, samples in rank['timings_ms'].items()}, 'routing_totals': {key: sum(row.get(key, 0) for row in rank.get('routing', [])) for key in ['tokens','grouped_active_expert_visits','grouped_rows_in_16row_tiles','chunk128_active_expert_visits','chunk128_rows_in_16row_tiles']}})
    summary['eval_total'] = len(data.get('eval', []))
    summary['eval_correct'] = sum(r['correct'] for r in data.get('eval', []))
    summary['eval_truncated'] = sum(r['finish_reason'] == 'length' for r in data.get('eval', []))
    result['models'][name] = summary
for file in root.glob('*.json'):
    if not file.name.startswith(('micro-','hybrid-','linear-gpu','reuse-0-gpu','reuse-1-gpu','tile-gpu')) or file.name.endswith('status.json'):
        continue
    data = json.loads(file.read_text())
    if not isinstance(data, dict) or 'rows' not in data:
        continue
    rows = []
    for row in data['rows']:
        rows.extend(row.get('chunks', [row]))
    valid = [r for r in rows if 'relative_l2' in r]
    result['micro'][file.stem] = {'gpu': data.get('gpu'), 'cases': len(valid), 'max_relative_l2': max((r['relative_l2'] for r in valid), default=0), 'routing': data.get('routing')}
result['micro_total_cases'] = sum(r['cases'] for r in result['micro'].values())
(root/'summary.json').write_text(json.dumps(result,indent=2))
print(json.dumps({'checks':result['checks'],'micro_total_cases':result['micro_total_cases']},indent=2))
for name, group in result['models'].items():
    print(name, [(r['variant'],r['case'],round(r['max_ttft_median'],4)) for r in group['cases']], 'eval',group['eval_correct'],group['eval_total'])
