from pathlib import Path
p=Path('benchmarks/kernels/benchmark_exl3.py');s=p.read_text()
s=s.replace('from vllm.model_executor.layers.quantization.exl3 import _exl3_linear','from vllm.model_executor.layers.quantization.exl3 import _exl3_linear, _extension')
pos=s.index('\n\n@torch.inference_mode()')
s=s[:pos]+'''

def prefill_ablation(weights, key, args, result):
    ext = _extension()
    k, n = weights["suh"].numel(), weights["svh"].numel()
    bits = weights["trellis"].shape[-1] // 16
    flags = ("mcg" in weights, "mul1" in weights)
    rotated_weight = torch.empty((k, n), device="cuda", dtype=torch.float16)
    ext.reconstruct_slice(rotated_weight, weights["trellis"], bits, *flags, 0)
    original_weight = torch.empty_like(rotated_weight)
    ext.reconstruct_had_slice(original_weight, weights["trellis"], weights["suh"], weights["svh"], bits, *flags, 0)

    def calculate(x, mode):
        if mode == "baseline":
            return _exl3_linear(x, weights["trellis"], weights["suh"], weights["svh"], *flags)
        inp = x.half().contiguous()
        out = torch.empty((x.shape[0], n), device=x.device, dtype=torch.float16)
        if mode == "cached_original":
            ext.hgemm(inp, original_weight, out)
        elif mode == "reconstruct_fused":
            weight = torch.empty_like(original_weight)
            ext.reconstruct_had_slice(weight, weights["trellis"], weights["suh"], weights["svh"], bits, *flags, 0)
            ext.hgemm(inp, weight, out)
        elif mode == "direct_gemm":
            scratch = torch.empty_like(inp)
            ext.exl3_gemm(inp, weights["trellis"], out, weights["suh"], scratch, weights["svh"], -1, *flags, 0)
        else:
            rotated = torch.empty_like(inp)
            ext.had_r_128(inp, rotated, weights["suh"], None, 1.0)
            if mode == "cached_rotated_torch":
                torch.mm(rotated, rotated_weight, out=out)
            else:
                ext.hgemm(rotated, rotated_weight, out)
            ext.had_r_128(out, out, None, weights["svh"], 1.0)
        return out.to(x.dtype)

    for rows in args.prefill_rows:
        x = torch.randn((rows, k), device="cuda", dtype=torch.bfloat16)
        reference = calculate(x, "baseline")
        for mode in ("baseline", "cached_rotated", "cached_rotated_torch", "cached_original", "reconstruct_fused", "direct_gemm"):
            actual = calculate(x, mode)
            relative = ((actual.float() - reference.float()).norm() / reference.float().norm()).item()
            assert relative < 0.01, (key, rows, mode, relative)
            for _ in range(3):
                calculate(x, mode)
            timings = bench_gpu_time_with_cudagraph(calculate, input_args=(x, mode), cold_l2_cache=True, num_iters_within_graph=1, dry_run_iters=3, repeat_iters=15)
            record = {"matrix": key, "shape": [rows, k, n], "bits": bits, "mode": mode, "median_ms": statistics.median(timings), "relative_l2": relative, "cache_bytes": k*n*2 if mode.startswith("cached") else 0}
            result["rows"].append(record)
            print(record, flush=True)
            args.output.write_text(json.dumps(result, indent=2))
''' +s[pos:]
s=s.replace('    parser.add_argument("--output", type=Path, required=True)','    parser.add_argument("--output", type=Path, required=True)\n    parser.add_argument("--prefill-rows", type=int, nargs="+")')
s=s.replace('    result = {','    torch.manual_seed(20260910)\n    result = {',1)
s=s.replace('        upstream = LinearEXL3(', '        if args.prefill_rows:\n            prefill_ablation(weights, key, args, result)\n            continue\n        upstream = LinearEXL3(',1)
p.write_text(s)
