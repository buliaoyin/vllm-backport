from pathlib import Path
p=Path('benchmarks/exl3_profile_worker.py');s=p.read_text()
s=s.replace('        self._exl3_event_profile = state\n', '''        self._exl3_event_profile = state
        layer_prefixes = {}
        for module in self.get_model().modules():
            method = getattr(module, "quant_method", None)
            if isinstance(method, exl3.Exl3MoEMethod):
                layer_prefixes[method.ptrs[0].data_ptr()] = method.prefix
''',1)
s=s.replace('                    state["routing"].append(ids.detach().clone())', '''                    workspace = kwargs.get("workspace", args[4] if len(args) > 4 else None)
                    pointers = kwargs.get("ptrs", args[3] if len(args) > 3 else None)
                    state["routing"].append((ids.detach().clone(), workspace[0].shape[1], layer_prefixes[pointers[0].data_ptr()]))''')
s=s.replace('        for ids in state["routing"]:', '''        for ids, capacity, prefix in state["routing"]:
            grouped_counts = torch.stack([
                torch.bincount(chunk.flatten().long(), minlength=288)
                for chunk in ids.split(capacity)
            ])''')
s=s.replace('                    "tokens": ids.shape[0],','''                    "prefix": prefix,
                    "workspace_capacity": capacity,
                    "grouped_active_expert_visits": (grouped_counts > 0).sum().item(),
                    "grouped_rows_in_16row_tiles": (((grouped_counts + 15) // 16) * 16).sum().item(),
                    "tokens": ids.shape[0],''',1)
p.write_text(s)
