// Benchmark-only template instantiations; upstream headers remain unmodified.
#include "/home/bul/dev/exllamav3/exllamav3/exllamav3_ext/quant/exl3_moe_common.cuh"
#undef MOE_TILESIZE_K
#define MOE_TILESIZE_K 16
#define exl3_moe_kernel exl3_moe_k16_kernel
#include "/home/bul/dev/exllamav3/exllamav3/exllamav3_ext/quant/exl3_moe_kernel.cuh"
extern "C" void* exl3_moe_k4_n128_k16_cb2() { return (void*) exl3_moe_kernel<4,128,2>; }
extern "C" void* exl3_moe_k4_n256_k16_cb2() { return (void*) exl3_moe_kernel<4,256,2>; }
