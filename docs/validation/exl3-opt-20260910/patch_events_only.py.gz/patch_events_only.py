from pathlib import Path
p=Path('benchmarks/benchmark_exl3.py');s=p.read_text()
s=s.replace('args.profile_dir or args.moe_workspace_sizes or args.moe_variants or args.capture_routing_dir','args.profile_dir or args.event_profile or args.moe_workspace_sizes or args.moe_variants or args.capture_routing_dir')
s=s.replace('    parser.add_argument("--profile-dir", type=Path)','    parser.add_argument("--profile-dir", type=Path)\n    parser.add_argument("--event-profile", action="store_true")')
s=s.replace('        result["event_profile_install"] = backend.llm.collective_rpc(', '    if args.profile_dir or args.event_profile:\n        result["event_profile_install"] = backend.llm.collective_rpc(')
p.write_text(s)
