import os,json,subprocess,time
from pathlib import Path
r=Path('/tmp/exl3-opt-20260910');status=[]
for name,placement in [('eval-pp21','10,7,7,21'),('eval-equal','11,11,11,12')]:
 cmd=['.venv/bin/python',str(r/'eval_controls.py'),'--output',str(r/f'{name}.json')]
 env=dict(os.environ,CUDA_DEVICE_ORDER='PCI_BUS_ID',CUDA_VISIBLE_DEVICES='0,1,2,3',NCCL_P2P_DISABLE='1',VLLM_PP_LAYER_PARTITION=placement,OMP_NUM_THREADS='1',EXL3_INT8_GEMV='0',VLLM_DETERMINISTIC_MOE_ALIGN='0',VLLM_EXL3_MOE_MAX_TOKENS='1024',VLLM_EXL3_MOE_PRIORITY='1')
 print('RUN',name,flush=True);start=time.time()
 with (r/f'{name}.log').open('w') as f:proc=subprocess.run(cmd,env=env,stdout=f,stderr=subprocess.STDOUT)
 status.append({'name':name,'exit_code':proc.returncode,'command':cmd,'environment':{k:env[k] for k in env if k.startswith(('VLLM_','CUDA_','EXL3_','NCCL_','OMP_'))},'start':start,'end':time.time()});(r/'eval-control-status.json').write_text(json.dumps(status,indent=2));print('DONE',name,proc.returncode,flush=True)
 if proc.returncode:break
