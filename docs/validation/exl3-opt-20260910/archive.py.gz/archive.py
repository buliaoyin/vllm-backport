import difflib,gzip,hashlib,importlib.metadata,importlib.util,json,shutil,subprocess
from pathlib import Path
r=Path('/tmp/exl3-opt-20260910');dest=Path('/home/bul/dev/vllm-backport/docs/validation/exl3-opt-20260910');dest.mkdir(exist_ok=True)
allowed={'.json','.gz','.py','.sh','.md','.log','.txt','.cu','.cuh'}
external={}
for f in sorted(r.rglob('*')):
 if not f.is_file() or '__pycache__' in f.parts:continue
 rel=f.relative_to(r)
 if f.suffix in ('.so','.pt'):
  external[str(f)]={'sha256':hashlib.sha256(f.read_bytes()).hexdigest(),'bytes':f.stat().st_size,'reason':'Local experiment binary or captured routes; regenerate with archived scripts'};continue
 if f.suffix not in allowed:continue
 target=dest/rel
 if f.suffix not in ('.json','.gz'):target=target.with_suffix(target.suffix+'.gz')
 target.parent.mkdir(parents=True,exist_ok=True)
 data=f.read_bytes();target.write_bytes(data if f.suffix in ('.json','.gz') else gzip.compress(data,mtime=0))
paths=['vllm/model_executor/layers/quantization/exl3.py','vllm/envs.py','tests/quantization/test_exl3.py','benchmarks/benchmark_exl3.py','benchmarks/exl3_profile_worker.py','benchmarks/kernels/benchmark_exl3_moe.py','benchmarks/kernels/benchmark_exl3.py','docs/features/quantization/exl3.md']
current={}
for name in paths:
 data=Path(name).read_bytes();current[name]=hashlib.sha256(data).hexdigest();out=dest/'current-sources'/Path(name+'.gz');out.parent.mkdir(parents=True,exist_ok=True);out.write_bytes(gzip.compress(data,mtime=0))
patch=[]
for name in paths[:3]:
 old=(r/'baseline'/Path(name).name).read_text().splitlines(True);new=Path(name).read_text().splitlines(True);patch.extend(difflib.unified_diff(old,new,fromfile='a/'+name,tofile='b/'+name))
(dest/'production-optimization.patch.gz').write_bytes(gzip.compress(''.join(patch).encode(),mtime=0))
shutil.copyfile('/home/bul/dev/exllamav3/LICENSE',dest/'LICENSE-exllamav3.txt')
upstream={p:hashlib.sha256(Path('/home/bul/dev/exllamav3',p).read_bytes()).hexdigest() for p in ['exllamav3/exllamav3_ext/quant/exl3_moe.cu','exllamav3/exllamav3_ext/quant/exl3_moe_common.cuh','exllamav3/exllamav3_ext/quant/exl3_moe_kernel.cuh','exllamav3/exllamav3_ext/quant/exl3_gemm_inner.cuh','LICENSE']}
metadata={'current_source_sha256':current,'upstream_git_revision':subprocess.check_output(['git','-C','/home/bul/dev/exllamav3','rev-parse','HEAD'],text=True).strip(),'upstream_git_status':subprocess.check_output(['git','-C','/home/bul/dev/exllamav3','status','--short'],text=True),'upstream_source_sha256':upstream,'local_artifacts':external,'versions':{n:importlib.metadata.version(n) for n in ['torch','triton','exllamav3','safetensors','flashinfer-python']},'gpu_inventory':subprocess.check_output(['nvidia-smi','--query-gpu=name,uuid,driver_version,memory.total','--format=csv,noheader'],text=True)}
extension=Path(importlib.util.find_spec('exllamav3_ext').origin)
metadata['installed_extension']={'path':str(extension),'sha256':hashlib.sha256(extension.read_bytes()).hexdigest()}
(dest/'provenance.json').write_text(json.dumps(metadata,indent=2))
manifest={str(p.relative_to(dest)):{'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'bytes':p.stat().st_size} for p in sorted(dest.rglob('*')) if p.is_file() and p.name!='sha256.json'}
(dest/'sha256.json').write_text(json.dumps(manifest,indent=2));print('Archived',len(manifest),'files,',round(sum(x['bytes'] for x in manifest.values())/1024**2,2),'MiB')
