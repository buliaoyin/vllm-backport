import torch
import triton
import triton.language as tl
from benchmark_exl3_moe import _extension, triton_routes

def cold_fused(
    inputs,
    chunk_size,
    groups=-1,
    splits=1,
    split_threshold=0,
    packing="sort",
    longest_first=False,
):
    """Ablate token grouping only; callers must check workspace capacity."""
    x, topk_weights, topk_ids, ptrs, workspace, bits, flags, limit = inputs
    ext = _extension()
    output = torch.empty_like(x)
    for start in range(0, x.shape[0], chunk_size):
        hidden = x[start : start + chunk_size].to(torch.float16).contiguous()
        ids = topk_ids[start : start + chunk_size].to(torch.int64).flatten()
        weights = topk_weights[start : start + chunk_size].to(torch.float16).flatten()
        chunk_ptrs = ptrs
        if splits > 1:
            sub_ids = (
                torch.arange(hidden.shape[0], device=x.device).repeat_interleave(
                    topk_ids.shape[1]
                )
                % splits
            )
            if split_threshold:
                original_counts = torch.zeros(
                    ptrs[0].numel() // splits + 1, dtype=torch.int64, device=x.device
                )
                original_counts.scatter_add_(0, ids, torch.ones_like(ids))
                sub_ids = torch.where(
                    original_counts[ids] >= split_threshold, sub_ids, 0
                )
            ids = ids * splits + sub_ids
        if packing == "triton":
            counts, tokens, sorted_weights, chunk_ptrs = triton_routes(
                ids, weights, chunk_ptrs, topk_ids.shape[1], longest_first
            )
        else:
            counts = torch.zeros(
                ptrs[0].numel() + 1, dtype=torch.int64, device=x.device
            )
            counts.scatter_add_(0, ids, torch.ones_like(ids))
            if longest_first:
                permutation = torch.argsort(counts[:-1], descending=True, stable=True)
                inverse = torch.empty_like(permutation)
                inverse.scatter_(
                    0, permutation, torch.arange(permutation.numel(), device=x.device)
                )
                inverse = torch.cat((inverse, inverse.new_full((1,), inverse.numel())))
                ids = inverse[ids]
                counts = torch.cat((counts[:-1][permutation], counts[-1:]))
                chunk_ptrs = [ptr[permutation] for ptr in ptrs]
            if packing == "align":
                from vllm.model_executor.layers.fused_moe.moe_align_block_size import (
                    moe_align_block_size,
                )

                order = moe_align_block_size(
                    ids.view(-1, topk_ids.shape[1]), 1, ptrs[0].numel()
                )[0].long()
            else:
                order = torch.argsort(ids, stable=True)
            tokens = torch.div(order, topk_ids.shape[1], rounding_mode="floor")
            sorted_weights = weights[order]
        result = torch.zeros_like(hidden, dtype=torch.float32)
        ext.exl3_moe(
            hidden,
            result,
            counts,
            tokens,
            sorted_weights,
            *workspace,
            0,
            *bits,
            *chunk_ptrs,
            *flags,
            limit,
            groups,
        )
        output[start : start + hidden.shape[0]].copy_(result)
    return output

@triton.jit
def _cached_grouped_gemm(
    A,
    B,
    C,
    Counts,
    Experts,
    MatrixIndices,
    M: tl.constexpr,
    N: tl.constexpr,
    K: tl.constexpr,
    BM: tl.constexpr,
    BN: tl.constexpr,
    BK: tl.constexpr,
):
    group = tl.program_id(1)
    tile = tl.program_id(0)
    row_tile = tile // tl.cdiv(N, BN)
    col_tile = tile % tl.cdiv(N, BN)
    expert = tl.load(Experts + group)
    count = tl.load(Counts + expert)
    matrix_index = tl.load(MatrixIndices + group)
    if row_tile * BM < count:
        rows = row_tile * BM + tl.arange(0, BM)
        cols = col_tile * BN + tl.arange(0, BN)
        ks = tl.arange(0, BK)
        accumulator = tl.full((BM, BN), 0, tl.float32)
        for start in range(tl.cdiv(K, BK)):
            offsets_k = start * BK + ks
            a = tl.load(
                A + group * M * K + rows[:, None] * K + offsets_k[None, :],
                (rows[:, None] < count) & (offsets_k[None, :] < K),
                0,
            )
            b = tl.load(
                B + matrix_index * K * N + offsets_k[:, None] * N + cols[None, :],
                (offsets_k[:, None] < K) & (cols[None, :] < N),
                0,
            )
            accumulator += tl.dot(a, b)
        tl.store(
            C + group * M * N + rows[:, None] * N + cols[None, :],
            accumulator.to(C.dtype.element_ty),
            (rows[:, None] < count) & (cols[None, :] < N),
        )

def hybrid_cached(inputs, chunk_size, hot_count, caches, mapping):
    grouped = True
    """Reconstruct a fixed number of GPU-selected hot experts, with no CPU readback."""
    x, weights, ids, ptrs, workspace, bits, flags, limit = inputs
    ext = _extension()
    output = torch.empty_like(x)
    experts = ptrs[0].numel()
    for start in range(0, x.shape[0], chunk_size):
        hidden = x[start : start + chunk_size]
        chunk_ids = ids[start : start + chunk_size].long()
        chunk_weights = weights[start : start + chunk_size]
        counts = torch.zeros(experts + 1, dtype=torch.int64, device=x.device)
        counts.scatter_add_(
            0, chunk_ids.flatten(), torch.ones_like(chunk_ids.flatten())
        )
        hot = counts[:-1].topk(hot_count).indices
        selected = torch.zeros(experts + 1, dtype=torch.bool, device=x.device)
        selected.index_fill_(0, hot, True)
        cold_ids = torch.where(selected[chunk_ids], experts, chunk_ids)
        cold_inputs = (
            hidden.float(),
            chunk_weights,
            cold_ids,
            ptrs,
            workspace,
            bits,
            flags,
            limit,
        )
        result = cold_fused(cold_inputs, chunk_size, longest_first=True)
        order = torch.argsort(chunk_ids.flatten(), stable=True)
        offsets = counts.cumsum(0) - counts
        positions = (
            offsets[hot, None] + torch.arange(hidden.shape[0], device=x.device)[None, :]
        )
        valid = (
            torch.arange(hidden.shape[0], device=x.device)[None, :] < counts[hot, None]
        )
        assignment = order[positions.clamp(max=order.numel() - 1)]
        tokens = assignment // chunk_ids.shape[1]
        routing = chunk_weights.flatten()[assignment].half() * valid
        gathered = hidden[tokens].half()

        def project(value, index, hot=hot, hidden=hidden, counts=counts):
            matrix, all_suh, all_svh = caches[index]
            matrix_indices = mapping[hot]
            suh, svh = all_suh[matrix_indices], all_svh[matrix_indices]
            k, n = suh.shape[1], svh.shape[1]
            rotated = torch.empty_like(value)
            ext.had_r_128(
                (value * suh[:, None, :]).reshape(-1, k),
                rotated.view(-1, k),
                None,
                None,
                1.0,
            )
            if grouped:
                projected = torch.empty(
                    (hot_count, hidden.shape[0], n),
                    device=x.device,
                    dtype=torch.float16,
                )
                _cached_grouped_gemm[
                    (triton.cdiv(hidden.shape[0], 32) * triton.cdiv(n, 128), hot_count)
                ](
                    rotated,
                    matrix,
                    projected,
                    counts,
                    hot,
                    matrix_indices,
                    hidden.shape[0],
                    n,
                    k,
                    32,
                    128,
                    64,
                    num_warps=4,
                )
            else:
                projected = torch.bmm(rotated, matrix)
            ext.had_r_128(projected.view(-1, n), projected.view(-1, n), None, None, 1.0)
            return projected * svh[:, None, :]

        gate = project(gathered, 0)
        up = project(gathered, 1)
        if limit:
            gate = gate.clamp(max=limit)
            up = up.clamp(-limit, limit)
        activated = (torch.nn.functional.silu(gate.float()) * up).half()
        down = project(activated, 2).masked_fill(~valid[:, :, None], 0)
        result.index_add_(
            0,
            tokens.flatten(),
            (down.float() * routing[:, :, None]).reshape(-1, x.shape[1]),
        )
        output[start : start + hidden.shape[0]].copy_(result)
    return output
