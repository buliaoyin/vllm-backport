import hashlib,json,os,subprocess,time
from pathlib import Path
r=Path('/tmp/exl3-opt-20260910');name='tile-model'
cmd=['.venv/bin/python',str(r/'benchmark_tile_model.py'),'--backend','vllm','--inputs',str(r/'tile-model-inputs.json.gz'),'--output',str(r/f'{name}.json'),'--pp','4','--chunk-size','1024','--max-model-len','16384','--kv-cache-gib','4','--batch-size','4','--warmups','1','--repeats','3','--tokens','32','--skip-eval','--moe-variants',str(r/'tile-model-variants.json')]
env=dict(os.environ,PYTHONPATH=str(r)+':/home/bul/dev/vllm-backport/benchmarks',CUDA_DEVICE_ORDER='PCI_BUS_ID',CUDA_VISIBLE_DEVICES='0,1,2,3',NCCL_P2P_DISABLE='1',VLLM_PP_LAYER_PARTITION='10,7,7,21',OMP_NUM_THREADS='1',EXL3_INT8_GEMV='0',VLLM_DETERMINISTIC_MOE_ALIGN='0',VLLM_EXL3_MOE_MAX_TOKENS='1024',VLLM_EXL3_MOE_PRIORITY='1')
start=time.time()
with (r/f'{name}.log').open('w') as f:proc=subprocess.run(cmd,env=env,stdout=f,stderr=subprocess.STDOUT)
(r/'tile-model-status.json').write_text(json.dumps({'exit_code':proc.returncode,'command':cmd,'environment':{k:env[k] for k in env if k.startswith(('VLLM_','CUDA_','EXL3_','NCCL_','OMP_','PYTHONPATH'))},'source_sha256':{n:hashlib.sha256((r/n).read_bytes()).hexdigest() for n in ('tile_model_worker.py','benchmark_tile_model.py','exl3_tile_launch.py','moe_k16_minblocks2.so')},'start':start,'end':time.time()},indent=2));print(name,proc.returncode,flush=True)
