import gzip,hashlib,json,re
from pathlib import Path
r=Path('/tmp/exl3-opt-20260910');summary=json.loads((r/'summary.json').read_text())
assert summary['checks']['retrieval']==summary['checks']['retrieval_passed']
assert summary['checks']['generated_tokens_valid'] and summary['checks']['zero_cache_hits']
assert summary['micro_total_cases']==394
assert all(v['max_relative_l2']<0.01 for v in summary['micro'].values())
expected=['moe-c512-sweep','moe-c1024-variants','equal-c1024','pp19-c1024','pp21-c1024','pp21-c512','pp21-c2048','reuse-model','long-final','long-c2048','tile-model','nvfp4-pp21-c1024','awq-pp18-c1024','exl3-pp18-c1024']
for name in expected:
 d=json.loads((r/(name+'.json')).read_text());groups={}
 for row in d['perf']:
  key=(row.get('variant',{}).get('name'),row.get('workspace_capacity'),row['case']);groups.setdefault(key,[]).append(row)
 assert groups and all(len(v)==3 for v in groups.values()),(name,{str(k):len(v) for k,v in groups.items()})
assert len(json.loads((r/'final-status.json').read_text()))==2
assert all(x['exit_code']==0 for x in json.loads((r/'final-status.json').read_text()))
assert len(json.loads((r/'comparator-pp18-status.json').read_text()))==2
assert all(x['exit_code']==0 for x in json.loads((r/'comparator-pp18-status.json').read_text()))
source=json.loads((r/'final-status.json').read_text())[0]['source_sha256'];hashes={}
for name in ['vllm/model_executor/layers/quantization/exl3.py','vllm/envs.py','tests/quantization/test_exl3.py']:
 hashes[name]=hashlib.sha256(Path(name).read_bytes()).hexdigest();assert hashes[name]==source[name]
tests={}
for gpu in (0,3):
 log=(r/f'tests-final-gpu{gpu}.log').read_text();match=re.search(r'(\d+) passed',log);assert match and int(match[1])==37;tests[str(gpu)]=int(match[1])
for name in ['precommit-complete.log','precommit-report.log','mypy-final.log','precommit-final-report.log']:
 text=(r/name).read_text();assert 'Passed' in text and 'Failed' not in text,name
inputs=json.loads(gzip.decompress((r/'moe-long-eval64.json.gz').read_bytes()));cases=[x for x in inputs['cases'] if x['name'] in ('p8192_b1','p8192_b4')]
for fmt in ('nvfp4','awq','exl3'):
 d=json.loads(gzip.decompress((r/f'{fmt}-8k-inputs.json.gz').read_bytes()));assert d['cases']==cases and d['eos_ids']==inputs['eos_ids'],fmt
controls={}
for name in ['eval-pp21','eval-equal']:
 d=json.loads((r/f'{name}.json').read_text());rows=[x for v in d['variants'] for x in v['eval']];assert len(rows)==32 and all(x['finish_reason']=='stop' and x['cached_tokens']==0 for x in rows)
 controls[name]={'correct':sum(x['correct'] for x in rows),'total':len(rows),'variants':[{'repeat':v['repeat'],'variant':v['variant'],'predicted12':v['eval'][0]['predicted']} for v in d['variants']]}
result={'production_source_matches_long_and_eval_run':True,'source_sha256':hashes,'gpu_tests':tests,'micro_cases':394,'micro_max_relative_l2':max(v['max_relative_l2'] for v in summary['micro'].values()),'perf':summary['checks'],'model_repeats_verified':expected,'gsm8k':{'correct':summary['models']['long-final']['eval_correct'],'total':summary['models']['long-final']['eval_total'],'truncated':summary['models']['long-final']['eval_truncated'],'single_question_controls':controls},'lint':'pre-commit passed','types':'mypy-3.12 passed','expected_failures':[{'experiment':'awq-pp21-c1024','reason':'GPU3 allocation of 4.5 GiB failed during model construction; 21-layer placement exceeds memory; no performance samples'},{'experiment':'eval-entrypoint-failure','reason':'Temporary helper lacked multiprocessing main guard; fixed and all controls completed'},{'experiment':'hybrid-gpu0-capture-failure','reason':'CUDA graph-incompatible boolean indexing in experimental helper; replaced with index_fill_ and rerun'}]}
(r/'validation.json').write_text(json.dumps(result,indent=2));print(json.dumps({k:v for k,v in result.items() if k!='gsm8k'},indent=2))
