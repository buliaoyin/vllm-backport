# EXL3 optimization experiment notes

Production changes retained so far:
- Workspaces and token groups share a dynamic capacity, default min(1024, scheduler max_num_batched_tokens).
- For >=256 tokens, order experts by descending token count, with stable ties; remap routes and nine pointer tables together.
- Original <=8 token decode path, trellis/codebook/scale representations and serialized shared experts remain in use.

No production cache, no requantization, no upstream extension changes.

Evidence:
- Capacity512 first sweep: 8K B1 outer512 TTFT 6.2326 -> 4.7960 -> 3.9589 for capacity128/256/512; all 9 checks pass.
- Outer1024 experiments (three repeats): baseline128 6.7663; capacity512 4.2640; capacity1024 3.7665; priority-sort 3.4709; priority-triton 3.4863; fused-linear 3.7833; rotated-cache 3.7286; original-cache 3.6966; cache+shared-overlap 3.6773; priority-triton+original-cache 3.4122. All 30 checks pass.
- Cache allocates 16.01 GiB minus unused LM head across four GPUs for each cached representation; actual bytes per rank in workspace_sweep. Gains too small for default adoption.
- Fixed-H GPU-selected hot experts reconstructed to FP16 then bmm are slower than fused, despite no CPU counts readback. Variable-M Triton grouped GEMM reduces padding cost but is still slower.
- GPU route packing in Triton is not faster than torch sort at complete-model scope. Keep as ablation, not production.
- Wider cooperative groups change reduction rounding (~0.00164 relative L2) and are not consistently faster.
- Splitting all experts wastes tiles; selectively splitting hot experts is only a marginal win on the sampled real routes, and largest-first scheduling is simpler.
- M=32 cannot be selected by a tuning constant alone: upstream exl3_gemm_inner.cuh statically requires TILESIZE_M==16 and hardcodes fragment/epilogue layouts. A general M kernel is future kernel work, not an experimentally validated gain.
- CUPTI unsupported on CMP (error42), use CUDA graph events and independent rank-local CUDA boundary events; do not add nested scopes or equate rank sums to request wall time.

Validation completed: 37 tests on GPU0 +37 GPU3, pre-commit passes, mypy3.12 passes. Production placement/long-context/model-eval work still pending.
