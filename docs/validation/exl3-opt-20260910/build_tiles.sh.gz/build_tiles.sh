#!/bin/bash
set -euo pipefail
/usr/local/cuda-13.0/bin/nvcc --shared --cudart shared -Xcompiler -fPIC -O3 -std=c++20 --use_fast_math --expt-relaxed-constexpr --expt-extended-lambda -lineinfo -Xptxas=-v -gencode=arch=compute_80,code=sm_80 -gencode=arch=compute_120,code=sm_120 -I/home/bul/dev/vllm-backport/.venv/lib/python3.12/site-packages/torch/include -I/home/bul/dev/vllm-backport/.venv/lib/python3.12/site-packages/torch/include/torch/csrc/api/include /tmp/exl3-opt-20260910/moe_k16.cu -o /tmp/exl3-opt-20260910/moe_k16.so
