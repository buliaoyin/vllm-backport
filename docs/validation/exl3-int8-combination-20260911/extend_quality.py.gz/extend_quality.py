"""Resolve output-budget truncation on the union of affected paired prompts."""
import gzip
import json
import os
import subprocess
import time
from pathlib import Path
R=Path('/home/bul/dev/vllm-backport');O=Path('/tmp/exl3-int8-combo-20260911')
while True:
    try:
        runs=json.loads((O/'status.json').read_text())
        if any(r.get('exit_code',0)!=0 for r in runs):raise RuntimeError('Main comparison failed')
        if len(runs)==6 and all(r.get('exit_code')==0 for r in runs):break
    except json.JSONDecodeError:pass
    time.sleep(5)
paired=[json.loads((O/f'dense-int8-{m}-{suffix}.json').read_text()) for m,suffix in ((0,'before'),(2,'candidate'))]
ids=sorted({r['id'] for d in paired for r in d['eval'] if r['finish_reason']=='length'})
data=json.loads(gzip.decompress((O/'dense-inputs.json.gz').read_bytes()))
data['evals']=[r for r in data['evals'] if r['id'] in ids]
(O/'dense-extra-inputs.json.gz').write_bytes(gzip.compress(json.dumps(data).encode(),mtime=0))
print('EXTEND_IDS',ids,flush=True)
status=[]
for mode in (0,2):
    name=f'dense-extra-mode{mode}'
    reference=next(r for r in runs if r['name']==f'dense-int8-{mode}-'+('before' if mode==0 else 'candidate'))
    cmd=list(reference['command'])
    for flag,val in [('--inputs',str(O/'dense-extra-inputs.json.gz')),('--output',str(O/f'{name}.json')),('--eval-tokens','2048')]:cmd[cmd.index(flag)+1]=val
    cmd+=['--skip-perf']
    env=dict(os.environ,**reference['environment'])
    env.pop('VLLM_PP_LAYER_PARTITION',None)
    record={'name':name,'ids':ids,'command':cmd,'environment':reference['environment'],'start':time.time()};status.append(record)
    (O/'extra-status.json').write_text(json.dumps(status,indent=2));print('START',name,flush=True)
    with (O/f'{name}.log').open('w') as log:r=subprocess.run(cmd,cwd=R,env=env,stdout=log,stderr=subprocess.STDOUT)
    record.update(exit_code=r.returncode,end=time.time());(O/'extra-status.json').write_text(json.dumps(status,indent=2));print('DONE',name,r.returncode,flush=True)
    if r.returncode:raise SystemExit(r.returncode)
