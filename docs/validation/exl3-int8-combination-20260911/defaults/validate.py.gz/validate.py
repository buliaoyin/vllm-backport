"""Validate production defaults after freezing the independent comparison."""
import json
import os
import subprocess
import time
from pathlib import Path
R=Path('/home/bul/dev/vllm-backport');D=Path('/tmp/exl3-defaults-20260911');P=Path('/tmp/exl3-moe-next-20260911');C=Path('/tmp/exl3-int8-combo-20260911')
assert json.loads((C/'audit.json').read_text())['dense_supplements_complete']
status=[]
def run(name,command,env):
    record={'name':name,'command':command,'environment':{k:v for k,v in env.items() if k.startswith(('CUDA_','EXL3_','VLLM_','NCCL_','OMP_','PYTHONPATH'))},'start':time.time()};status.append(record)
    (D/'validation-status.json').write_text(json.dumps(status,indent=2));print('START',name,flush=True)
    with (D/(name+'.log')).open('w') as log:r=subprocess.run(command,cwd=R,env=env,stdout=log,stderr=subprocess.STDOUT)
    record.update(exit_code=r.returncode,end=time.time());(D/'validation-status.json').write_text(json.dumps(status,indent=2));print('DONE',name,r.returncode,flush=True)
    if r.returncode:raise SystemExit(r.returncode)
env=dict(os.environ,OMP_NUM_THREADS='1',CUDA_DEVICE_ORDER='PCI_BUS_ID',CUDA_VISIBLE_DEVICES='0',EXL3_INT8_GEMV='0',VLLM_EXL3_TEST_DECODE_LIBRARY=str(P/'final-decode/decode.so'),VLLM_EXL3_TEST_PIPELINE_LIBRARY=str(P/'safe-prefill/pipeline.so'),VLLM_EXL3_TEST_ROWS_LIBRARY=str(P/'rows64/rows.so'),VLLM_EXL3_TEST_INT8_LIBRARY='/tmp/exl3-int8-20260911/final-v9/int8.so')
for k in ('VLLM_EXL3_MOE_M_TILE','VLLM_EXL3_MOE_MAX_TOKENS','VLLM_EXL3_EXPERIMENTAL_DECODE','VLLM_EXL3_DECODE_LIBRARY'):env.pop(k,None)
py=str(R/'.venv/bin/python')
run('tests-config',[py,'-m','pytest','tests/engine/test_arg_utils.py','-k','exl3_chunk_default','-q'],dict(env,CUDA_VISIBLE_DEVICES=''))
run('tests-sm80',[py,'-m','pytest','tests/quantization/test_exl3.py','-q'],env)
# The real model checks SM120 fallback as well as default M32 on all SM80 ranks.
model_env={k:v for k,v in env.items() if not k.startswith(('VLLM_EXL3_','EXL3_'))}
model_env.update(CUDA_VISIBLE_DEVICES='0,1,2,3',NCCL_P2P_DISABLE='1',VLLM_PP_LAYER_PARTITION='11,11,11,12',PYTHONPATH=str(R/'benchmarks')+':'+str(R))
run('model-defaults',[py,str(D/'benchmark_defaults.py'),'--backend','vllm','--inputs',str(D/'moe-inputs.json.gz'),'--output',str(D/'model-defaults.json'),'--pp','4','--max-model-len','66560','--kv-cache-gib','8','--batch-size','4','--eval-batch-size','1','--warmups','1','--repeats','2','--tokens','32','--eval-tokens','768','--expected-layer-counts','11','11','11','12'],model_env)
