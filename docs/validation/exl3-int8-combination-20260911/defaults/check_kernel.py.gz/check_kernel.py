import json,re,subprocess
from pathlib import Path
O=Path('/tmp/exl3-defaults-20260911')
paths=['/tmp/exl3-moe-next-20260911/safe-prefill/pipeline.so','/home/bul/dev/vllm-backport/vllm/_exl3_C.abi3.so']
data=[]
for p in paths:
 s=subprocess.check_output(['/usr/local/cuda/bin/cuobjdump','--dump-sass',p],text=True)
 functions={};name=None
 for line in s.splitlines():
  if 'Function :' in line:
   name=line.split('Function :',1)[1].strip();functions[name]=[]
  elif name:
   match=re.match(r'\s*/\*[0-9a-f]+\*/\s+(.*?)\s*/\* 0x[0-9a-f]+ \*/',line)
   if match:functions[name].append(match[1])
 selected={k:v for k,v in functions.items() if 'exl3_moe_nobar_kernel' in k and 'ILi4ELi256ELi2ELi2ELi32ELi32ELb1E' in k}
 assert len(selected)==1,(p,list(selected))
 name,instructions=next(iter(selected.items()));assert instructions
 data.append((name,instructions))
assert data[0][0]==data[1][0]
a,b=data[0][1],data[1][1]
result={'reference_library':paths[0],'native_library':paths[1],'kernel':data[0][0],'reference_instructions':len(a),'native_instructions':len(b),'same_instructions':a==b}
if a!=b:result['first_differences']=[{'index':i,'reference':x,'native':y} for i,(x,y) in enumerate(zip(a,b)) if x!=y][:10]
(O/'native-kernel-equivalence.json').write_text(json.dumps(result,indent=2))
print(result)
