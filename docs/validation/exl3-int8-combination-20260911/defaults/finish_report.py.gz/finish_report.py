import hashlib
import json
import statistics
from pathlib import Path
R=Path('/home/bul/dev/vllm-backport');D=Path('/tmp/exl3-defaults-20260911')
status=json.loads((D/'validation-status.json').read_text())
assert len(status)==3 and all(r.get('exit_code')==0 for r in status)
d=json.loads((D/'model-defaults.json').read_text())
assert d['resolved_chunk_size']==2048 and d['args']['chunk_size'] is None
assert d['environment']['EXL3_INT8_GEMV'] is None
assert d['environment']['VLLM_EXL3_MOE_MAX_TOKENS'] is None
assert len(d['perf'])==4 and len(d['eval'])==64
for stage in ('runtime_before','runtime_after'):
 ranks=sorted(d[stage],key=lambda r:r['pp_rank'])
 assert [len(r['decoder_layers']) for r in ranks]==[11,11,11,12]
 assert all(r['priority'] for r in ranks)
 for i,r in enumerate(ranks):
  assert all(x['capacity']==2048 and x['m_tile']==(32 if i<3 else 16) for x in r['layers'])
assert all(c['matched'] for r in d['perf'] for c in r['checks'])
assert all(r['cached_tokens']==0 for r in d['eval'])
perf={}
for name in sorted({r['case'] for r in d['perf']}):
 rs=[r for r in d['perf'] if r['case']==name]
 perf[name]={'input_tps':statistics.median(sum(x['prompt_tokens'] for x in r['rows'])/r['max_ttft'] for r in rs),'output_tps':statistics.median(sum(x['new_tokens']-1 for x in r['rows'])/max(x['decode'] for x in r['rows']) for r in rs)}
summary={'resolved_chunk':2048,'m_tiles':[32,32,32,16],'workspace_capacities':[2048]*4,'pp':[11,11,11,12],'ordinary_gemv':'upstream default 2; environment unset','expert_decode':'upstream native; experimental worker absent','quality':{'correct':sum(r['correct'] for r in d['eval']),'total':64,'unfinished':sum(r['finish_reason']=='length' for r in d['eval']),'wrong_ids':[r['id'] for r in d['eval'] if not r['correct']]},'retrieval_checks':4,'perf':perf}
(D/'default-summary.json').write_text(json.dumps(summary,indent=2))
paths=['CMakeLists.txt','setup.py','pyproject.toml','vllm/envs.py','vllm/engine/arg_utils.py','vllm/model_executor/layers/quantization/exl3.py','tests/engine/test_arg_utils.py','tests/quantization/test_exl3.py','benchmarks/exl3_profile_worker.py','benchmarks/kernels/exl3_m32/worker.py']+[str(p) for p in Path('csrc/libtorch_stable/quantization/exl3').rglob('*') if p.is_file()]
(D/'validated-source-hashes.json').write_text(json.dumps({p:hashlib.sha256((R/p).read_bytes()).hexdigest() for p in paths},indent=2))
p=R/'docs/validation/exl3-int8-combination-20260911.md';s=p.read_text();old='参数落地及实际默认值验证记录将在本节补充。性能表使用的是显式启用混合专家 decode 的完整实验组合；不能将其直接当作仅设置 M32/2048 后的性能。'
q=summary['quality']
new='''本次将先前要求的 M32 与 2048 落地为运行时默认值。普通 GEMV 保留上游默认 2；混合专家 decode 与 INT8 prefill 仍是显式实验路径。

| 参数 | 默认/建议 | 依据及范围 |
| --- | --- | --- |
| `VLLM_EXL3_MOE_M_TILE` | `32` | SM80、uniform 4-bit mul1、维度为 256 的倍数且在 [256, 8192] 使用已验证的安全 M32 FP32 累加内核；其他情形使用上游。设 `16` 可回退。 |
| `max_num_batched_tokens` | 未指定时 `2048` | EXL3 专用默认；保留用户显式设置和调度模式既有调整。此前同组合相对 1024：8K 输入 TPS −5.9%，16K/32K/64K +2.5%/+8.3%/+11.2%。侧重 8K 延迟可显式选 1024。 |
| `VLLM_EXL3_MOE_MAX_TOKENS` | `2048` | 专家 workspace 上限，同时受调度 token budget 限制。GLM 每卡主 workspace 为 384/384/384/1104 MiB，SM80 M32 另共享约 4 MiB 锁缓冲。 |
| `VLLM_EXL3_MOE_PRIORITY` | `1` | 保留此前验证的专家优先调度。 |
| `EXL3_INT8_GEMV` | 保留上游 `2` | Dense B1 +11.5%，MoE 优化组合 B1 约 +2%；存在量化误差和输出差异，不能承诺无损。严格参考检查设 `0`。本轮没有再次测试模式 1，不能将历史小样本结果当成本组合精度保证。 |
| 混合专家 decode | 显式实验开关 | 本文主性能表依赖该路径；当前正常模型启动仍用上游专家 decode。此次未把实验库及 worker 自动纳入生产默认。 |
| INT8 Tensor Core prefill | 显式实验开关 | 默认 M32 保持 FP16 operands、FP32 累加；此前 INT8 prefill 收益不足以支持替换默认。 |

如果需要排除激活 INT8，除了普通 `EXL3_INT8_GEMV=0`，也须关闭实验性专家 INT8。当前 64 题检查没有支持“无精度损失”的证据，也不足以判断不同模式的总体准确率优劣。

M32 通过独立的 PyTorch stable API 组件 `_exl3_C` 集成，使用显式 Tensor 锁缓冲，不依赖实验 worker 或上游私有 `DevCtx` ABI。标准根 CMake 和独立组件两种构建/安装均通过；打包包含上游 MIT 许可证。新组件与已验证实验版本的 6560 条计算 SASS 指令一致。这是计算代码的一致性证据，host 分派还单独经过以下测试：

- 配置回归 **5 项通过**：EXL3 隐式 2048、显式 1024/4096 保留，其他格式默认不变。
- SM80 **95 项通过**：包括新增 M32 尾部、2048 容量溢出、独立权重重建参考与变化输入/路由的 CUDA Graph 重放；新用例明确拒绝误回退上游。
'''
new+=f"- 实际默认模型启动不传 chunk/workspace/M tile 覆盖，也不设普通 INT8 环境变量。确认 chunk=2048、M tile=[32,32,32,16]、workspace=[2048,2048,2048,2048]、PP=[11,11,11,12]。8K/64K 检索 **4/4**，GSM8K B1 **{q['correct']}/64**，截断 **{q['unfinished']}**，错题 ID {q['wrong_ids']}。\n"
new+='''
实际默认模型的检查值如下（各 2 次测量，无前后控制，仅作为集成检查；与本文主表的混合专家 decode 配置不同）：

| 输入 token | 输入 token/s | 输出 token/s |
| --- | ---: | ---: |
'''
for case,r in sorted(perf.items(),key=lambda x:int(x[0].split('_')[0][1:])):
 new+=f"| {case.split('_')[0][1:]} | {r['input_tps']:.2f} | {r['output_tps']:.2f} |\n"
new+='\n[默认值测试命令](exl3-int8-combination-20260911/defaults/validation-status.json.gz)、[默认值运行结果](exl3-int8-combination-20260911/defaults/default-summary.json.gz)、[计算指令一致性](exl3-int8-combination-20260911/defaults/native-kernel-equivalence.json.gz)。'
assert old in s;s=s.replace(old,new);p.write_text(s)
print(json.dumps(summary,indent=2))
