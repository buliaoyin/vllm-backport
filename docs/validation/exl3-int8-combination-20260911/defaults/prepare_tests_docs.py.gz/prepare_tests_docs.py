from pathlib import Path
R=Path('/home/bul/dev/vllm-backport')
p=R/'tests/quantization/test_exl3.py';s=p.read_text()
s=s.replace('rows, capacity, hidden_dim, monkeypatch, relative_limit=0.01, dtype=torch.float16\n', 'rows, capacity, hidden_dim, monkeypatch, relative_limit=0.01, dtype=torch.float16,\n    m_tile=16,\n')
old='    monkeypatch.setenv("VLLM_EXL3_MOE_MAX_TOKENS", str(capacity))'
assert s.count(old)==1
s=s.replace(old,'''    if capacity is None:
        monkeypatch.delenv("VLLM_EXL3_MOE_MAX_TOKENS", raising=False)
    else:
        monkeypatch.setenv("VLLM_EXL3_MOE_MAX_TOKENS", str(capacity))
    if m_tile is None:
        monkeypatch.delenv("VLLM_EXL3_MOE_M_TILE", raising=False)
    else:
        monkeypatch.setenv("VLLM_EXL3_MOE_M_TILE", str(m_tile))''')
anchor='@pytest.mark.parametrize("rows", [9, 16, 17, 31, 32, 33, 63, 64, 65, 129, 513, 1025])'
assert s.count(anchor)==1
new='''@pytest.mark.parametrize("rows", [9, 33, 513, 2049])
def test_default_m32_routes_tails_and_workspace_overflow(rows, monkeypatch):
    """Default M32 must compute routes and chunk overflow without upstream MoE."""
    if not torch.cuda.is_available() or torch.cuda.get_device_capability() != (8, 0):
        pytest.skip("Default M32 requires SM80")
    pytest.importorskip("vllm._exl3_C")

    def reject_upstream(*args):
        pytest.fail("Supported SM80 experts should use the default M32 kernel")

    monkeypatch.setattr(_extension(), "exl3_moe", reject_upstream)
    _check_moe_routing(rows, None, 256, monkeypatch, m_tile=None)


'''
s=s.replace(anchor,new+anchor);p.write_text(s)
p=R/'tests/engine/test_arg_utils.py';s=p.read_text();s+='''

@pytest.mark.parametrize(
    "quantization,explicit,expected",
    [("exl3", None, 2048), ("exl3", 1024, 1024), ("exl3", 4096, 4096),
     ("awq", None, 8192), (None, None, 8192)],
)
def test_exl3_chunk_default_preserves_explicit_and_other_backends(
    quantization, explicit, expected, monkeypatch
):
    """EXL3 changes the implicit token budget, preserving caller overrides."""
    from types import SimpleNamespace

    from vllm.usage.usage_lib import UsageContext

    args = EngineArgs(max_num_batched_tokens=explicit, enable_chunked_prefill=True)
    monkeypatch.setattr(
        args,
        "get_batch_defaults",
        lambda world_size: ({UsageContext.LLM_CLASS: 8192}, {UsageContext.LLM_CLASS: 16}),
    )
    model = SimpleNamespace(
        quantization=quantization, max_model_len=65536, is_multimodal_model=False
    )
    args._set_default_max_num_seqs_and_batched_tokens_args(
        UsageContext.LLM_CLASS, model, SimpleNamespace(use_batched_dp_moe=False)
    )
    assert args.max_num_batched_tokens == expected
''';p.write_text(s)
p=R/'benchmarks/kernels/exl3_m32/worker.py';s=p.read_text()
if '\nimport os\n' not in s:s=s.replace('\nimport hashlib\n','\nimport hashlib\nimport os\n')
anchor='class Exl3RowsWorkerExtension'
assert anchor in s
# Experimental workers must preserve their explicit upstream controls after promotion.
i=s.index(anchor);s=s[:i]+'# Keep experimental row-kernel controls independent of the production default.\nos.environ["VLLM_EXL3_MOE_M_TILE"] = "16"\n\n\n'+s[i:];p.write_text(s)
p=R/'benchmarks/exl3_profile_worker.py';s=p.read_text()
s=s.replace('{"prefix": method.prefix, "capacity": method.workspace[0].shape[1]}', '{"prefix": method.prefix, "capacity": method.workspace[0].shape[1],\n                 "m_tile": method.moe_m_tile}')
s=s.replace('def candidate(x, weights, ids, ptrs, workspace, bits, flags, limit):', 'def candidate(\n                x, weights, ids, ptrs, workspace, bits, flags, limit, m32_locks=None\n            ):')
p.write_text(s)
p=R/'docs/features/quantization/exl3.md';s=p.read_text()
s=s.replace('workspace capacity, which defaults to the smaller of 1024 tokens and the', 'workspace capacity, which defaults to the smaller of 2048 tokens and the')
s=s.replace('`VLLM_EXL3_MOE_MAX_TOKENS` sets a positive workspace/token-group limit.', '''EXL3 defaults `max_num_batched_tokens` to 2048 when no explicit token budget is
provided. `--max-num-batched-tokens` overrides this scheduler setting. Other
quantization backends retain their existing defaults. The usual throughput-mode,
unchunked-prefill and multimodal budget adjustments still apply.

SM80 uses the bundled M=32, FP32-accumulating expert kernel for uniform 4-bit
mul1 weights with dimensions divisible by 256 in [256, 8192]. Short expert tails
retain the smaller row path. Other formats and GPU architectures use the upstream
kernel. `VLLM_EXL3_MOE_M_TILE=16` explicitly selects the upstream implementation.
The [component build instructions](../../../csrc/libtorch_stable/quantization/exl3/README.md)
allow updating `_exl3_C` without rebuilding unrelated extensions.

`VLLM_EXL3_MOE_MAX_TOKENS` sets a positive workspace/token-group limit.''')
s=s.replace('For hidden size 4096 and intermediate size 2048, a 1024-row workspace uses\n192 MiB on the tested CMP 170HX and 552 MiB on the tested RTX PRO 6000 Blackwell.\nThe corresponding 512-row sizes are 96 MiB and 276 MiB.', 'For hidden size 4096 and intermediate size 2048, the default 2048-row workspace\nuses 384 MiB on the tested CMP 170HX and 1104 MiB on the tested RTX PRO 6000\nBlackwell. M32 additionally shares a roughly 4 MiB lock buffer per device.\nSetting the scheduler token budget to 1024 also caps expert workspace capacity\nat 1024, halving the main workspace.')
p.write_text(s)
print('Tests, experimental controls and docs updated')
