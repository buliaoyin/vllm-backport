from pathlib import Path
R=Path('/home/bul/dev/vllm-backport')
def change(name, before, after):
 p=R/name;s=p.read_text()
 if after in s:return
 assert s.count(before)==1,(name,s.count(before),before[:60])
 p.write_text(s.replace(before,after))
change('CMakeLists.txt','# Define other extension targets\n','# Define other extension targets\n#\nif(VLLM_GPU_LANG STREQUAL "CUDA")\n  include(csrc/libtorch_stable/quantization/exl3/CMakeLists.txt)\nendif()\n')
change('setup.py','if _is_cuda():\n    ext_modules.append(CMakeExtension(name="vllm.vllm_flash_attn._vllm_fa2_C"))','if _is_cuda():\n    ext_modules.append(CMakeExtension(name="vllm._exl3_C"))\n    ext_modules.append(CMakeExtension(name="vllm.vllm_flash_attn._vllm_fa2_C"))')
change('setup.py','"vllm/_C_stable_libtorch.abi3.so",','"vllm/_C_stable_libtorch.abi3.so",\n                            "vllm/_exl3_C.abi3.so",')
change('vllm/envs.py','    VLLM_EXL3_MOE_MAX_TOKENS: int = 1024','    VLLM_EXL3_MOE_MAX_TOKENS: int = 2048\n    VLLM_EXL3_MOE_M_TILE: int = 32')
change('vllm/envs.py','os.getenv("VLLM_EXL3_MOE_MAX_TOKENS", "1024")','os.getenv("VLLM_EXL3_MOE_MAX_TOKENS", "2048")')
change('vllm/envs.py','    # Schedule larger EXL3 experts first to reduce the final wave of work.','    # SM80 row reuse for supported experts; 16 selects the upstream kernel.\n    "VLLM_EXL3_MOE_M_TILE": lambda: int(os.getenv("VLLM_EXL3_MOE_M_TILE", "32")),\n    # Schedule larger EXL3 experts first to reduce the final wave of work.')
change('vllm/engine/arg_utils.py','        if self.max_num_batched_tokens is None:\n            if parallel_config.use_batched_dp_moe:','        if self.max_num_batched_tokens is None:\n            if model_config.quantization == "exl3":\n                self.max_num_batched_tokens = 2048\n            elif parallel_config.use_batched_dp_moe:')
name='vllm/model_executor/layers/quantization/exl3.py'
change(name,'from vllm.config import get_current_vllm_config_or_none','from vllm.config import get_current_vllm_config_or_none\nfrom vllm.logger import init_logger\nfrom vllm.platforms import current_platform')
change(name,'_DTYPES = {','logger = init_logger(__name__)\n_M32_LOCK_INTS = 1024 * 1024 + 2 * 1024 + 2 + 64\n\n_DTYPES = {')
change(name,'@dataclass(frozen=True)\nclass Exl3Tensor:', '''@lru_cache(maxsize=1)
def _m32_extension():
    try:
        return importlib.import_module("vllm._exl3_C")
    except ImportError as exc:
        raise ImportError(
            "EXL3 M32 requires vllm._exl3_C. Build the EXL3 component as "
            "described in docs/features/quantization/exl3.md, or set "
            "VLLM_EXL3_MOE_M_TILE=16 to use the upstream kernel."
        ) from exc


@dataclass(frozen=True)
class Exl3Tensor:''')
change(name,'        self.workspaces: dict[tuple, list[torch.Tensor]] = {}','        self.workspaces: dict[tuple, list[torch.Tensor]] = {}\n        self.m32_locks: dict[torch.device, torch.Tensor] = {}')
change(name,'        self.prefix = prefix.removesuffix(".routed_experts")','        self.prefix = prefix.removesuffix(".routed_experts")\n        self.m32_locks = None\n        self.moe_m_tile = 16')
change(name,'        self.workspace = self.config.workspaces[key]','''        self.workspace = self.config.workspaces[key]
        m_tile = envs.VLLM_EXL3_MOE_M_TILE
        if m_tile not in (16, 32):
            raise ValueError("VLLM_EXL3_MOE_M_TILE must be 16 or 32")
        if (
            m_tile == 32
            and current_platform.get_device_capability(device.index) == (8, 0)
            and tuple(self.bits) == (4, 4, 4)
            and tuple(self.flags) == (False, True) * 3
            and all(
                256 <= width <= 8192 and width % 256 == 0
                for width in (self.hidden_size, self.intermediate_size)
            )
        ):
            _m32_extension()
            if device not in self.config.m32_locks:
                self.config.m32_locks[device] = torch.zeros(
                    _M32_LOCK_INTS, dtype=torch.int32, device=device
                )
            self.m32_locks = self.config.m32_locks[device]
            self.moe_m_tile = 32
            logger.info_once("Using EXL3 M=32 FP32 MoE prefill on SM80.")''')
change(name,'            float(self.moe.swiglu_limit or 0.0),\n        )','            float(self.moe.swiglu_limit or 0.0),\n            self.m32_locks,\n        )')
# Both custom-op entry points receive the optional, explicitly tracked lock buffer.
p=R/name;s=p.read_text()
for function in ('_exl3_moe_fused','_exl3_moe'):
 start=s.index('def '+function+'(');end=s.index(') -> torch.Tensor:',start)
 signature=s[start:end];assert signature.count('    limit: float,')==1
 s=s[:start]+signature.replace('    limit: float,','    limit: float,\n    m32_locks: torch.Tensor | None = None,')+s[end:]
start=s.index('        ext.exl3_moe(\n',s.index('def _exl3_moe_fused('))
end=s.index('        output[start :',start)
original=s[start:end]
s=s[:start]+'''        if m32_locks is not None:
            torch.ops._exl3_C.moe_m32(
                hidden, result, counts, tokens, weights[order],
                *workspace, *chunk_ptrs, m32_locks, limit,
            )
        else:
'''+''.join('    '+line if line.strip() else line for line in original.splitlines(keepends=True))+s[end:]
old='''    return implementation(
        x, topk_weights, topk_ids, ptrs, workspace, bits, flags, limit
    )'''
new='''    args = (x, topk_weights, topk_ids, ptrs, workspace, bits, flags, limit)
    if implementation is _exl3_moe_fused and m32_locks is not None:
        return implementation(*args, m32_locks)
    return implementation(*args)'''
assert s.count(old)==1;s=s.replace(old,new)
s=s.replace('def _exl3_moe_fake(x, topk_weights, topk_ids, ptrs, workspace, bits, flags, limit):','def _exl3_moe_fake(\n    x, topk_weights, topk_ids, ptrs, workspace, bits, flags, limit, m32_locks=None\n):')
s=s.replace('"exl3_moe", _exl3_moe, mutates_args=["workspace"], fake_impl=_exl3_moe_fake','"exl3_moe", _exl3_moe, mutates_args=["workspace", "m32_locks"], fake_impl=_exl3_moe_fake')
p.write_text(s)
print('Default M32/2048 changes applied')
