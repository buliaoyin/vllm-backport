"""Check that all six results used the intended data, paths and fixed placement."""
import gzip
import hashlib
import json
from pathlib import Path

R = Path('/home/bul/dev/vllm-backport')
O = Path('/tmp/exl3-int8-combo-20260911')
status = json.loads((O / 'status.json').read_text())
assert len(status) == 6 and all(x.get('exit_code') == 0 for x in status)
hashes = json.loads((O / 'measured-source-hashes.json').read_text())
assert all(hashlib.sha256((R / p).read_bytes()).hexdigest() == h for p, h in hashes.items())
results = {}
for run in status:
    name = run['name']
    model = name.split('-')[0]
    mode = int(name.split('-')[2])
    after = name.endswith('-after')
    data = json.loads(gzip.decompress((O / f'{model}-inputs.json.gz').read_bytes()))
    result = json.loads((O / f'{name}.json').read_text())
    repeats = 3 if after else 5
    assert result['environment']['EXL3_INT8_GEMV'] == str(mode)
    assert result['inputs_sha256'] == hashlib.sha256((O / f'{model}-inputs.json.gz').read_bytes()).hexdigest()
    assert result['benchmark_source_sha256'] == hashlib.sha256((O / 'benchmark_model.py').read_bytes()).hexdigest()
    assert result['args']['chunk_size'] == 2048
    assert result['args']['eval_batch_size'] == 1
    assert len(result['perf']) == len(data['cases']) * repeats
    cases = {x['name']: x for x in data['cases']}
    for record in result['perf']:
        case = cases[record['case']]
        assert len(record['rows']) == len(case['inputs'])
        for row, ids in zip(record['rows'], case['inputs']):
            assert row['prompt_tokens'] == len(ids)
            assert row['new_tokens'] == case.get('new_tokens', result['args']['tokens'])
            assert row['cached_tokens'] == 0
        assert all(c['matched'] for c in record.get('checks', []))
    assert len(result['eval']) == (0 if after else 64)
    assert all(row['cached_tokens'] == 0 for row in result['eval'])
    if model == 'moe':
        assert all(row['finish_reason'] != 'length' for row in result['eval'])
    runtime = sorted(result['runtime_after'], key=lambda x: x['pp_rank'])
    if model == 'moe':
        expected = [list(range(a, b)) for a, b in [(0, 11), (11, 22), (22, 33), (33, 45)]]
        assert [[x['index'] for x in r['decoder_layers']] for r in runtime] == expected
        assert [r['expert_decode']['activation_mode'] for r in runtime] == ['plain', 'plain', 'plain', 'residual']
        assert all(r['expert_decode']['sha256'] == 'b3992ca9b63a1b348e7e1ac02c49fc659788c790f4ba5bd27e0b8bc2e2be1514' for r in runtime)
        sweep = result['workspace_sweep'][0]
        assert all(r['row_kernel']['sha256'] == '92281e957561e5240976ad2518477ef30167c2dd8c645d40f07b9fc2a465ac68' for r in sweep[:3])
        assert sweep[3]['row_kernel'] == 'native'
        assert all(layer['capacity'] == 2048 for r in runtime for layer in r['layers'])
        assert all(r['priority'] for r in runtime)
    results[name] = {
        'passed': True, 'performance_samples': len(result['perf']),
        'quality_samples': len(result['eval']),
        'truncated_quality_samples': sum(r['finish_reason']=='length' for r in result['eval']),
        'retrieval_checks': sum(len(r.get('checks', [])) for r in result['perf']),
        'gpu_names': result['gpu_names'],
    }
extras=json.loads((O/'extra-status.json').read_text())
assert len(extras)==2 and all(r.get('exit_code')==0 for r in extras)
assert extras[0]['ids']==extras[1]['ids']
for run in extras:
    d=json.loads((O/(run['name']+'.json')).read_text())
    assert d['args']['skip_perf'] and d['args']['eval_tokens']==2048 and d['args']['eval_batch_size']==1
    assert sorted(r['id'] for r in d['eval'])==run['ids']
    assert all(r['cached_tokens']==0 for r in d['eval'])
(O / 'audit.json').write_text(json.dumps({'source_frozen': True, 'runs': results, 'dense_supplement_ids':extras[0]['ids'], 'dense_supplements_complete':True}, indent=2))
print(json.dumps(results, indent=2))
