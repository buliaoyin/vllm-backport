"""Produce the report from final measurements; validation results appended later."""
import json
from pathlib import Path
O = Path('/tmp/exl3-int8-combo-20260911')
R = Path('/home/bul/dev/vllm-backport')
s = json.loads((O/'summary.json').read_text())
audit = json.loads((O/'audit.json').read_text())
assert len(audit['runs']) == 6
lines = ['# EXL3 优化组合与普通 INT8 GEMV 对照（2026-09-11）', '',
'本轮只改变普通线性层的 `EXL3_INT8_GEMV=0/2`。MoE 两组均启用安全 M32 prefill、chunk/workspace 2048、优先调度和混合专家 decode（SM80 普通 INT8、SM120 激活残差补偿）。因此 `0` 组仍含专家 INT8，结果衡量的是普通 GEMV 在既有优化上的额外收益。', '',
'## 测试条件', '',
'- Dense：指定 Qwen3.8-27B EXL3，物理 GPU3 RTX PRO 6000 Blackwell；MoE：指定 GLM-5.3-Flash EXL3，GPU0–2 CMP 170HX，GPU3 Blackwell。完整 checkpoint 路径在原始 JSON。',
'- MoE 固定 `11/11/11/12`，实际层索引为 0–10、11–21、22–32、33–44；逐进程断言通过。SM120 prefill 保持上游实现。',
'- Torch 2.13.0+cu130、CUDA 13.0、ExLlamaV3 1.4.8。每组独立启动并捕获 CUDA Graph；测试期间运行时代码固定，库哈希和实际专家模式已审计。',
'- 顺序为每个模型 `0 前测 → 2 → 0 后测`；前两组每项 1 次预热、5 次重复，后测 1 次预热、3 次重复。基线为前后 8 个样本合并中位数，候选为 5 个样本中位数。',
'- MoE KV 每 rank 8 GiB、最大长度 66560；dense KV 2 GiB、最大长度 4096。max_num_seqs=4，greedy，prefix caching 关闭，所有缓存命中为 0。',
'- B1 decode TPS = `(输出 token 数−1)/(最后 token 时间−首 token 时间)`。输入 TPS = `输入 token 数/TTFT`，包含调度与首 token 开销。长输入生成 32 token，256/2048 B1 生成 256 token；B4 每请求 128 token。',
'- 精度使用相同 64 道 GSM8K，逐请求 **B1**，初始最多 768 输出 token。dense 对任一模式触及上限的题目取并集，以同样 B1 设置在 0/2 两组统一提高到 2048 token 补测。与此前 B4 64 题得分不直接比较。原始输出、token ID 和错题均保留。',
'- GPU 测试串行；CUDA 编译不与性能计时重叠。核函数追踪沿用此前已验证的普通 GEMV 路径，本轮不向计时进程注入追踪。', '',
'## 单请求输入与输出吞吐', '',
'单位 token/s；输入值按 TTFT 计算。', '',
'| 模型 | 输入 token | 输入 0 | 输入 2 | 输出 0 | 输出 2 | 输出增益 |',
'| --- | ---: | ---: | ---: | ---: | ---: | ---: |']
for model in ('dense','moe'):
 for case,v in sorted(s['comparisons'][model]['perf'].items(),key=lambda z:int(z[0].split('_')[0][1:])):
  if not case.endswith('_b1'): continue
  inp=v['metrics']['input_tps']
  lines.append(f"| {model} | {case.split('_')[0][1:]} | {inp['baseline_median']:.2f} | {inp['candidate_median']:.2f} | {v['baseline_output_tps']:.2f} | {v['candidate_output_tps']:.2f} | {v['output_gain_pct']:+.2f}% |")
lines += ['', '## B4 与运行漂移', '',
'B4 的请求 decode 区间包含 PP 调度和其他请求的 prefill；不能称为固定 M=4 的纯稳态 decode。这里列完整 generate 的输出吞吐（包含 prefill），并保留样本范围。', '',
'| 模型 | 输入/请求 | 0 中位数 [范围] | 2 中位数 [范围] |',
'| --- | ---: | ---: | ---: |']
for model in ('dense','moe'):
 for case,v in sorted(s['comparisons'][model]['perf'].items(),key=lambda z:int(z[0].split('_')[0][1:])):
  if not case.endswith('_b4'):continue
  m=v['metrics']['end_to_end_output_tps']
  lines.append(f"| {model} | {case.split('_')[0][1:]} | {m['baseline_median']:.2f} [{m['baseline_min']:.2f}, {m['baseline_max']:.2f}] | {m['candidate_median']:.2f} [{m['candidate_min']:.2f}, {m['candidate_max']:.2f}] |")
lines += ['', 'MoE 2048-token B4 的前后控制组存在明显调度波动，不能根据中位数宣称稳定收益。单请求则对前、后两个控制组均有提升。完整前后统计和原始样本见机器可读汇总。', '',
'## 精度', '', '先列固定 768-token 预算的原始结果；dense 截断题不能当作已完成答案评价。', '', '| 模型 | 0 正确题数 | 2 正确题数 | 2 新错题 ID | 2 修正题 ID | 最终答案相同 | token 序列完全相同 |', '| --- | ---: | ---: | --- | --- | ---: | ---: |']
for model in ('dense','moe'):
 a=s['runs'][f'{model}-int8-0-before']['quality'];b=s['runs'][f'{model}-int8-2-candidate']['quality'];q=s['comparisons'][model]['quality']
 assert a['total']==b['total']==64
 lines.append(f"| {model} | {a['correct']}/64 | {b['correct']}/64 | {q['new_errors']} | {q['fixed_errors']} | {q['same_answers']}/64 | {q['same_tokens']}/64 |")
q=s['dense_extended_quality']; a,b=q['runs']; pair=q['paired']
lines += ['', f"Dense 延长输出补测覆盖两组共同的题目并集 {a['rerun_ids']}，0/2 仍触及上限的题数分别为 {a['unfinished']}/{b['unfinished']}。替换这些题目的结果后，0 为 **{a['correct']}/64**，2 为 **{b['correct']}/64**；新错题 {pair['new_errors']}，修正题 {pair['fixed_errors']}，最终答案相同 {pair['same_answers']}/64，完整 token 序列相同 {pair['same_tokens']}/64。原始 768-token 得分与延长预算结果均保留，不能混用。重启后生成路径也可能发生变化；这组补测不能消除运行非确定性或将全部答案差异归因于 INT8。", '']
checks=sum(r['retrieval_checks'] for r in audit['runs'].values())
lines += ['',f'MoE 8K–64K 固定访问码检索检查 **{checks}/{checks}**。仅验证本次指定访问码，不代表完整长上下文能力评测。', '',
'这些结果没有显示模型输出崩坏，但量化会改变输出路径，并存在新增错题。64 题小样本不能证明精度无损、总体精度提升或不存在其他回归。没有运行完整 GSM8K、困惑度或其他学科评测。', '',
'## 综合默认参数', '',
'参数落地及实际默认值验证记录将在本节补充。性能表使用的是显式启用混合专家 decode 的完整实验组合；不能将其直接当作仅设置 M32/2048 后的性能。', '',
'## 原始证据', '',
'- [机器可读汇总](exl3-int8-combination-20260911/summary.json.gz)、[运行条件审计](exl3-int8-combination-20260911/audit.json.gz)。',
'- [完整命令与环境](exl3-int8-combination-20260911/status.json.gz)、[测试脚本](exl3-int8-combination-20260911/benchmark_model.py.gz)。',
'- [证据清单与哈希](exl3-int8-combination-20260911/manifest.json)。',
'- [此前 M32、专家 decode 与 chunk 的消融](exl3-moe-20260911.md)、[此前普通 GEMV 0/1/2 与 INT8 prefill 对照](exl3-int8-20260911.md)。', '',
'本轮没有重跑原版 ExLlamaV3、AWQ 或 NVFP4，不能将当前增量结果替代此前同分层格式对照。', '']
(R/'docs/validation/exl3-int8-combination-20260911.md').write_text('\n'.join(lines))
