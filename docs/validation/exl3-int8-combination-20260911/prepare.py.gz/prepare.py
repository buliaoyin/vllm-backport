import gzip, json, hashlib
from pathlib import Path
from tokenizers import Tokenizer
O=Path('/tmp/exl3-int8-combo-20260911'); P=Path('/tmp/exl3-moe-next-20260911')
source=P/'benchmark_model.py'
s=source.read_text()
s=s.replace('    parser.add_argument("--batch-size", type=int, default=4)', '    parser.add_argument("--batch-size", type=int, default=4)\n    parser.add_argument("--eval-batch-size", type=int, default=1)')
s=s.replace('range(0, len(data["evals"]), args.batch_size)', 'range(0, len(data["evals"]), args.eval_batch_size)')
s=s.replace('data["evals"][offset : offset + args.batch_size]', 'data["evals"][offset : offset + args.eval_batch_size]')
s=s.replace('    for eval_variant in [v for v in variants if v.get("eval", True)]:', '    print("PERFORMANCE_COMPLETE", flush=True)\n    for eval_variant in [v for v in variants if v.get("eval", True)]:')
(O/'benchmark_model.py').write_text(s)
moe=json.loads(gzip.decompress((P/'model-inputs.json.gz').read_bytes()))
for c in moe['cases']:
 n=int(c['name'].split('_')[0][1:]);c['new_tokens']=32 if n>=8192 else 256 if len(c['inputs'])==1 else 128
(O/'moe-inputs.json.gz').write_bytes(gzip.compress(json.dumps(moe,ensure_ascii=False).encode(),mtime=0))
(O/'moe-variants.json').write_bytes((P/'hybrid-c2048-variants.json').read_bytes())
dense=json.loads(Path('/tmp/exl3-int8-20260911/dense-decode-inputs.json').read_text())
tokenizer=Tokenizer.from_file(str(Path(dense['model'])/'tokenizer.json'))
first=dense['evals'][0]
text=tokenizer.decode(first['input_ids'],skip_special_tokens=False)
assert text.count(first['question'])==1
before,after=text.split(first['question'])
evals=[]
for r in moe['evals']:
 ids=tokenizer.encode(before+r['question']+after,add_special_tokens=False).ids
 evals.append({k:r[k] for k in ('id','question','answer')}|{'input_ids':ids})
assert all(evals[i]['input_ids']==r['input_ids'] for i,r in enumerate(dense['evals']))
dense['evals']=evals
for c in dense['cases']:c['new_tokens']=256 if len(c['inputs'])==1 else 128
(O/'dense-inputs.json.gz').write_bytes(gzip.compress(json.dumps(dense,ensure_ascii=False).encode(),mtime=0))
(O/'dense-variants.json').write_text(json.dumps([{'name':'default_linear','capacity':2048,'priority':True,'eval':True}],indent=2))
print('Prepared MoE',len(moe['cases']),'cases and dense',len(dense['cases']),'cases; 64 matching questions; previous dense 16 inputs preserved')
