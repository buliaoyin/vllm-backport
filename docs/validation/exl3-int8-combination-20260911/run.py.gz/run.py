import json, os, subprocess, time
from pathlib import Path
R=Path('/home/bul/dev/vllm-backport');O=Path('/tmp/exl3-int8-combo-20260911');P=Path('/tmp/exl3-moe-next-20260911')
status=[]
for model,mode,suffix in [('moe',0,'before'),('moe',2,'candidate'),('moe',0,'after'),('dense',0,'before'),('dense',2,'candidate'),('dense',0,'after')]:
 while (O/'build.lock').exists():time.sleep(1)
 name=f'{model}-int8-{mode}-{suffix}'
 cmd=[str(R/'.venv/bin/python'),str(O/'benchmark_model.py'),'--backend','vllm','--inputs',str(O/f'{model}-inputs.json.gz'),'--output',str(O/f'{name}.json'),'--pp','4' if model=='moe' else '1','--chunk-size','2048','--max-model-len','66560' if model=='moe' else '4096','--kv-cache-gib','8' if model=='moe' else '2','--batch-size','4','--eval-batch-size','1','--warmups','1','--repeats','5' if suffix!='after' else '3','--tokens','32','--eval-tokens','768','--moe-variants',str(O/f'{model}-variants.json')]
 if model=='moe':cmd += ['--expected-layer-counts','11','11','11','12','--worker-extension-cls','kernels.exl3_moe_decode.worker.Exl3DecodeWorkerExtension']
 if suffix=='after':cmd += ['--skip-eval']
 env=dict(os.environ,CUDA_DEVICE_ORDER='PCI_BUS_ID',CUDA_VISIBLE_DEVICES='0,1,2,3' if model=='moe' else '3',NCCL_P2P_DISABLE='1',OMP_NUM_THREADS='1',EXL3_INT8_GEMV=str(mode),VLLM_DETERMINISTIC_MOE_ALIGN='0',VLLM_EXL3_MOE_MAX_TOKENS='2048',VLLM_EXL3_MOE_PRIORITY='1',VLLM_EXL3_EXPERIMENTAL_DECODE='hybrid' if model=='moe' else 'native',VLLM_EXL3_DECODE_LIBRARY=str(P/'final-decode/decode.so'),PYTHONPATH=str(R/'benchmarks')+':'+str(R))
 if model=='moe':env['VLLM_PP_LAYER_PARTITION']='11,11,11,12'
 else:env.pop('VLLM_PP_LAYER_PARTITION',None)
 record={'name':name,'command':cmd,'environment':{k:v for k,v in env.items() if k.startswith(('CUDA_','NCCL_','VLLM_','EXL3_','OMP_','PYTHONPATH'))},'start':time.time()};status.append(record);(O/'status.json').write_text(json.dumps(status,indent=2));print('START',name,flush=True)
 with (O/f'{name}.log').open('w') as log:r=subprocess.run(cmd,cwd=R,env=env,stdout=log,stderr=subprocess.STDOUT)
 record.update(exit_code=r.returncode,end=time.time());(O/'status.json').write_text(json.dumps(status,indent=2));print('DONE',name,r.returncode,flush=True)
 if r.returncode:raise SystemExit(r.returncode)
