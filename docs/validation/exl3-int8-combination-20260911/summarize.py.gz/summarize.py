import collections, json, statistics
from pathlib import Path
O=Path('/tmp/exl3-int8-combo-20260911')
result={'runs':{},'comparisons':{}}
for p in O.glob('*-int8-*.json'):
 d=json.loads(p.read_text());groups=collections.defaultdict(list)
 for r in d['perf']:groups[r['case']].append(r)
 perf={}
 for case,rs in groups.items():
  values={
   'input_tps':[sum(v['prompt_tokens'] for v in r['rows'])/r['max_ttft'] for r in rs],
   'output_tps':[sum(v['new_tokens']-1 for v in r['rows'])/max(v['decode'] for v in r['rows']) for r in rs],
   'end_to_end_output_tps':[r['throughput'] for r in rs],
   'ttft':[r['max_ttft'] for r in rs]}
  perf[case]={'repeats':len(rs), **{k:{'median':statistics.median(v),'min':min(v),'max':max(v),'samples':v} for k,v in values.items()},'cached_tokens':sum(v['cached_tokens'] for r in rs for v in r['rows']),'checks_passed':sum(c['matched'] for r in rs for c in r.get('checks',[])),'checks_total':sum(len(r.get('checks',[])) for r in rs),'output_tokens':[v['new_tokens'] for v in rs[0]['rows']]}
 ev=d['eval']
 result['runs'][p.stem]={'perf':perf,'quality':{'total':len(ev),'correct':sum(r['correct'] for r in ev),'unfinished':sum(r['finish_reason']=='length' for r in ev),'wrong_ids':[r['id'] for r in ev if not r['correct']]},'args':d['args']}
for model in ('moe','dense'):
 before=O/f'{model}-int8-0-before.json';cand=O/f'{model}-int8-2-candidate.json'
 if not (before.exists() and cand.exists()):continue
 a,b=(json.loads(p.read_text()) for p in (before,cand));reference={r['id']:r for r in a['eval']}
 ev=[r for r in b['eval'] if r['id'] in reference]
 pairs={'quality':{'compared':len(ev),'same_answers':sum(r['predicted']==reference[r['id']]['predicted'] for r in ev),'same_tokens':sum(r['token_ids']==reference[r['id']]['token_ids'] for r in ev),'new_errors':[r['id'] for r in ev if not r['correct'] and reference[r['id']]['correct']],'fixed_errors':[r['id'] for r in ev if r['correct'] and not reference[r['id']]['correct']]},'perf':{}}
 runs=result['runs'];aa=runs[before.stem]['perf'];bb=runs[cand.stem]['perf'];cc=runs.get(f'{model}-int8-0-after',{}).get('perf',{})
 for case,x in bb.items():
  if case not in aa:continue
  ys=aa[case]['output_tps']['samples']+cc.get(case,{}).get('output_tps',{}).get('samples',[])
  combined={k:aa[case][k]['samples']+cc.get(case,{}).get(k,{}).get('samples',[]) for k in ('input_tps','output_tps','end_to_end_output_tps','ttft')}
  base=statistics.median(ys);z=x['output_tps']['median'];pairs['perf'][case]={'baseline_output_tps':base,'candidate_output_tps':z,'output_gain_pct':100*(z/base-1),'before_output_tps':aa[case]['output_tps']['median'],'after_output_tps':cc.get(case,{}).get('output_tps',{}).get('median'), 'metrics':{k:{'baseline_median':statistics.median(v),'baseline_min':min(v),'baseline_max':max(v),'baseline_samples':v,'candidate_median':x[k]['median'],'candidate_min':x[k]['min'],'candidate_max':x[k]['max'],'candidate_samples':x[k]['samples'],'gain_pct':100*(x[k]['median']/statistics.median(v)-1)} for k,v in combined.items()}}

 result['comparisons'][model]=pairs
extra=[O/f'dense-extra-mode{mode}.json' for mode in (0,2)]
if all(p.exists() for p in extra):
 merged=[];details=[]
 for mode,suffix,path in ((0,'before',extra[0]),(2,'candidate',extra[1])):
  original=json.loads((O/f'dense-int8-{mode}-{suffix}.json').read_text())
  rerun=json.loads(path.read_text())
  replacements={r['id']:r for r in rerun['eval']}
  rows=[replacements.get(r['id'],r) for r in original['eval']]
  merged.append({r['id']:r for r in rows})
  details.append({'mode':mode,'total':len(rows),'correct':sum(r['correct'] for r in rows),'unfinished':sum(r['finish_reason']=='length' for r in rows),'wrong_ids':[r['id'] for r in rows if not r['correct']],'rerun_ids':list(replacements),'rerun_cap':rerun['args']['eval_tokens']})
 a,b=merged
 result['dense_extended_quality']={'runs':details,'paired':{'new_errors':[i for i in a if a[i]['correct'] and not b[i]['correct']],'fixed_errors':[i for i in a if not a[i]['correct'] and b[i]['correct']],'same_answers':sum(a[i]['predicted']==b[i]['predicted'] for i in a),'same_tokens':sum(a[i]['token_ids']==b[i]['token_ids'] for i in a)}}
(O/'summary.json').write_text(json.dumps(result,ensure_ascii=False,indent=2))
for name,d in result['runs'].items():
 print(name,d['quality'])
 for case,r in d['perf'].items():print(' ',case,r['repeats'],round(r['input_tps']['median'],2),round(r['output_tps']['median'],2))
for model,d in result['comparisons'].items():print(model,'QUALITY COMPARISON',d['quality'])
