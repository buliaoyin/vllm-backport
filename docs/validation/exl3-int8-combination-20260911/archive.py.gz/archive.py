import gzip
import hashlib
import json
from pathlib import Path
O=Path('/tmp/exl3-int8-combo-20260911')
D=Path('/tmp/exl3-defaults-20260911')
R=Path('/home/bul/dev/vllm-backport')
A=R/'docs/validation/exl3-int8-combination-20260911'
A.mkdir(parents=True,exist_ok=True)
manifest=[]
def add(source,relative):
    payload=source.read_bytes()
    target=A/relative
    target.parent.mkdir(parents=True,exist_ok=True)
    if not relative.endswith('.gz'):
        target=target.with_name(target.name+'.gz')
        target.write_bytes(gzip.compress(payload,mtime=0))
    else:
        target.write_bytes(payload)
    manifest.append({'file':str(target.relative_to(A)), 'source':str(source), 'source_sha256':hashlib.sha256(payload).hexdigest(), 'sha256':hashlib.sha256(target.read_bytes()).hexdigest()})
for p in O.iterdir():
    if p.is_file() and p.suffix in ('.py','.json','.gz','.log'):
        if p.name=='summary-progress.log':continue
        add(p,p.name)
for p in (O/'sources').glob('*.gz'):add(p,'measured-sources/'+p.name)
for p in D.iterdir():
    if p.is_file() and p.suffix in ('.json','.log','.py','.gz'):
        add(p,'defaults/'+p.name)
(A/'manifest.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2)+'\n')
for row in manifest:
    assert hashlib.sha256((A/row['file']).read_bytes()).hexdigest()==row['sha256']
print('Archived',len(manifest),'files,',sum((A/x['file']).stat().st_size for x in manifest),'bytes')
