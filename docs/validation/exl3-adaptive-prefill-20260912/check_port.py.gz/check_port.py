import importlib.util,json
from pathlib import Path
import torch,pytest
from benchmarks.kernels.exl3_prefill_int8.backend import Backend
from vllm.model_executor.layers.quantization import exl3
from vllm.model_executor.layers.quantization.utils import exl3_prefill
root=Path('/home/bul/dev/vllm-backport');out=Path('/tmp/exl3-adaptive-20260912')
spec=importlib.util.spec_from_file_location('exl3tests',root/'tests/quantization/test_exl3.py');suite=importlib.util.module_from_spec(spec);spec.loader.exec_module(suite)
prototype=Backend('/tmp/exl3-target4700-20260911/kernels-batched-int8-r1/helpers.so')
original=exl3.Exl3MoEMethod.apply
stats=[]
def compare(method,layer,x,weights,ids,*args,**kwargs):
 actual=original(method,layer,x,weights,ids,*args,**kwargs)
 expected=prototype(x,weights,ids,method.ptrs,method.workspace,method.bits,method.flags,float(method.moe.swiglu_limit or 0),method.m32_locks)
 torch.accelerator.synchronize()
 delta=(actual.float()-expected.float());rel=(delta.norm()/expected.float().norm()).item()
 stats.append({'rows':x.shape[0],'hidden':x.shape[1],'exact_fraction':(actual==expected).float().mean().item(),'relative_l2':rel,'max_abs':delta.abs().max().item()});assert rel<1e-5,stats[-1]
 return actual
with pytest.MonkeyPatch.context() as m:
 m.setenv('VLLM_EXL3_MOE_PREFILL','int8');m.setenv('VLLM_EXL3_MOE_INT8_MIN_TOKENS','9');m.setattr(exl3.Exl3MoEMethod,'apply',compare)
 for rows in (97,400,4096,6144):
  suite._check_moe_routing(rows,2048,768,m,intermediate_dim=512,dtype=torch.bfloat16,m_tile=32,relative_limit=.02)
(out/'port-equivalence.json').write_text(json.dumps(stats,indent=2));print(json.dumps(stats),flush=True)
