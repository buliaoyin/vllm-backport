import argparse,os,subprocess,sys,json,time
from pathlib import Path
p=argparse.ArgumentParser();p.add_argument('name');p.add_argument('mode');p.add_argument('chunk',type=int);p.add_argument('--inputs',default='inputs.json.gz');p.add_argument('--repeats',type=int,default=2);p.add_argument('--warmups',type=int,default=1);p.add_argument('--profile',action='store_true');p.add_argument('--eval',action='store_true');p.add_argument('--with-eval',action='store_true');p.add_argument('--min-rows',type=int,default=4096);a=p.parse_args()
root=Path('/home/bul/dev/vllm-backport');out=Path('/tmp/exl3-adaptive-20260912')
env={k:v for k,v in os.environ.items() if not k.startswith(('EXL3_','VLLM_EXL3_'))}
env.update(CUDA_DEVICE_ORDER='PCI_BUS_ID',CUDA_VISIBLE_DEVICES='0,1,2',OMP_NUM_THREADS='1',NCCL_P2P_DISABLE='1',VLLM_PP_LAYER_PARTITION='16,15,14',VLLM_EXL3_MOE_MAX_TOKENS='2048',VLLM_EXL3_MOE_PREFILL=a.mode,VLLM_EXL3_MOE_INT8_MIN_TOKENS=str(a.min_rows),PYTHONPATH=str(root/'benchmarks')+':'+str(root),VLLM_TRITON_USE_TD='0',EXL3_INT8_GEMV='2',PYTORCH_ALLOC_CONF='expandable_segments:True')
cmd=[sys.executable,'benchmarks/benchmark_exl3.py','--backend','vllm','--inputs',str(out/a.inputs),'--output',str(out/(a.name+'.json')),'--pp','3','--expected-layer-counts','16','15','14','--max-model-len','66560','--kv-cache-gib','2','--batch-size','4','--warmups',str(a.warmups),'--repeats',str(a.repeats),'--tokens','32','--skip-eval']
if a.eval or a.with_eval:
 cmd.remove('--skip-eval');cmd+=['--eval-batch-size','4','--eval-tokens','768']
 if a.eval:cmd+=['--skip-perf']
if a.profile:cmd+=['--event-profile','--profile-tokens','1']
if a.chunk:cmd+=['--chunk-size',str(a.chunk)]
meta={'command':cmd,'env':{k:v for k,v in env.items() if k.startswith(('CUDA_','EXL3_','VLLM_','NCCL_','OMP_','PYTORCH_'))},'start':time.time()}
(out/(a.name+'-status.json')).write_text(json.dumps(meta,indent=2))
with (out/(a.name+'.log')).open('w') as f:
 result=subprocess.run(cmd,cwd=root,env=env,stdout=f,stderr=subprocess.STDOUT,timeout=2400)
meta.update(exit_code=result.returncode,end=time.time());(out/(a.name+'-status.json')).write_text(json.dumps(meta,indent=2))
print(a.name,result.returncode,flush=True)
sys.exit(result.returncode)
