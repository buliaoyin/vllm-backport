import gzip,json
from pathlib import Path
p=Path('/tmp/exl3-adaptive-20260912')
d=json.load(gzip.open(p/'all-inputs.json.gz','rt'))
bylen={len(c['inputs'][0]):c for c in d['cases'] if len(c['inputs'])==4}
cases=[]
for lengths in [[8192],[16384],[20480],[24576],[32768],[65536],[8192]*2,[8192]*4,[16384]*2,[16384]*4,[32768]*2,[2048,32768],[8192,32768],[8192,8192,8192,32768]]:
 c={'name':'_'.join(str(n//1024)+'k' for n in lengths),'inputs':[],'expected_strings':[]}
 for i,n in enumerate(lengths):
  for k in ['inputs','expected_strings']:
   c[k].append(bylen[n][k][i])
 cases.append(c)
d['cases']=cases
(p/'inputs.json.gz').write_bytes(gzip.compress(json.dumps(d).encode(),mtime=0))
print([(c['name'],[len(x) for x in c['inputs']]) for c in cases])
