import argparse,os,subprocess,sys,json,time
from pathlib import Path
p=argparse.ArgumentParser();p.add_argument('name');p.add_argument('kind',choices=['mixed','dense']);p.add_argument('mode');p.add_argument('--chunk',type=int,default=0);p.add_argument('--native-capacity',type=int,default=2048);p.add_argument('--profile',action='store_true');p.add_argument('--inputs');a=p.parse_args()
root=Path('/home/bul/dev/vllm-backport');out=Path('/tmp/exl3-adaptive-20260912')
env={k:v for k,v in os.environ.items() if not k.startswith(('EXL3_','VLLM_EXL3_','VLLM_PP_LAYER_PARTITION'))}
env.update(CUDA_DEVICE_ORDER='PCI_BUS_ID',CUDA_VISIBLE_DEVICES='0,1,2,3' if a.kind=='mixed' else '3',OMP_NUM_THREADS='1',NCCL_P2P_DISABLE='1',VLLM_EXL3_MOE_MAX_TOKENS=str(a.native_capacity),VLLM_EXL3_MOE_PREFILL=a.mode,PYTHONPATH=str(root/'benchmarks')+':'+str(root),VLLM_TRITON_USE_TD='0',EXL3_INT8_GEMV='2',PYTORCH_ALLOC_CONF='expandable_segments:True')
cmd=[sys.executable,'benchmarks/benchmark_exl3.py','--backend','vllm','--inputs',str(out/(a.inputs or a.kind+'-inputs.json.gz')),'--output',str(out/(a.name+'.json')),'--pp','4' if a.kind=='mixed' else '1','--max-model-len','66560' if a.kind=='mixed' else '33792','--kv-cache-gib','2' if a.kind=='mixed' else '4','--batch-size','4','--warmups','1','--repeats','3','--tokens','32','--skip-eval']
if a.kind=='mixed':
 env['VLLM_PP_LAYER_PARTITION']='11,11,11,12';cmd+=['--expected-layer-counts','11','11','11','12']
else:cmd+=['--worker-extension-cls','exl3_profile_worker.Exl3ProfileWorkerExtension']
if a.profile:cmd+=['--event-profile','--profile-tokens','1']
if a.chunk:cmd+=['--chunk-size',str(a.chunk)]
meta={'command':cmd,'env':{k:v for k,v in env.items() if k.startswith(('CUDA_','EXL3_','VLLM_','NCCL_','OMP_','PYTORCH_'))},'start':time.time()}
(out/(a.name+'-status.json')).write_text(json.dumps(meta,indent=2))
with (out/(a.name+'.log')).open('w') as f:r=subprocess.run(cmd,cwd=root,env=env,stdout=f,stderr=subprocess.STDOUT,timeout=2400)
meta.update(exit_code=r.returncode,end=time.time());(out/(a.name+'-status.json')).write_text(json.dumps(meta,indent=2));print(a.name,r.returncode,flush=True);sys.exit(r.returncode)
