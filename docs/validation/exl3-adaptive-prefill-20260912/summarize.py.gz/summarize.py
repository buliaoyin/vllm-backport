import json,statistics as st
from pathlib import Path
p=Path('/tmp/exl3-adaptive-20260912')
names=['native2048','int8-6144','auto-remaining','auto-final','native-confirm','int8-accuracy','mixed-auto','mixed-native','dense-native','dense-auto','auto32-confirm','mixed-auto32-confirm']
summary={}
for name in names:
 f=p/(name+'.json')
 if not f.exists():continue
 d=json.loads(f.read_text()); cases={}
 for r in d['perf']:cases.setdefault(r['case'],[]).append(r)
 out={'resolved_chunk_size':d.get('resolved_chunk_size'),'cases':{},'accuracy':{'correct':sum(x['correct'] for x in d['eval']),'total':len(d['eval']),'truncated':sum(x['finish_reason']=='length' for x in d['eval'])}}
 for case,rs in cases.items():
  first=rs[0]; n=len(first['rows']); entry={'samples':len(rs),'prompt_lengths':[x['prompt_tokens'] for x in first['rows']],'checks_passed':all(c['matched'] for r in rs for c in r.get('checks',[])),'checks_total':sum(len(r.get('checks',[])) for r in rs),'ttft_s':[st.median(r['rows'][j]['ttft'] for r in rs) for j in range(n)],'decode_s':[st.median(r['rows'][j]['decode'] for r in rs) for j in range(n)],'e2e_s':st.median(r['seconds'] for r in rs)}
  if 'arrival_offset' in first['rows'][0]:
   entry['max_output_gaps_s']=[st.median(max(b[1]-a[1] for a,b in zip(r['rows'][j]['token_arrivals'],r['rows'][j]['token_arrivals'][1:])) for r in rs) for j in range(n)]
  else:
   samples=[sum(row['prompt_tokens'] for row in r['rows'])/r['max_ttft'] for r in rs];entry['input_tps']=st.median(samples);entry['input_tps_range']=[min(samples),max(samples)]
  if n==1:entry['decode_tps']=st.median((r['rows'][0]['new_tokens']-1)/r['rows'][0]['decode'] for r in rs)
  out['cases'][case]=entry
 if 'runtime_after' in d:
  out['ranks']=[{k:r[k] for k in ['gpu','pp_rank','workspace_bytes','int8_prefill_workspace_bytes','cuda_allocated_bytes','cuda_peak_allocated_bytes'] if k in r} | {'layers':len(r['decoder_layers'])} for r in d['runtime_after']]
 if 'event_profile' in d:
  out['profile']=[{k:{'calls':len(v),'total_ms':sum(v)} for k,v in r['timings_ms'].items() if k.startswith('moe')} for r in d['event_profile']['ranks']]
 summary[name]=out
(p/'summary.json').write_text(json.dumps(summary,indent=2))
for name,d in summary.items():
 print(name,'chunk',d['resolved_chunk_size'],'accuracy',d['accuracy'])
 for case,c in d['cases'].items():
  print(case,round(c.get('input_tps',0),1), 'ttft',','.join(f'{x:.3f}' for x in c['ttft_s']),'gaps',c.get('max_output_gaps_s',''),'checks',c['checks_passed'])
