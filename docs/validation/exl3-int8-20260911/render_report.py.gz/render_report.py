import json,statistics
from pathlib import Path
R=Path('/home/bul/dev/vllm-backport');O=Path('/tmp/exl3-int8-20260911');S=json.loads((O/'summary.json').read_text())
assert len(S['decode'])==12
text=(O/'report_static.md').read_text()
assert len(S['prefill'])==4 and all(q['samples']==64 for q in S['prefill_quality'])
quality_a,quality_b=S['prefill_quality']
intro=(f"本轮实现并测试了 9 版 INT8 Tensor Core 专家 prefill，最终真实路由的 1024-token 完整专家计算快约 **2.6%–2.8%**。"
       f"固定分层下，64K TTFT 从 M32 FP16 的 **18.42 / 18.61 秒**（前/后测）降至 **18.13 秒**，8K 基本持平；"
       f"GSM8K 本次样本为 FP16 **{quality_a['correct']}/64**、INT8 **{quality_b['correct']}/64**。"
       "收益较小，保留为显式选择的实验内核。现成 decode 开关则让集成版 dense B1 吞吐提高约 **11.1%**，MoE 约 **1.6%**。"
       "所有 MoE 整模型比较固定 `11/11/11/12`。")
old=text.split('\n\n')[1]
text=text.replace(old,intro,1)

text+='\n## Decode 整模型结果\n\n三次重复的中位数，单位 token/s；质量列依次为模式 0/1/2 的正确题数。\n\n| 模型 / 后端 | INT8=0 | INT8=1 | INT8=2 | 模式 2 相对 0 | GSM8K /16 |\n|---|---:|---:|---:|---:|---|\n'
for kind in ['dense','moe']:
 for backend in ['vllm','exllamav3']:
  r=[next(v for v in S['decode'] if v['model']==kind and v['backend']==backend and v['mode']==mode) for mode in [0,1,2]]
  values=[v['b1_decode_tps'] for v in r]
  text+=f"| {kind} / {backend} | {values[0]:.2f} | {values[1]:.2f} | {values[2]:.2f} | {(values[2]/values[0]-1)*100:+.1f}% | {' / '.join(str(v['correct']) for v in r)} |\n"
text+='\nB4 完整 generate 吞吐（含 prefill），单位 token/s：\n\n| 模型 / 后端 | INT8=0 | INT8=1 | INT8=2 |\n|---|---:|---:|---:|\n'
for kind in ['dense','moe']:
 for backend in ['vllm','exllamav3']:
  r=[next(v for v in S['decode'] if v['model']==kind and v['backend']==backend and v['mode']==mode) for mode in [0,1,2]]
  text+=f"| {kind} / {backend} | "+' | '.join(f"{v['b4_generate_tps']:.2f}" for v in r)+' |\n'
text+='\nDense 和原版 MoE 的 B4 吞吐没有提升。集成版 MoE B4 模式 2 的中位数较高，但三个样本为 42.43/43.66/36.83，而模式 0 为 36.48/42.35/36.47 token/s，波动区间明显重叠。PP 调度中有效 M 会随请求推进变化；没有调度时间线，不能将这个中位数差异直接归因于 INT8 或宣称稳定增益。小 M 路径也不覆盖固定 M=4 的稳态 GEMM。16 题中的得分变化和逐 token 差异已保存在 summary 与原始 JSON；不能据此宣布量化无损或总体精度提升。\n'
text+='\n## 原型消融与真实路由\n\nLayer22、1024-token wrapper，单位 ms。各轮都有 FP16 前后控制；跨轮数字仅用于说明迭代，最终比较使用同轮数据。\n\n| 原型 | INT8 ms | 说明 |\n|---|---:|---|\n'
labels={1:'初版，片段数组进入局部内存',2:'静态寄存器双缓冲',3:'每个专家一次激活量化、ldmatrix',4:'共享内存码本表，回退',5:'字节顺序错误，数值检查拒绝',6:'修正后的直接 IMMA 布局与饱和打包',7:'移除冗余屏障',8:'向量化行量化与原生 warp max',9:'四 warp 协同量化，改善冷专家并行度'}
for item in S['experiments']:
 speed=f"{item['median_ms']:.3f}" if 'median_ms' in item else '不计时'
 text+=f"| v{item['version']} | {speed} | {labels[item['version']]} |\n"
text+='\n最终库复测，完整专家 wrapper，单位 ms：\n\n| 路由层 / GPU | 输入行数 | M32 FP16 前测 | INT8 | 码本残差 INT8 | M32 FP16 后测 | INT8 相对 L2 |\n|---|---:|---:|---:|---:|---:|---:|\n'
for name in ['final-layer22-gpu0','final-layer3-gpu1']:
 d=json.loads((O/f'{name}.json').read_text())
 for rows in [512,1024,2048]:
  r=[v for v in d['records'] if v['rows']==rows]
  assert len(r)==4 and r[0]['relative_l2']<0.001 and r[3]['relative_l2']<0.001
  text+=f"| {name} | {rows} | {r[0]['median_ms']:.3f} | {r[1]['median_ms']:.3f} | {r[2]['median_ms']:.3f} | {r[3]['median_ms']:.3f} | {r[1]['relative_l2']:.3%} |\n"
text+='\n## 8K–64K 请求级 prefill\n\n下表为 TTFT 中位数（秒）；是整请求指标，不是各 GPU 算子区间之和。吞吐为输入 token / TTFT，包含调度及首 token 的开销。\n\n| 输入 token | M32 FP16 前测 | INT8 SM80 | M32 FP16 后测 | INT8 TTFT 相对前测 | INT8 输入 token/s |\n|---|---:|---:|---:|---:|---:|\n'
assert len(S['prefill'])==4
for row in S['prefill']:
 a,b,c=(row[k]['ttft'] for k in ['m32_before','int8_sm80','m32_after'])
 text+=f"| {row['case']} | {a:.4f} | {b:.4f} | {c:.4f} | {(b/a-1)*100:+.1f}% | {row['int8_sm80']['prefill_tps']:.1f} |\n"
checks=sum(row[k]['checks'] for row in S['prefill'] for k in ['m32_before','int8_sm80','m32_after'])
text+=f'\n长输入检索检查：{checks}/36，只验证指定访问码，不代表完整长上下文能力评测。FP16 后测较前测慢约 1%–3%，说明时间漂移和状态差异已接近短输入的收益；8K 未显示可信的提升，64K 对两端基线均仅有小幅改善。\n'
text+='\nPrefill 质量比较（同引擎、decode 固定关闭 INT8）：\n\n| Prefill | GSM8K /64 | 错题 ID |\n|---|---:|---|\n'
for row in S['prefill_quality']:
 assert row['samples']==64
 text+=f"| {row['variant']} | {row['correct']}/64 | {row['wrong']} |\n"
q=S['prefill_quality'][1]
text+=f"\n两种 prefill 的最终答案相同 {q['answers_equal_fp16']}/64，逐 token 完全相同 {q['tokens_equal_fp16']}/64。这个 64 题样本只能反映本次检查，不能证明量化无损或推断总体精度。\n"
text+='\n此前 NVFP4/AWQ 的固定分层历史 64K TTFT 为 12.1481 / 11.7093 秒；本轮未重跑这两种格式。其专家路径为 Marlin W4A16，且 AWQ 最后一个 MoE 层未量化，不能把差异当作纯内核、等精度比较。[历史固定分层记录](exl3-fixed-pp-comparison-20260910.md)\n'
text+='\n## 验证与复现\n\n- `tests/quantization/test_exl3.py` 在 SM80 上 79 项通过，含 18 项可选 INT8 边界/图重放测试及新增残差、M=2 线性层用例。\n- 修改文件的 pre-commit 检查通过。测试使用的 kernel/build 源码哈希与库构建记录一致。\n- [构建、基准与模型 worker 用法](../../benchmarks/kernels/exl3_int8/README.md)。\n- [汇总与逐层断言脚本](exl3-int8-20260911/summarize.py.gz)、[机器可读汇总](exl3-int8-20260911/summary.json.gz)、[环境版本/二进制哈希](exl3-int8-20260911/frameworks.json.gz)、[原始证据清单](exl3-int8-20260911/manifest.json)。\n- 上游 checkout 与安装扩展未修改。此次代码保留为可选实验，生产默认未切换到 INT8 prefill。基础提交为 `d24da36fc`，本轮未另行提交。\n'
text="\n".join("| "+" | ".join(part.strip() for part in line.split("|")[1:-1])+" |" if line.startswith("|---") else line for line in text.split("\n"))
(R/'docs/validation/exl3-int8-20260911.md').write_text(text)
