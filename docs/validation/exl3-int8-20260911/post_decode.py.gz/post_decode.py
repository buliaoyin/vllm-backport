import os,json,time,subprocess,shutil
from pathlib import Path
R=Path('/home/bul/dev/vllm-backport');O=Path('/tmp/exl3-int8-20260911');P=str(R/'.venv/bin/python')
while True:
 try:
  items=json.loads((O/'validation-status.json').read_text());d=next((r for r in items if r['name']=='decode-models'),{})
 except (json.JSONDecodeError,FileNotFoundError):d={}
 if 'exit_code' in d:
  if d['exit_code']:raise SystemExit(d['exit_code'])
  break
 time.sleep(2)
status=[]
def run(name,cmd,env):
 item={'name':name,'start':time.time(),'command':cmd};status.append(item);(O/'post-decode-status.json').write_text(json.dumps(status,indent=2));print('START',name,flush=True)
 with (O/f'{name}.log').open('w') as log:r=subprocess.run(cmd,cwd=R,env=dict(os.environ,**env),stdout=log,stderr=subprocess.STDOUT)
 item.update(exit_code=r.returncode,end=time.time());(O/'post-decode-status.json').write_text(json.dumps(status,indent=2));print('DONE',name,r.returncode,flush=True)
 if r.returncode:raise SystemExit(r.returncode)
run('trace-upstream',['/home/bul/miniconda3/bin/conda','run','--no-capture-output','-n','exllamav3','python',str(O/'trace_upstream.py')],{'CUDA_DEVICE_ORDER':'PCI_BUS_ID','CUDA_VISIBLE_DEVICES':'3','OMP_NUM_THREADS':'1','LD_PRELOAD':str(O/'trace_launch.so')})
shutil.copyfile(O/'gemm_int8_v8.cuh',O/'gemm_int8.cuh')
run('build-v8',[P,str(O/'build.py'),'build-v8'],{})
run('int8-v8-layer22',[P,str(O/'bench_int8.py'),'--checkpoint','/home/bul/dev/models1/zai/turboderp/GLM-5.3-Flash-exl3/4.05bpw','--prefix','model.language_model.layers.22.mlp.experts','--route-sample','/tmp/exl3-opt-20260910/routes/layer-22.pt','--prefill-rows','512','1024','2048','--output',str(O/'int8-v8-layer22.json')],{'CUDA_DEVICE_ORDER':'PCI_BUS_ID','CUDA_VISIBLE_DEVICES':'0','OMP_NUM_THREADS':'1','EXL3_INT8_GEMV':'0','VLLM_EXL3_MOE_MAX_TOKENS':'1024','INT8_BUILD':'build-v8'})
