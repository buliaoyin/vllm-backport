import os,subprocess,json,time
from pathlib import Path
R=Path('/home/bul/dev/vllm-backport');O=Path('/tmp/exl3-int8-20260911');P=str(R/'.venv/bin/python')
common=dict(os.environ,CUDA_DEVICE_ORDER='PCI_BUS_ID',CUDA_VISIBLE_DEVICES='0',EXL3_INT8_GEMV='0',OMP_NUM_THREADS='1',VLLM_EXL3_MOE_MAX_TOKENS='1024',PYTHONPATH=str(R))
status=[]
def run(name,cmd,overrides={}):
 record={'name':name,'command':cmd,'environment':overrides,'start':time.time()};status.append(record);(O/'final-validation-status.json').write_text(json.dumps(status,indent=2));print('START',name,flush=True)
 with (O/f'{name}.log').open('w') as log:r=subprocess.run(cmd,cwd=R,env=dict(common,**overrides),stdout=log,stderr=subprocess.STDOUT)
 record.update(exit_code=r.returncode,end=time.time());(O/'final-validation-status.json').write_text(json.dumps(status,indent=2));print('DONE',name,r.returncode,flush=True)
 if r.returncode:raise SystemExit(r.returncode)
run('tests-sm80',[P,'-m','pytest','tests/quantization/test_exl3.py','-q'],{'VLLM_EXL3_TEST_INT8_LIBRARY':str(O/'final-v9/int8.so'),'VLLM_EXL3_TEST_ROWS_LIBRARY':str(O/'final-v9/fp16/rows.so')})
for layer,gpu in [(22,'0'),(3,'1')]:
 name=f'final-layer{layer}-gpu{gpu}'
 run(name,[P,'benchmarks/kernels/benchmark_exl3_moe.py','--checkpoint','/home/bul/dev/models1/zai/turboderp/GLM-5.3-Flash-exl3/4.05bpw','--prefix',f'model.language_model.layers.{layer}.mlp.experts','--route-sample',f'/tmp/exl3-opt-20260910/routes/layer-{layer}.pt','--prefill-rows','512','1024','2048','--prefill-chunks','1024','--row-kernel-library',str(O/'final-v9/int8.so'),'--row-kernel-variants','m32_predicated','int8','int8_residual','m32_predicated','--row-kernel-max-relative-error','0.02','--output',str(O/f'{name}.json')],{'CUDA_VISIBLE_DEVICES':gpu})
run('prefill-model',[P,str(O/'run_prefill_model.py')])
