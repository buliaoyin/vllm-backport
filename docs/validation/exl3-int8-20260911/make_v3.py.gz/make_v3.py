from pathlib import Path
p=Path('/tmp/exl3-int8-20260911');s=(p/'gemm_int8_v2.cuh').read_text()
a=s.index('__device__ __forceinline__ uint32_t load_a_i8');b=s.index('template<bool RESIDUAL>',a)
s=s[:a]+'''__device__ __forceinline__ void quantize_rows(half* A,int M,int K,int start,int stride) {
    int lane=threadIdx.x&31;
    for(int row=start;row<M;row+=stride) {
        half* input=A+row*K;
        float amax=0,sum=0;
        for(int k=lane;k<K;k+=32) {float v=__half2float(input[k]);amax=fmaxf(amax,fabsf(v));sum+=v;}
        #pragma unroll
        for(int x=16;x;x>>=1) {amax=fmaxf(amax,__shfl_xor_sync(0xffffffff,amax,x));sum+=__shfl_xor_sync(0xffffffff,sum,x);}
        float scale=fmaxf(amax/127.f,1e-20f),inv=1.f/scale;
        int8_t* output=(int8_t*)input;
        for(int k=lane;k<K;k+=32) {
            int v=__float2int_rn(__half2float(input[k])*inv);
            __syncwarp();output[k]=v;__syncwarp();
        }
        if(!lane) {float* tail=(float*)(input+K-4);tail[0]=scale;tail[1]=sum;}
    }
}
'''+s[b:]
a=s.index('    half* sha=shared;');b=s.index('    for(int nt=',a)
s=s[:a]+'''    uint8_t* sha=(uint8_t*)shared;
    uint16_t* shb=(uint16_t*)(sha+3*1024);
    int tid=threadIdx.x,warp=tid/32,lane=tid&31;
    float scale[4],sum[4];
    #pragma unroll
    for(int m=0;m<4;++m){int row=lane/4+8*m;scale[m]=1.f;sum[m]=0.f;if(row<M){const float* tail=(const float*)(A+(row+1)*K-4);scale[m]=tail[0];sum[m]=tail[1];}}
'''+s[b:]
s=s.replace('if(tid<128) {\n                    int row=tid/4,col=tid%4,sw=col^((row>>1)&3);','if(tid<64) {\n                    int row=tid/2,col=tid%2,sw=col^((row>>2)&1);').replace('row*4+sw','row*2+sw').replace('(const int4*)(A+row*K+k*32)+col','(const int4*)((const uint8_t*)A+row*K*2+k*32)+col')
a=s.index('            const half* ap=');b=s.index('            #pragma unroll\n            for(int kb=',a)
s=s[:a]+'''            const uint8_t* ap=sha+(k%3)*1024;
            #pragma unroll
            for(int m=0;m<2;++m) {
                if(m==1 && M<=16) continue;
                int row=(lane%8)+8*((lane/8)%2)+m*16,col=lane/16;
                FragA v;ldsm4(v,(const int4*)ap+row*2+(col^((row>>2)&1)));
                #pragma unroll
                for(int j=0;j<4;++j)fa[buf][m].v[j]=((uint32_t*)&v)[j];
            }
'''+s[b:]
(p/'gemm_int8.cuh').write_text(s)
pb=p/'build.py';b=pb.read_text();pos=b.index("assert s.count('exl3_gemm_int8_inner')")
b=b[:pos]+'''if 'quantize_rows' in (root/'gemm_int8.cuh').read_text():
 s=s.replace('        had_gather_gu_in();','        had_gather_gu_in();\\n        if(gated) quantize_rows(temp_state_g,token_count,hidden_dim,warp_idx0,warps_per_group);\\n        quantize_rows(temp_state_u,token_count,hidden_dim,warp_idx0,warps_per_group);\\n        group_barrier(group_idx,group_size,barrier_counters_sense);')
 s=s.replace('        had_guad();','        had_guad();\\n        quantize_rows(temp_intermediate_g,token_count,intermediate_dim,warp_idx0,warps_per_group);\\n        group_barrier(group_idx,group_size,barrier_counters_sense);')
'''+b[pos:];pb.write_text(b)
