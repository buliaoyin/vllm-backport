# EXL3 INT8 decode 与 SM80 prefill 验证（2026-09-11）

本轮实际实现并测试了 INT8 Tensor Core 专家 prefill。现成 INT8 decode 开关有整模型收益；prefill 原型的结论见下方实测，不能从 A100 的理论算力倍数推出请求加速倍数。所有 MoE 整模型比较固定 `11/11/11/12`，没有使用此前的 `10/7/7/21` 分配。

## 对原说法的核实

原说法基本合理，但需要补充 **MoE decode 也没有整体切换到 INT8**：

- 原版 `EXL3_INT8_GEMV` 默认 `2`，`0` 禁用，`1` 为激活残差补偿，`2` 为普通激活 INT8。集成版未重设默认值，继承上游配置；此前显式设置 `0` 的成绩不代表默认运行状态。
- 此路径仅接入普通 `exl3_gemm` 的 mul1 码本：模式 1 主要为 M=1，模式 2 为 M=1/2；N 需整除 256，K 需整除 128。默认可接受的权重位宽上限是 Ampere 5-bit、Blackwell/Hopper 6-bit。不满足条件时回退。
- 当前 MoE decode 使用多专家 `exl3_mgemm`，没有调用该 INT8 分支；fused MoE prefill 也不使用该开关。普通 attention/shared-expert 线性层仍可受益。
- 启动追踪实际观察到 `exl3_gemv_int8_sq_kernel`，MoE 三模式均为 `exl3_mgemm_kernel`；M=32 普通线性层均回退到 FP16 GEMM。独立 MoE 算子检查中，三模式的 B1/B4 输出逐位一致；这不代表整模型输出一致。FP16 码本解码本身也含 DP4A，不能仅凭出现 DP4A 判断整个 GEMM 使用 INT8。
- 上游注释中“尚不支持 CUDA graph”已经过时；当前实现支持 graph 参数记录，微基准也实际捕获、重放了 INT8。整模型每种开关独立启动，避免沿用其他模式的图。

源码：[INT8 默认值与范围](https://github.com/turboderp-org/exllamav3/blob/6ff3a17ea7f3d0026b273d43239398d57f71b788/exllamav3/exllamav3_ext/quant/exl3_gemv_int8.cu)、[普通与多专家分发](https://github.com/turboderp-org/exllamav3/blob/6ff3a17ea7f3d0026b273d43239398d57f71b788/exllamav3/exllamav3_ext/quant/exl3_gemm.cu)。

A100 标称稠密 FP16 Tensor Core 312 TFLOPS、INT8 624 TOPS；两者都不使用稀疏性加倍后的数值。这支持探索 IMMA，但这里的实际 SM80 硬件是 CMP 170HX，且算子包括解码、量化、内存和同步成本。[NVIDIA A100 规格](https://www.nvidia.com/en-us/data-center/a100/)

## 条件与统计口径

- dense：用户指定 Qwen3.8-27B EXL3，物理 GPU3 RTX PRO 6000 Blackwell。MoE：用户指定 GLM-5.3-Flash EXL3，GPU0–2 CMP 170HX，GPU3 Blackwell；实际层索引必须是 0–10、11–21、22–32、33–44。
- vLLM：Torch 2.13.0+cu130、CUDA 13.0、ExLlamaV3 1.4.8。原版在 `conda run -n exllamav3` 下运行，Torch 2.8.0+cu128、CUDA 12.8、ExLlamaV3 1.4.8+cu128.torch2.8.0。保留既有环境；跨后端绝对差异包含框架/编译版本因素。两个扩展的 SHA256 已归档。
- decode：同一份 2048-token 输入，B1/B4，固定生成 128 token，greedy，1 次预热、3 次重复、chunk 1024、零 prefix-cache 命中。B1 decode TPS 为 `127 / (last_token_time - first_token_time)`；B4 报完整 generate 吞吐，包含 prefill，不能当作纯 decode TPS。
- decode 质量：相同前 16 道 GSM8K，**逐请求 B1**，最多 768 输出 token；这样能够覆盖 INT8 小 M 路径。是小样本检查，不是总体精度结论。
- prefill：M32 FP16 前测 → INT8 SM80 → M32 FP16 后测，同一引擎；B1，8K/16K/32K/64K，chunk 1024，每 rank KV 8 GiB，max length 66560，固定输出 32 token，1 次预热、3 次重复。Blackwell 专家保持原实现。性能全部结束后，再进行同引擎 64 题 GSM8K B4 质量比较，decode 固定 `EXL3_INT8_GEMV=0`。
- 核内计时：完整专家 wrapper 的 GPU 工作，包括激活量化、路由、Hadamard、激活与 scatter；每次重放一个 CUDA graph，15 次采样，事件外先写 256 MiB 缓冲驱逐 L2。GPU 测试与 CUDA 编译串行。CUPTI 内核事件在 CMP 上不可用，算子名用独立的 CUDA 启动追踪确认；追踪未进入模型测速进程。

## INT8 prefill 实现与尝试

最终内核使用 `mma.sync.aligned.m16n8k32.row.col.s32.s8.s8.s32`，M32 共享解码结果、FP32 epilogue。每个 warp 处理完整 K32，避免原来的 block 内 K 子组归约；激活在 Hadamard 后按行 absmax 量化，复用现有 workspace。代码和复现命令见 [实验入口](../../benchmarks/kernels/exl3_int8/README.md)。它不会自动进入生产调度。

mul1 码本的整数部分是 `D = byte_sum(index * 0x83DCD12D) - 510`，需要超过 8 个有符号位。普通 INT8 使用 `floor((D+2)/4)` 并饱和打包，码本步长约 0.027069；加入码本偏移对应的行和修正。残差版用第二次 IMMA 处理 `D-4q`。这里的残差是 **权重码本残差**，不同于原版开关 1 的 **激活残差**；它仍然保留激活 INT8 误差及上游 FP16 码本舍入差异。

每个版本先检查数值再计时。首版的片段数组动态索引造成局部内存读写；改为静态双缓冲后消除。随后尝试把重复激活量化移出 GEMM、共享内存码本表、直接解码至 IMMA 字节布局、饱和打包、移除冗余屏障、向量化行量化，以及四 warp 协同量化。直接布局的一次字节顺序错误被数值检查拦截，其时间不进入性能结论。共享码本表与双 IMMA 残差均未带来收益。

最终 SASS 已确认 IMMA；FP16 控制为 HMMA。SASS 静态指令数量和源码消融能证明路径、识别额外工作，不能定量证明 Tensor Core、整数 ALU、访存、同步各占多少时间。此前“约 94% 在 GEMM”同样包含这些内部开销。
