import os,sys,json
sys.path.insert(0,'/home/bul/dev/vllm-backport')
import torch
from benchmarks.kernels import benchmark_exl3_moe as bench
@torch.inference_mode()
def run(layer,method,args,k,n):
 torch.manual_seed(9);records=[]
 for rows in [1,4]:
  x=torch.randn(rows,k,device='cuda',dtype=torch.bfloat16);ids=torch.rand(rows,args.experts,device='cuda').topk(8,dim=-1).indices;w=torch.rand(rows,8,device='cuda').softmax(-1)
  ref=None
  for mode in [0,1,2]:
   os.environ['EXL3_INT8_GEMV']=str(mode);print('TRACE_MOE',rows,mode,flush=True)
   y=bench._exl3_moe_decode(x,w,ids,method.ptrs,method.workspace,method.bits,method.flags,10.);torch.accelerator.synchronize()
   if ref is None:ref=y
   records.append({'rows':rows,'mode':mode,'equal':bool(torch.equal(y,ref))})
 args.output.write_text(json.dumps(records,indent=2))
bench.prefill_ablation=run
if __name__=='__main__':bench.main()
