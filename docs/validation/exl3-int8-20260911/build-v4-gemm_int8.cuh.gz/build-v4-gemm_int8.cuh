#pragma once
#include "upstream/ptx.cuh"
#include "upstream/quant/exl3_dq.cuh"
#include "codebook_int8.cuh"

struct I8A { uint32_t v[4]; };
struct I8B { uint32_t v[2]; };
struct I8C { int v[4]; };
__device__ __forceinline__ void imma(const I8A& a, const I8B& b, I8C& c) {
    asm volatile("mma.sync.aligned.m16n8k32.row.col.s32.s8.s8.s32 "
        "{%0,%1,%2,%3}, {%4,%5,%6,%7}, {%8,%9}, {%0,%1,%2,%3};"
        : "+r"(c.v[0]), "+r"(c.v[1]), "+r"(c.v[2]), "+r"(c.v[3])
        : "r"(a.v[0]), "r"(a.v[1]), "r"(a.v[2]), "r"(a.v[3]), "r"(b.v[0]), "r"(b.v[1]));
}
__device__ __forceinline__ uint32_t pack4(int a,int b,int c,int d) {
    return __byte_perm(__byte_perm(a,b,0x4440),__byte_perm(c,d,0x4440),0x5410);
}
__device__ __forceinline__ uint32_t rearrange_b(uint32_t q,int lane) {
    int src=(lane&~3)+2*(lane&1);
    uint32_t lo=__shfl_sync(0xffffffff,q,src);
    uint32_t hi=__shfl_sync(0xffffffff,q,src+1);
    int shift=(lane&2)*8;
    return ((lo>>shift)&0xffff) | ((hi>>shift)<<16);
}
template<bool RESIDUAL>
__device__ __forceinline__ void decode_i8(const uint32_t* ptr, int lane, uint32_t (&b)[2],uint32_t (&r)[2]) {
    uint32_t a=ptr[(lane+31)&31], d=ptr[lane], s;
    FSHF_IMM(s,d,a,20);
    uint32_t w[8];
    w[7]=d&0xffff;
    BFE16_IMM(w[6],d,4); BFE16_IMM(w[5],d,8); BFE16_IMM(w[4],d,12); BFE16_IMM(w[3],d,16);
    w[2]=s&0xffff; BFE16_IMM(w[1],s,4); BFE16_IMM(w[0],s,8);
    int q[8], rr[8];
    #pragma unroll
    for(int i=0;i<8;++i) {
        if constexpr(RESIDUAL) {
            int v=(int)__dp4a(w[i]*0x83DCD12Du,0x01010101u,0u)-510;
            q[i]=min(127,(v+2)>>2);rr[i]=v-4*q[i];
        } else {
            extern __shared__ half shared[];
            q[i]=((const int8_t*)shared+24576)[w[i]];
        }
    }
    #pragma unroll
    for(int n=0;n<2;++n) {
        b[n]=rearrange_b(pack4(q[4*n],q[4*n+1],q[4*n+2],q[4*n+3]),lane);
        if constexpr(RESIDUAL) r[n]=rearrange_b(pack4(rr[4*n],rr[4*n+1],rr[4*n+2],rr[4*n+3]),lane);
    }
}
__device__ __forceinline__ void quantize_rows(half* A,int M,int K,int start,int stride) {
    int lane=threadIdx.x&31;
    for(int row=start;row<M;row+=stride) {
        half* input=A+row*K;
        float amax=0,sum=0;
        for(int k=lane;k<K;k+=32) {float v=__half2float(input[k]);amax=fmaxf(amax,fabsf(v));sum+=v;}
        #pragma unroll
        for(int x=16;x;x>>=1) {amax=fmaxf(amax,__shfl_xor_sync(0xffffffff,amax,x));sum+=__shfl_xor_sync(0xffffffff,sum,x);}
        float scale=fmaxf(amax/127.f,1e-20f),inv=1.f/scale;
        int8_t* output=(int8_t*)input;
        for(int k=lane;k<K;k+=32) {
            int v=__float2int_rn(__half2float(input[k])*inv);
            __syncwarp();output[k]=v;__syncwarp();
        }
        if(!lane) {float* tail=(float*)(input+K-4);tail[0]=scale;tail[1]=sum;}
    }
}
template<bool RESIDUAL>
__device__ __forceinline__ void exl3_gemm_int8_inner(const half* A,const uint16_t* B,half* C,int M,int K,int N) {
    extern __shared__ half shared[];
    uint8_t* sha=(uint8_t*)shared;
    uint16_t* shb=(uint16_t*)(sha+3*1024);
    int tid=threadIdx.x,warp=tid/32,lane=tid&31;
    float scale[4],sum[4];
    #pragma unroll
    for(int m=0;m<4;++m){int row=lane/4+8*m;scale[m]=1.f;sum[m]=0.f;if(row<M){const float* tail=(const float*)(A+(row+1)*K-4);scale[m]=tail[0];sum[m]=tail[1];}}
    for(int nt=blockIdx.x;nt<N/256;nt+=gridDim.x) {
        I8A fa[2][2]; I8B fb[2][2],fr[2][2]; I8C fc[2][2]={},rc[2][2]={};
        const int steps=K/32;
        auto load=[&](int k) {
            if(k<steps) {
                int slot=k%3;
                if(tid<64) {
                    int row=tid/2,col=tid%2,sw=col^((row>>2)&1);
                    if(row<M) cp_async((int4*)(sha+slot*1024)+row*2+sw,(const int4*)((const uint8_t*)A+row*K*2+k*32)+col);
                    else ((int4*)(sha+slot*1024))[row*2+sw]=make_int4(0,0,0,0);
                }
                if(tid<256) {
                    int kb=tid/128,nb=tid%128;
                    cp_async((int4*)(shb+slot*2048)+tid,(const int4*)(B+(k*2+kb)*(N/16)*64+nt*16*64)+nb);
                }
            }
            cp_async_fence();
        };
        auto fragments=[&](int k,int buf) {
            const uint8_t* ap=sha+(k%3)*1024;
            #pragma unroll
            for(int m=0;m<2;++m) {
                if(m==1 && M<=16) continue;
                int row=(lane%8)+8*((lane/8)%2)+m*16,col=lane/16;
                FragA v;ldsm4(v,(const int4*)ap+row*2+(col^((row>>2)&1)));
                #pragma unroll
                for(int j=0;j<4;++j)fa[buf][m].v[j]=((uint32_t*)&v)[j];
            }
            #pragma unroll
            for(int kb=0;kb<2;++kb) {
                uint32_t bv[2],rv[2];
                decode_i8<RESIDUAL>((const uint32_t*)(shb+(k%3)*2048+(kb*16+warp)*64),lane,bv,rv);
                #pragma unroll
                for(int n=0;n<2;++n){fb[buf][n].v[kb]=bv[n];if constexpr(RESIDUAL) fr[buf][n].v[kb]=rv[n];}
            }
            __syncthreads();
        };
        load(0);load(1);cp_async_wait<1>();__syncthreads();fragments(0,0);
        #define INT8_STEP(BUF) \
            load(k+2);cp_async_wait<1>();__syncthreads(); \
            if(k+1<steps) fragments(k+1,1-BUF); \
            _Pragma("unroll") \
            for(int m=0;m<2;++m) { \
                if(m==1&&M<=16)continue; \
                _Pragma("unroll") \
                for(int n=0;n<2;++n) { \
                    imma(fa[BUF][m],fb[BUF][n],fc[m][n]); \
                    if constexpr(RESIDUAL) imma(fa[BUF][m],fr[BUF][n],rc[m][n]); \
                } \
            } \
            ++k;
        for(int k=0;k<steps;) {INT8_STEP(0);INT8_STEP(1);}
        #undef INT8_STEP
        cp_async_wait<0>();__syncthreads();
        const float kinv=__half2float(__ushort_as_half(0x1eee));
        const float bias=1534.f*kinv+__half2float(__ushort_as_half(0xc931));
        #pragma unroll
        for(int m=0;m<2;++m) for(int n=0;n<2;++n) {
            #pragma unroll
            for(int r=0;r<2;++r) {
                int row=lane/4+m*16+r*8;
                if(row<M) {
                    float v0=4.f*fc[m][n].v[r*2],v1=4.f*fc[m][n].v[r*2+1];
                    if constexpr(RESIDUAL){v0+=rc[m][n].v[r*2];v1+=rc[m][n].v[r*2+1];}
                    half2 v=__floats2half2_rn(v0*(scale[2*m+r]*kinv)+bias*sum[2*m+r],v1*(scale[2*m+r]*kinv)+bias*sum[2*m+r]);
                    *((half2*)(C+row*N+nt*256+warp*16+n*8+(lane%4)*2))=v;
                }
            }
        }
        __syncthreads();
    }
}
