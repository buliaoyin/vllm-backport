#include <cuda_runtime_api.h>
#include <dlfcn.h>
#include <cstdio>
#include <cstdlib>
#include <mutex>
#include <set>
#include <string>
static void trace(const void* f) {
  static std::mutex mutex;static std::set<std::string> seen;
  const char* name=nullptr;
  auto get=(cudaError_t(*)(const char**,const void*))dlsym(RTLD_NEXT,"cudaFuncGetName");
  if(get) get(&name,f);
  const char* mode=getenv("EXL3_INT8_GEMV");
  std::string key=std::string(mode?mode:"default")+":"+(name?name:"unknown");
  std::lock_guard<std::mutex> guard(mutex);
  if(seen.insert(key).second)fprintf(stderr,"EXL3_KERNEL_TRACE %s\n",key.c_str());
}
extern "C" cudaError_t cudaLaunchKernel(const void* f,dim3 g,dim3 b,void** args,size_t sm,cudaStream_t stream) {
  auto next=(decltype(&cudaLaunchKernel))dlsym(RTLD_NEXT,"cudaLaunchKernel");
  trace(f);return next(f,g,b,args,sm,stream);
}
extern "C" cudaError_t cudaLaunchCooperativeKernel(const void* f,dim3 g,dim3 b,void** args,size_t sm,cudaStream_t stream) {
  auto next=(decltype(&cudaLaunchCooperativeKernel))dlsym(RTLD_NEXT,"cudaLaunchCooperativeKernel");
  trace(f);return next(f,g,b,args,sm,stream);
}
