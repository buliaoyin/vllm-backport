import gzip,json,hashlib,shutil
from pathlib import Path
src=Path('/tmp/exl3-int8-20260911');dst=Path('/home/bul/dev/vllm-backport/docs/validation/exl3-int8-20260911');dst.mkdir(exist_ok=True)
for path in sorted(src.iterdir()):
 if path.is_file() and path.name.endswith('.json.gz'):
  shutil.copyfile(path,dst/path.name)
  continue
 if not path.is_file() or path.suffix not in ('.py','.cpp','.log','.json','.sass','.md'):continue
 # Benchmark stdout may be large; raw JSON and source files are compactly archived.
 data=path.read_bytes();target=dst/(path.name+'.gz')
 target.write_bytes(gzip.compress(data,mtime=0))
for build in [*sorted(src.glob('build-v*')),*sorted(src.glob('final-*'))]:
 if not build.is_dir():continue
 meta={'name':build.name,'sha256':{}}
 for name in ['gemm_int8.cuh','moe_int8.cuh','int8.cu','build.json','build.log']:
  path=build/name
  if not path.exists():continue
  data=path.read_bytes();meta['sha256'][name]=hashlib.sha256(data).hexdigest();(dst/f'{build.name}-{name}.gz').write_bytes(gzip.compress(data,mtime=0))
 meta['sha256']['int8.so']=hashlib.sha256((build/'int8.so').read_bytes()).hexdigest()
 (dst/f'{build.name}-sha256.json').write_text(json.dumps(meta,indent=2))
manifest={p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted(dst.iterdir()) if p.name!='manifest.json'}
(dst/'manifest.json').write_text(json.dumps(manifest,indent=2))
print(len(manifest),'artifacts')
