#include "fp16/moe_rows.cuh"
#include "moe_int8.cuh"
extern "C" void* exl3_rows_int8() { return (void*)exl3_moe_int8_kernel<4,256,2,2,32,32,true,false>; }
extern "C" void* exl3_rows_int8_residual() { return (void*)exl3_moe_int8_kernel<4,256,2,2,32,32,true,true>; }
extern "C" void* exl3_rows_m32_predicated() { return (void*)exl3_moe_rows_v2_kernel<4,256,2,2,32,32,true>; }
