from pathlib import Path
p=Path('/tmp/exl3-int8-20260911');s=(p/'gemm_int8_v8.cuh').read_text();a=s.index('__device__ __forceinline__ void quantize_rows');b=s.index('template<bool RESIDUAL>',a)
s=s[:a]+'''__device__ __forceinline__ void quantize_rows(half* A,int M,int K,int start,int stride) {
    extern __shared__ half shared[];
    float* maxima=(float*)shared;float* sums=maxima+16;
    const int tid=threadIdx.x,lane=tid%128,warp=tid/32,local_row=tid/128;
    for(int base=blockIdx.x*4;base<M;base+=gridDim.x*4) {
        int row=base+local_row;
        half* input=A+row*K;
        float amax=0,sum=0;
        if(row<M) for(int k=lane*4;k<K;k+=512) {
            float2 x=__half22float2(((const half2*)(input+k))[0]);
            float2 y=__half22float2(((const half2*)(input+k))[1]);
            amax=fmaxf(amax,fmaxf(fmaxf(fabsf(x.x),fabsf(x.y)),fmaxf(fabsf(y.x),fabsf(y.y))));
            sum+=(x.x+x.y)+(y.x+y.y);
        }
        amax=__uint_as_float(__reduce_max_sync(0xffffffff,__float_as_uint(amax)));
        #pragma unroll
        for(int x=16;x;x>>=1)sum+=__shfl_xor_sync(0xffffffff,sum,x);
        if(!(tid&31)){maxima[warp]=amax;sums[warp]=sum;}
        __syncthreads();
        int r=local_row*4;
        amax=fmaxf(fmaxf(maxima[r],maxima[r+1]),fmaxf(maxima[r+2],maxima[r+3]));
        sum=(sums[r]+sums[r+1])+(sums[r+2]+sums[r+3]);
        float scale=fmaxf(amax/127.f,1e-20f),inv=1.f/scale;
        uint32_t* output=(uint32_t*)input;
        for(int k=lane*4;k<K;k+=512) {
            uint32_t q=0;
            if(row<M) {
                float2 x=__half22float2(((const half2*)(input+k))[0]);
                float2 y=__half22float2(((const half2*)(input+k))[1]);
                q=pack4(__float2int_rn(x.x*inv),__float2int_rn(x.y*inv),__float2int_rn(y.x*inv),__float2int_rn(y.y*inv));
            }
            __syncthreads();
            if(row<M)output[k/4]=q;
            __syncthreads();
        }
        if(!lane&&row<M){float* tail=(float*)(input+K-4);tail[0]=scale;tail[1]=sum;}
        __syncthreads();
    }
}
'''+s[b:];(p/'gemm_int8_v9.cuh').write_text(s)
