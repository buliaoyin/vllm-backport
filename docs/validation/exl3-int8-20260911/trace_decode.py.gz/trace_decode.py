import os,sys
sys.path.insert(0,'/home/bul/dev/vllm-backport')
import torch
from tests.quantization.test_exl3 import _weights
from vllm.model_executor.layers.quantization.exl3 import _exl3_linear,_extension
w=_weights(4096,4096,4,'cuda');ext=_extension()
for m in [1,2,4,32]:
 x=torch.randn(m,4096,device='cuda',dtype=torch.float16)
 for mode in [0,1,2]:
  os.environ['EXL3_INT8_GEMV']=str(mode)
  print('TRACE_CALL',m,mode,flush=True)
  _exl3_linear(x,w['trellis'],w['suh'],w['svh'],False,True)
  torch.accelerator.synchronize()
