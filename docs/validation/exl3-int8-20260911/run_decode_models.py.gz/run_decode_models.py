import os,sys,json,subprocess,time,hashlib
from pathlib import Path
R=Path('/home/bul/dev/vllm-backport');O=Path('/tmp/exl3-int8-20260911')
script=(R/'benchmarks/benchmark_exl3.py').read_text().replace('range(0, len(data["evals"]), args.batch_size)','range(0, len(data["evals"]), 1)').replace('data["evals"][offset : offset + args.batch_size]','data["evals"][offset : offset + 1]')
(O/'benchmark_decode.py').write_text(script)
for kind in ['dense','moe']:
 d=json.loads((R/f'docs/validation/exl3-20260910/{kind}-inputs.json').read_text());d['cases']=[c for c in d['cases'] if c['name'].startswith('p2048_')];d['evals']=d['evals'][:16];(O/f'{kind}-decode-inputs.json').write_text(json.dumps(d))
status=[]
for kind in sys.argv[1:]:
 for backend in ['vllm','exllamav3']:
  for mode in [0,1,2]:
   name=f'{kind}-{backend}-int8-{mode}';output=O/f'{name}.json'
   if output.exists() and len(json.loads(output.read_text()).get('eval',[]))==16:continue
   env=dict(os.environ,CUDA_DEVICE_ORDER='PCI_BUS_ID',CUDA_VISIBLE_DEVICES='3' if kind=='dense' else '0,1,2,3',EXL3_INT8_GEMV=str(mode),OMP_NUM_THREADS='1',NCCL_P2P_DISABLE='1',VLLM_EXL3_MOE_MAX_TOKENS='1024',VLLM_EXL3_MOE_PRIORITY='1',VLLM_DETERMINISTIC_MOE_ALIGN='0')
   if kind=='moe':env['VLLM_PP_LAYER_PARTITION']='11,11,11,12'
   else:env.pop('VLLM_PP_LAYER_PARTITION',None)
   env['PYTHONPATH']=str(R/'benchmarks')+':'+str(R)+(':/home/bul/dev/exllamav3' if backend=='exllamav3' else '')
   cmd=[str(R/'.venv/bin/python'),str(O/'benchmark_decode.py'),'--backend',backend,'--inputs',str(O/f'{kind}-decode-inputs.json'),'--output',str(output),'--pp','1' if kind=='dense' else '4','--chunk-size','1024','--max-model-len','4096','--kv-cache-gib','2','--exl-cache-tokens','16384','--batch-size','4','--tokens','128','--eval-tokens','768','--warmups','1','--repeats','3']
   if kind=='moe':cmd+=['--expected-layer-counts','11','11','11','12','--exl-memory','32','41','41','49']
   if backend=='exllamav3':cmd=['/home/bul/miniconda3/bin/conda','run','--no-capture-output','-n','exllamav3','python',*cmd[1:]]
   record={'name':name,'command':cmd,'environment':{k:v for k,v in env.items() if k in ('CUDA_VISIBLE_DEVICES','EXL3_INT8_GEMV','VLLM_PP_LAYER_PARTITION','NCCL_P2P_DISABLE','VLLM_EXL3_MOE_MAX_TOKENS')},'start':time.time()};status.append(record);(O/'decode-model-status.json').write_text(json.dumps(status,indent=2))
   print('START',name,flush=True)
   with (O/f'{name}.log').open('w') as log:r=subprocess.run(cmd,cwd=R,env=env,stdout=log,stderr=subprocess.STDOUT)
   record.update(exit_code=r.returncode,end=time.time());(O/'decode-model-status.json').write_text(json.dumps(status,indent=2));print('DONE',name,r.returncode,flush=True)
   if r.returncode:raise SystemExit(r.returncode)
