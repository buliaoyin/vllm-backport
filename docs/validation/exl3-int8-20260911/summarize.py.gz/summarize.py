import json,statistics,hashlib,gzip
import regex as re
from pathlib import Path
R=Path('/home/bul/dev/vllm-backport');O=Path('/tmp/exl3-int8-20260911')
summary={'decode':[],'prefill':[],'prefill_quality':[],'experiments':[]}
inputs=json.loads(gzip.decompress((O/'prefill-model-inputs.json.gz').read_bytes()))
old_perf=json.loads(gzip.decompress((R/'docs/validation/exl3-fixed-pp-20260910/exl3-long-b1-inputs.json.gz').read_bytes()))
old_eval=json.loads(gzip.decompress((R/'docs/validation/exl3-sm80-m32-20260911/eval-inputs.json.gz').read_bytes()))
assert inputs['cases']==old_perf['cases']
assert inputs['evals']==old_eval['evals']

for kind in ['dense','moe']:
 for backend in ['vllm','exllamav3']:
  baseline=None
  for mode in [0,1,2]:
   p=O/f'{kind}-{backend}-int8-{mode}.json'
   if not p.exists():continue
   d=json.loads(p.read_text())
   if len(d['eval'])!=16:continue
   assert len(d['perf'])==6
   if kind=='moe':
    expected=[list(range(0,11)),list(range(11,22)),list(range(22,33)),list(range(33,45))]
    if backend=='vllm':
     actual=[[v['index'] for v in rank['decoder_layers']] for rank in sorted(d['runtime_before'],key=lambda r:r['pp_rank'])]
    else:
     actual=[[] for _ in range(4)]
     for name,device in d['module_devices']:
      match=re.search(r'\.layers\.(\d+)$',name)
      if match:actual[int(device.split(':')[-1])].append(int(match.group(1)))
    assert [sorted(v) for v in actual]==expected,actual
   for record in d['perf']:
    assert all(r['new_tokens']==128 and r['cached_tokens']==0 for r in record['rows'])
   perf={case:[r for r in d['perf'] if r['case']==case] for case in ['p2048_b1','p2048_b4']}
   rec={'model':kind,'backend':backend,'mode':mode,
        'b1_decode_tps':statistics.median(127/r['rows'][0]['decode'] for r in perf['p2048_b1']),
        'b1_ttft':statistics.median(r['max_ttft'] for r in perf['p2048_b1']),
        'b4_generate_tps':statistics.median(r['throughput'] for r in perf['p2048_b4']),
        'b4_generate_tps_samples':[r['throughput'] for r in perf['p2048_b4']],
        'correct':sum(r['correct'] for r in d['eval']),'samples':16,
        'wrong':[{'id':r['id'],'expected':r['expected'],'predicted':r['predicted'],'new_tokens':r['new_tokens'],'finish':r['finish_reason']} for r in d['eval'] if not r['correct']],
        'input_sha256':d.get('inputs_sha256'),'sha256':hashlib.sha256(p.read_bytes()).hexdigest()}
   if mode==0:baseline=d
   else:
    assert [r['id'] for r in d['eval']]==[r['id'] for r in baseline['eval']]
    rec['answers_equal_mode0']=sum(r['predicted']==b['predicted'] for r,b in zip(d['eval'],baseline['eval']))
    rec['tokens_equal_mode0']=sum(r['token_ids']==b['token_ids'] for r,b in zip(d['eval'],baseline['eval']))
   summary['decode'].append(rec)
p=O/'prefill-model.json'
if p.exists():
 d=json.loads(p.read_text())
 expected=[list(range(0,11)),list(range(11,22)),list(range(22,33)),list(range(33,45))]
 actual=[[v['index'] for v in rank['decoder_layers']] for rank in sorted(d['runtime_before'],key=lambda r:r['pp_rank'])]
 assert actual==expected,actual
 assert d['environment']['EXL3_INT8_GEMV']=='0'
 assert d['args']['chunk_size']==1024 and d['args']['kv_cache_gib']==8
 build=json.loads((O/'final-v9/build.json').read_text())
 for phase in d['workspace_sweep']:
  assert len(phase)==4
  for rank,record in enumerate(phase):
   assert record['expert_layers']==[8,11,11,12][rank]
   if rank==3:
    assert record['row_kernel']=='native'
    continue
   kernel=record['row_kernel']
   assert kernel['sha256']==build['library_sha256']
   assert kernel['variant']==record['options']['rows_variant']
   assert kernel['expert_layers']==[8,11,11][rank]
 for case in sorted({r['case'] for r in d['perf']},key=lambda c:int(c.split('_')[0][1:])):
  rec={'case':case}
  for variant in ['m32_before','int8_sm80','m32_after']:
   rows=[r for r in d['perf'] if r['case']==case and r['variant']['name']==variant]
   if len(rows)!=3:continue
   assert all(len(r['rows'])==1 and r['rows'][0]['cached_tokens']==0 and r['rows'][0]['new_tokens']==32 for r in rows)
   rec[variant]={'ttft':statistics.median(r['max_ttft'] for r in rows),'ttft_samples':[r['max_ttft'] for r in rows],'prefill_tps':statistics.median(r['rows'][0]['prompt_tokens']/r['max_ttft'] for r in rows),'checks':sum(c['matched'] for r in rows for c in r['checks'])}
  summary['prefill'].append(rec)
 for variant in ['m32_before','int8_sm80']:
  rows=[r for r in d['eval'] if r['variant']==variant]
  rec={'variant':variant,'samples':len(rows),'correct':sum(r['correct'] for r in rows),'wrong':[r['id'] for r in rows if not r['correct']]}
  if variant=='m32_before':baseline={r['id']:r for r in rows}
  else:
   rec['answers_equal_fp16']=sum(r['predicted']==baseline[r['id']]['predicted'] for r in rows)
   rec['tokens_equal_fp16']=sum(r['token_ids']==baseline[r['id']]['token_ids'] for r in rows)
   rec['changed_answers']=[{'id':r['id'],'expected':r['expected'],'fp16':baseline[r['id']]['predicted'],'int8':r['predicted']} for r in rows if r['predicted']!=baseline[r['id']]['predicted']]
  summary['prefill_quality'].append(rec)
 summary['runtime']=d.get('runtime_before')
for i in range(1,10):
 p=O/f'int8-v{i}-layer22.json'
 if not p.exists():continue
 d=json.loads(p.read_text());rec={'version':i,'rows':1024}
 for r in d['records']:
  if r['rows']==1024 and r['variant']=='int8':rec.update({k:v for k,v in r.items() if k!='times_ms'})
 summary['experiments'].append(rec)
(O/'summary.json').write_text(json.dumps(summary,indent=2));print(json.dumps({k:summary[k] for k in ['decode','prefill','prefill_quality']},indent=2))
