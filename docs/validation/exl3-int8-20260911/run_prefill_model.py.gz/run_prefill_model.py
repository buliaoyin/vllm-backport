import os,json,subprocess,time
from pathlib import Path
R=Path('/home/bul/dev/vllm-backport');O=Path('/tmp/exl3-int8-20260911')
variants=[{'name':name,'capacity':1024,'priority':True,'rows_library':str(O/'final-v9/int8.so'),'rows_variant':variant} for name,variant in [('m32_before','m32_predicated'),('int8_sm80','int8'),('m32_after','m32_predicated')]]
(O/'prefill-model-variants.json').write_text(json.dumps(variants,indent=2))
cmd=[str(R/'.venv/bin/python'),str(O/'benchmark_prefill.py'),'--backend','vllm','--inputs',str(O/'prefill-model-inputs.json.gz'),'--output',str(O/'prefill-model.json'),'--pp','4','--expected-layer-counts','11','11','11','12','--chunk-size','1024','--max-model-len','66560','--kv-cache-gib','8','--batch-size','4','--warmups','1','--repeats','3','--tokens','32','--moe-variants',str(O/'prefill-model-variants.json'),'--worker-extension-cls','kernels.exl3_int8.worker.Exl3Int8WorkerExtension']
env=dict(os.environ,CUDA_DEVICE_ORDER='PCI_BUS_ID',CUDA_VISIBLE_DEVICES='0,1,2,3',NCCL_P2P_DISABLE='1',VLLM_PP_LAYER_PARTITION='11,11,11,12',OMP_NUM_THREADS='1',EXL3_INT8_GEMV='0',VLLM_DETERMINISTIC_MOE_ALIGN='0',VLLM_EXL3_MOE_MAX_TOKENS='1024',VLLM_EXL3_MOE_PRIORITY='1',PYTHONPATH=str(R/'benchmarks')+':'+str(R))
meta={'command':cmd,'start':time.time()};(O/'prefill-model-status.json').write_text(json.dumps(meta,indent=2))
with (O/'prefill-model.log').open('w') as log:result=subprocess.run(cmd,cwd=R,env=env,stdout=log,stderr=subprocess.STDOUT)
meta.update(exit_code=result.returncode,end=time.time());(O/'prefill-model-status.json').write_text(json.dumps(meta,indent=2));raise SystemExit(result.returncode)
