import os,sys,json,statistics
from pathlib import Path
sys.path.insert(0,'/home/bul/dev/vllm-backport')
import torch
from tests.quantization.test_exl3 import _weights,_reference
from vllm.model_executor.layers.quantization.exl3 import _exl3_linear,_extension
from benchmarks.kernels.exl3_m32.benchmark import graph_times
out=Path(sys.argv[1]); ext=_extension(); torch.manual_seed(711)
result={'gpu':torch.cuda.get_device_name(),'torch':str(torch.__version__),'records':[]}
for k,n,bits in [(4096,2048,4),(4096,4096,4),(4096,14336,4),(2048,4096,4),(4096,4096,6)]:
 w=_weights(k,n,bits,'cuda')
 for m in [1,2,4,32]:
  x=torch.randn(m,k,device='cuda',dtype=torch.float16)
  ref=_reference(x,w)
  for mode in [0,1,2,0]:
   os.environ['EXL3_INT8_GEMV']=str(mode)
   fn=lambda:_exl3_linear(x,w['trellis'],w['suh'],w['svh'],False,True)
   y=fn(); torch.accelerator.synchronize()
   err=float((y.float()-ref.float()).norm()/ref.float().norm())
   times=graph_times(fn,15)
   with torch.profiler.profile(activities=[torch.profiler.ProfilerActivity.CPU,torch.profiler.ProfilerActivity.CUDA]) as p:fn()
   kernels=[e.name for e in p.events() if e.device_type==torch.autograd.DeviceType.CUDA]
   r={'m':m,'k':k,'n':n,'bits':bits,'mode':mode,'relative_l2':err,'times_ms':times,'median_us':statistics.median(times)*1000,'kernels':kernels}
   result['records'].append(r);out.write_text(json.dumps(result,indent=2));print({a:b for a,b in r.items() if a not in ('times_ms','kernels')},flush=True)
