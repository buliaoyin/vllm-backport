import os,sys,json,statistics
from pathlib import Path
import torch
sys.path.insert(0,'/home/bul/dev/vllm-backport')
from benchmarks.kernels import benchmark_exl3_moe as bench
from launcher import Launcher
from benchmarks.kernels.exl3_m32.benchmark import graph_times
root=Path('/tmp/exl3-int8-20260911')
@torch.inference_mode()
def run(layer,method,args,k,n):
 sample=torch.load(args.route_sample,weights_only=True,map_location='cuda');ext=bench._extension();native=ext.exl3_moe
 result={'gpu':torch.cuda.get_device_name(),'prefix':args.prefix,'route':str(args.route_sample),'records':[]}
 for rows in args.prefill_rows:
  chunk=1024
  x,w,ids=(sample[t][:rows].contiguous() for t in ('x','weights','ids'))
  workspace=[t.new_empty((t.shape[0],chunk,t.shape[2])) for t in method.workspace]
  inputs=(x,w,ids,method.ptrs,workspace,method.bits,method.flags,10.)
  fn=lambda:bench.fused_with_chunk(inputs,chunk,longest_first=True)
  ext.exl3_moe=native;ref=fn();torch.accelerator.synchronize()
  for name in os.environ.get('INT8_VARIANTS','m32_predicated,int8,int8_residual,m32_predicated').split(','):
   lib=Path('/tmp/exl3-m32-20260911/final-build/rows.so') if name=='m32_predicated' else root/os.environ.get('INT8_BUILD','build-v1')/'int8.so'
   launcher=Launcher(ext,lib,name);ext.exl3_moe=launcher
   y=fn();torch.accelerator.synchronize();delta=y.float()-ref.float()
   rec={'rows':rows,'variant':name,'relative_l2':float(delta.norm()/ref.float().norm()),'max_abs':float(delta.abs().max()),'finite':bool(torch.isfinite(y).all())}
   if rec['finite'] and rec['relative_l2']<0.1:
    times=graph_times(fn);rec.update(times_ms=times,median_ms=statistics.median(times))
   result['records'].append(rec);args.output.write_text(json.dumps(result,indent=2));print({a:b for a,b in rec.items() if a!='times_ms'},flush=True)
   ext.exl3_moe=native
bench.prefill_ablation=run
if __name__=='__main__':bench.main()
