from pathlib import Path
p=Path('/tmp/exl3-int8-20260911');s=(p/'gemm_int8_v7.cuh').read_text();a=s.index('__device__ __forceinline__ void quantize_rows');b=s.index('template<bool RESIDUAL>',a)
s=s[:a]+'''__device__ __forceinline__ void quantize_rows(half* A,int M,int K,int start,int stride) {
    int lane=threadIdx.x&31;
    for(int row=start;row<M;row+=stride) {
        half* input=A+row*K;
        float amax=0,sum=0;
        for(int k=lane*4;k<K;k+=128) {
            float2 x=__half22float2(((const half2*)(input+k))[0]);
            float2 y=__half22float2(((const half2*)(input+k))[1]);
            amax=fmaxf(amax,fmaxf(fmaxf(fabsf(x.x),fabsf(x.y)),fmaxf(fabsf(y.x),fabsf(y.y))));
            sum+=(x.x+x.y)+(y.x+y.y);
        }
        amax=__uint_as_float(__reduce_max_sync(0xffffffff,__float_as_uint(amax)));
        #pragma unroll
        for(int x=16;x;x>>=1) sum+=__shfl_xor_sync(0xffffffff,sum,x);
        float scale=fmaxf(amax/127.f,1e-20f),inv=1.f/scale;
        uint32_t* output=(uint32_t*)input;
        for(int k=lane*4;k<K;k+=128) {
            float2 x=__half22float2(((const half2*)(input+k))[0]);
            float2 y=__half22float2(((const half2*)(input+k))[1]);
            uint32_t q=pack4(__float2int_rn(x.x*inv),__float2int_rn(x.y*inv),__float2int_rn(y.x*inv),__float2int_rn(y.y*inv));
            __syncwarp();output[k/4]=q;__syncwarp();
        }
        if(!lane) {float* tail=(float*)(input+K-4);tail[0]=scale;tail[1]=sum;}
    }
}
'''+s[b:];(p/'gemm_int8_v8.cuh').write_text(s)
