import gzip,json
from pathlib import Path
R=Path('/home/bul/dev/vllm-backport');O=Path('/tmp/exl3-int8-20260911')
s=(R/'benchmarks/benchmark_exl3.py').read_text()
beg=s.index('    if not args.skip_eval:\n');end=s.index('    print("SAVED"',beg)
block=s[beg:end]
block=block.replace('"id": request["id"],','"variant": eval_variant["name"],\n                        "id": request["id"],')
block='\n'.join('    '+line if line else line for line in block.splitlines())+'\n'
s=s[:beg]+'''    for eval_variant in variants[:2]:
        backend.llm.collective_rpc("configure_exl3_optimization", args=(eval_variant,))
'''+block+s[end:]
(O/'benchmark_prefill.py').write_text(s)
d=json.loads(gzip.decompress((R/'docs/validation/exl3-fixed-pp-20260910/exl3-long-b1-inputs.json.gz').read_bytes()))
e=json.loads(gzip.decompress((R/'docs/validation/exl3-sm80-m32-20260911/eval-inputs.json.gz').read_bytes()))
d['evals']=e['evals'];assert len(d['evals'])==64
(O/'prefill-model-inputs.json.gz').write_bytes(gzip.compress(json.dumps(d).encode(),mtime=0))
p=O/'run_prefill_model.py';s=p.read_text().replace("'benchmarks/benchmark_exl3.py'","str(O/'benchmark_prefill.py')").replace("'docs/validation/exl3-fixed-pp-20260910/exl3-long-b1-inputs.json.gz'","str(O/'prefill-model-inputs.json.gz')").replace("'--skip-eval',",'');p.write_text(s)
