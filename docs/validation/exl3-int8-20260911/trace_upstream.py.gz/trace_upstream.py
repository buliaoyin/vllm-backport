import os
import torch
import exllamav3_ext as ext
print('EXTENSION',ext.__file__,'TORCH',torch.__version__,flush=True)
x0=torch.randn(32,4096,device='cuda',dtype=torch.float16)
trellis=torch.randint(-32768,32767,(256,256,64),device='cuda',dtype=torch.int16)
suh=torch.randn(4096,device='cuda',dtype=torch.float16)*0.2
svh=torch.randn(4096,device='cuda',dtype=torch.float16)*0.2
for rows in [1,2,4,32]:
 x=x0[:rows].contiguous();out=torch.empty_like(x);had=torch.empty_like(x)
 for mode in ['0','1','2','default']:
  if mode=='default':os.environ.pop('EXL3_INT8_GEMV',None)
  else:os.environ['EXL3_INT8_GEMV']=mode
  print('TRACE_UPSTREAM',rows,mode,flush=True)
  ext.exl3_gemm(x,trellis,out,suh,had,svh,-1,False,True,0)
  torch.cuda.synchronize()
