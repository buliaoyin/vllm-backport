import sys,shutil,json,subprocess
from pathlib import Path
import regex as re
root=Path('/tmp/exl3-int8-20260911');out=root/sys.argv[1];out.mkdir(exist_ok=False)
base=Path('/tmp/exl3-m32-20260911/final-build');shutil.copytree(base/'upstream',out/'upstream')
shutil.copyfile(root/'gemm_int8.cuh',out/'gemm_int8.cuh')
s=(base/'moe_rows.cuh').read_text().replace('#include "gemm_rows.cuh"','#include "gemm_int8.cuh"')
s=s.replace('bool PREDICATE_ROWS>','bool PREDICATE_ROWS, bool RESIDUAL>').replace('exl3_moe_rows_v2_kernel','exl3_moe_int8_kernel')
s=re.sub(r'                if constexpr \(ROW_TILE_M == 16\).*?\(in_addr \+ offset \* hidden_dim,trellis,out_addr \+ offset \* intermediate_dim,rows,hidden_dim,intermediate_dim,locks,nullptr\);\n            }', '                exl3_gemm_int8_inner<RESIDUAL>(in_addr + offset * hidden_dim,trellis,out_addr + offset * intermediate_dim,rows,hidden_dim,intermediate_dim);\n            }',s,flags=re.S)
s=re.sub(r'                if constexpr \(ROW_TILE_M == 16\).*?\(in_addr \+ offset \* intermediate_dim,trellis,out_addr \+ offset \* hidden_dim,rows,intermediate_dim,hidden_dim,locks,nullptr\);\n            }', '                exl3_gemm_int8_inner<RESIDUAL>(in_addr + offset * intermediate_dim,trellis,out_addr + offset * hidden_dim,rows,intermediate_dim,hidden_dim);\n            }',s,flags=re.S)
if 'quantize_rows' in (root/'gemm_int8.cuh').read_text():
 s=s.replace('        had_gather_gu_in();','        had_gather_gu_in();\n        if(gated) quantize_rows(temp_state_g,token_count,hidden_dim,warp_idx0,warps_per_group);\n        quantize_rows(temp_state_u,token_count,hidden_dim,warp_idx0,warps_per_group);\n        group_barrier(group_idx,group_size,barrier_counters_sense);')
 s=s.replace('        had_guad();','        had_guad();\n        quantize_rows(temp_intermediate_g,token_count,intermediate_dim,warp_idx0,warps_per_group);\n        group_barrier(group_idx,group_size,barrier_counters_sense);')
assert s.count('exl3_gemm_int8_inner')==2
if 'codebook_int8.cuh' in (root/'gemm_int8.cuh').read_text():
 shutil.copyfile(root/'codebook_int8.cuh',out/'codebook_int8.cuh')
 s=s.replace('    // Buffers for group','    if constexpr(!RESIDUAL) {\n        extern __shared__ half shared[];\n        int4* table=(int4*)((char*)shared+24576);\n        for(int i=threadIdx.x;i<4096;i+=512) table[i]=((const int4*)exl3_int8_codebook)[i];\n        __syncthreads();\n    }\n    // Buffers for group')
(out/'moe_int8.cuh').write_text(s)
(out/'int8.cu').write_text('#include "moe_int8.cuh"\n'+''.join(f'extern "C" void* exl3_rows_{name}() {{ return (void*)exl3_moe_int8_kernel<4,256,2,2,32,32,true,{res}>; }}\n' for name,res in [('int8','false'),('int8_residual','true')]))
cmd=json.loads((base/'build.json').read_text())['command'];cmd=[x.replace(str(base),str(out)).replace('rows.cu','int8.cu').replace('rows.so','int8.so') for x in cmd]
(out/'build.json').write_text(json.dumps({'command':cmd},indent=2))
with (out/'build.log').open('w') as log:subprocess.run(cmd,stdout=log,stderr=subprocess.STDOUT,check=True)
print(out/'int8.so')
