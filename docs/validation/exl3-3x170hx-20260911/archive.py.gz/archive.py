import gzip
import hashlib
import json
from pathlib import Path

source = Path('/tmp/exl3-3x170hx-20260911')
dest = Path('/home/bul/dev/vllm-backport/docs/validation/exl3-3x170hx-20260911')
dest.mkdir(exist_ok=True)
manifest = {'scope': 'GLM-5.3-Flash EXL3 on GPUs 0,1,2 only; PP and chunk tuning. Failed startup cases are retained. The copied four-GPU run is a historical reference.', 'artifacts': []}
for path in sorted(source.iterdir()):
    if not path.is_file() or path.suffix not in ('.json', '.jsonl', '.log', '.py', '.gz', '.txt'):
        continue
    data = path.read_bytes()
    name = path.name if path.suffix == '.gz' else path.name + '.gz'
    compressed = data if path.suffix == '.gz' else gzip.compress(data, mtime=0)
    (dest / name).write_bytes(compressed)
    manifest['artifacts'].append({'source': str(path), 'artifact': name, 'original_sha256': hashlib.sha256(data).hexdigest(), 'artifact_sha256': hashlib.sha256(compressed).hexdigest()})
(dest / 'manifest.json').write_text(json.dumps(manifest, indent=2) + '\n')
print('Archived', len(manifest['artifacts']), 'artifacts')
