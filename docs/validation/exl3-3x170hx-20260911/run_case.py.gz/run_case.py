import argparse
import json
import os
import subprocess
import sys
import time
from pathlib import Path

ROOT=Path('/home/bul/dev/vllm-backport')
OUT=Path('/tmp/exl3-3x170hx-20260911')
parser=argparse.ArgumentParser()
parser.add_argument('--name',required=True)
parser.add_argument('--partition',type=int,nargs=3,required=True)
parser.add_argument('--chunk',type=int,default=6144)
parser.add_argument('--kv',type=float,default=4)
parser.add_argument('--repeats',type=int,default=2)
parser.add_argument('--warmups',type=int,default=1)
parser.add_argument('--tokens',type=int,default=32)
parser.add_argument('--full',action='store_true')
parser.add_argument('--profile',action='store_true')
parser.add_argument('--native',action='store_true')
parser.add_argument('--inputs',type=Path)
args=parser.parse_args()
assert sum(args.partition)==45 and min(args.partition)>0
env={k:v for k,v in os.environ.items() if not k.startswith(('EXL3_','VLLM_EXL3_'))}
env.update(CUDA_DEVICE_ORDER='PCI_BUS_ID',CUDA_VISIBLE_DEVICES='0,1,2',OMP_NUM_THREADS='1',NCCL_P2P_DISABLE='1',VLLM_PP_LAYER_PARTITION=','.join(map(str,args.partition)),VLLM_EXL3_MOE_MAX_TOKENS=str(args.chunk),PYTHONPATH=str(ROOT/'benchmarks')+':'+str(ROOT),VLLM_TRITON_USE_TD='0',EXL3_INT8_GEMV='2')
worker='benchmarks.kernels.exl3_prefill.worker.WorkerExtension'
if not args.native:
 env.update(VLLM_EXL3_BATCHED_INT8_LIBRARY='/tmp/exl3-target4700-20260911/kernels-batched-int8-r1/helpers.so',VLLM_EXL3_BATCHED_INT8_CONFIG='m64n128k64',VLLM_EXL3_BATCHED_INT8_MIN_ROWS='4096')
 worker='benchmarks.kernels.exl3_prefill_int8.worker.WorkerExtension'
inputs=args.inputs or OUT/('inputs.json.gz' if args.full else 'confirmation-inputs.json.gz')
command=[sys.executable,str(OUT/'benchmark_exl3.py'),'--backend','vllm','--inputs',str(inputs),'--output',str(OUT/(args.name+'.json')),'--pp','3','--expected-layer-counts',*map(str,args.partition),'--max-model-len','66560','--kv-cache-gib',str(args.kv),'--batch-size','4','--chunk-size',str(args.chunk),'--warmups',str(args.warmups),'--repeats',str(args.repeats),'--tokens',str(args.tokens),'--skip-eval','--worker-extension-cls',worker]
if args.profile:command+=['--event-profile']
status={'name':args.name,'command':command,'environment':{k:v for k,v in env.items() if k.startswith(('CUDA_','EXL3_','VLLM_','NCCL_','OMP_','PYTHONPATH','PYTORCH_'))},'start':time.time()}
status_path=OUT/(args.name+'-status.json');status_path.write_text(json.dumps(status,indent=2))
print('START',args.name,flush=True)
with (OUT/(args.name+'.log')).open('w') as log:
 process=subprocess.run(command,cwd=ROOT,env=env,stdout=log,stderr=subprocess.STDOUT,timeout=1000)
status.update(exit_code=process.returncode,end=time.time());status_path.write_text(json.dumps(status,indent=2))
print('DONE',args.name,process.returncode,flush=True)
if process.returncode:raise SystemExit(process.returncode)
d=json.loads((OUT/(args.name+'.json')).read_text())
assert len(d['gpu_names'])==3 and all('170HX' in x for x in d['gpu_names'])
for r in d['runtime_after']:
 assert r['linear_cache'] is None
 assert all(x['decode_mode']=='plain' for x in r['layers'])
 if not args.native:
  b=r['batched_int8_prefill'];assert b['calls']>0 and b['minimum_rows']==4096
  assert all(k['imma'] for k in b['gemm_kernels'].values())
for r in d['perf']:
 assert all(x['cached_tokens']==0 and x['new_tokens']==args.tokens for x in r['rows'])
 assert all(c['matched'] for c in r.get('checks',[]))
print('VALIDATED',args.name,flush=True)
