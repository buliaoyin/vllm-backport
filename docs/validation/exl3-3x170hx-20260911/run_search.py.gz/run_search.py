import json
import os
import statistics
import subprocess
import sys
import time
from pathlib import Path

OUT = Path('/tmp/exl3-3x170hx-20260911')
ROOT = Path('/home/bul/dev/vllm-backport')
FIRST = 'pp16-15-14-c6144-kv2-expand'
while f'VALIDATED {FIRST}' not in (OUT / 'resume-runner.log').read_text():
    s = json.loads((OUT / (FIRST + '-status.json')).read_text())
    if s.get('exit_code', 0) != 0:
        raise RuntimeError('Resumed run failed; investigate before sweeping')
    time.sleep(3)

env = dict(os.environ, PYTORCH_ALLOC_CONF='expandable_segments:True')
results = []

def collect(name):
    d = json.loads((OUT / (name + '.json')).read_text())
    result = {'name': name, 'partition': d['args']['expected_layer_counts'],
              'chunk': d['resolved_chunk_size'], 'kv_gib': d['args']['kv_cache_gib'],
              'input_tps': statistics.median(r['rows'][0]['prompt_tokens'] / r['rows'][0]['ttft'] for r in d['perf']),
              'output_tps': statistics.median((r['rows'][0]['new_tokens'] - 1) / r['rows'][0]['decode'] for r in d['perf'])}
    results.append(result)
    (OUT / 'search-results.json').write_text(json.dumps(results, indent=2))
    print('RESULT', json.dumps(result), flush=True)
    return result

def run(partition, chunk, native=False):
    name = ('native-' if native else '') + 'pp' + '-'.join(map(str, partition)) + f'-c{chunk}-kv2-expand'
    command = [sys.executable, str(OUT / 'run_case.py'), '--name', name,
               '--partition', *map(str, partition), '--chunk', str(chunk), '--kv', '2']
    if native:
        command.append('--native')
    p = subprocess.run(command, cwd=ROOT, env=env, timeout=1100)
    if p.returncode:
        log = (OUT / (name + '.log')).read_text()
        if 'torch.OutOfMemoryError' not in log:
            raise RuntimeError(f'Unexpected failure in {name}')
        print('EXCLUDE_OOM', name, flush=True)
        time.sleep(3)
        return None
    return collect(name)

collect(FIRST)
for part in ([17, 14, 14], [16, 14, 15], [15, 15, 15]):
    run(part, 6144)
part_results = list(results)
best = max(part_results, key=lambda r: r['input_tps'])
(OUT / 'partition-selection.json').write_text(json.dumps({'candidates': part_results, 'selected': best}, indent=2))
print('PARTITION_SELECTED', json.dumps(best), flush=True)
run(best['partition'], 8192)
run(best['partition'], 4096)
# The memory-balanced partition may fit a larger chunk when a 15-expert stage cannot.
if best['partition'] != [17, 14, 14]:
    run([17, 14, 14], 8192)
run(best['partition'], 2048, native=True)
print('SEARCH_DONE', flush=True)
