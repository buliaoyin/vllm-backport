import os
import subprocess
import sys
import time
from pathlib import Path

OUT=Path('/tmp/exl3-3x170hx-20260911')
while 'FINAL_DONE' not in (OUT/'final-runner.log').read_text():
    if 'Traceback (most recent call last)' in (OUT/'final-runner.log').read_text():
        raise RuntimeError('Full-length run failed')
    time.sleep(3)
cmd=[sys.executable,str(OUT/'run_case.py'),'--name','confirm-pp17-14-14-c8192','--partition','17','14','14','--chunk','8192','--kv','2','--repeats','3','--warmups','2']
p=subprocess.run(cmd,cwd='/home/bul/dev/vllm-backport',env=dict(os.environ,PYTORCH_ALLOC_CONF='expandable_segments:True'),timeout=1100)
if p.returncode:
    raise SystemExit(p.returncode)
print('RUNNER_UP_DONE',flush=True)
