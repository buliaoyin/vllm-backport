import json
import os
import statistics
import subprocess
import sys
import time
from pathlib import Path

OUT = Path('/tmp/exl3-3x170hx-20260911')
ROOT = Path('/home/bul/dev/vllm-backport')
while 'SEARCH_DONE' not in (OUT / 'search-runner.log').read_text():
    if 'Traceback (most recent call last)' in (OUT / 'search-runner.log').read_text():
        raise RuntimeError('Search failed; investigate before confirmation')
    time.sleep(3)

env = dict(os.environ, PYTORCH_ALLOC_CONF='expandable_segments:True')
results = json.loads((OUT / 'search-results.json').read_text())

def run(name, partition, chunk, full=False, native=False):
    command = [sys.executable, str(OUT / 'run_case.py'), '--name', name,
               '--partition', *map(str, partition), '--chunk', str(chunk), '--kv', '2']
    if full:
        command += ['--full', '--repeats', '3', '--warmups', '2']
    if native:
        command.append('--native')
    p = subprocess.run(command, cwd=ROOT, env=env, timeout=1100)
    if p.returncode:
        if 'torch.OutOfMemoryError' not in (OUT / (name + '.log')).read_text():
            raise RuntimeError(f'Unexpected failure in {name}')
        print('EXCLUDE_OOM', name, flush=True)
        return None
    d = json.loads((OUT / (name + '.json')).read_text())
    rows = [r['rows'][0] for r in d['perf'] if r['rows'][0]['prompt_tokens'] == 65536]
    result = {'name': name, 'partition': partition, 'chunk': chunk, 'kv_gib': 2,
              'input_tps': statistics.median(65536 / r['ttft'] for r in rows),
              'output_tps': statistics.median((r['new_tokens'] - 1) / r['decode'] for r in rows)}
    print('RESULT', json.dumps(result), flush=True)
    return result

for part in ([16, 14, 15], [15, 15, 15]):
    name = 'pp' + '-'.join(map(str, part)) + '-c4096-kv2-expand'
    r = run(name, part, 4096)
    if r:
        results.append(r)
int8_results = [r for r in results if not r['name'].startswith('native-')]
best = max(int8_results, key=lambda r: r['input_tps'])
(OUT / 'final-selection.json').write_text(json.dumps({'candidates': results, 'selected': best}, indent=2))
print('FINAL_SELECTED', json.dumps(best), flush=True)
assert run('final-int8-full', best['partition'], best['chunk'], full=True)
assert run('final-native-full', best['partition'], 2048, full=True, native=True)
print('FINAL_DONE', flush=True)
