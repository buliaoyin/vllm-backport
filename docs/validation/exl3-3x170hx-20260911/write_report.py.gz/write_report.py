import json
from pathlib import Path

OUT = Path('/tmp/exl3-3x170hx-20260911')
ROOT = Path('/home/bul/dev/vllm-backport')
summary = json.loads((OUT / 'summary.json').read_text())
selected = json.loads((OUT / 'final-selection.json').read_text())['selected']
int8 = summary['final-int8-full']
native = summary['final-native-full']
reference = summary['reference-4gpu-off-full']
part = selected['partition']
chunk = selected['chunk']
pp = '/'.join(map(str, part))

def by_length(d):
    return {x['prompt_tokens']: x for x in d['perf']}

a, b, c = map(by_length, (int8, native, reference))
rows, reference_rows = [], []
for n in sorted(a):
    x, y, z = a[n], b[n], c[n]
    rows.append(f"| {n//1024}K | {y['input_tps']:.1f} | {y['output_tps']:.2f} | {x['input_tps']:.1f} | {x['output_tps']:.2f} | {(x['input_tps']/y['input_tps']-1)*100:+.2f}% |")
    reference_rows.append(f"| {n//1024}K | {x['input_tps']:.1f} / {x['output_tps']:.2f} | {z['input_tps']:.1f} / {z['output_tps']:.2f} | {(x['input_tps']/z['input_tps']-1)*100:+.2f}% |")
search_rows = []
for p in sorted(OUT.glob('*-kv2-expand-status.json')):
    s = json.loads(p.read_text())
    name = s['name']
    cmd = s['command']
    i = cmd.index('--expected-layer-counts')
    counts = '/'.join(cmd[i+1:i+4])
    size = cmd[cmd.index('--chunk-size')+1]
    mode = '原生 M32' if name.startswith('native-') else 'INT8'
    if s.get('exit_code') == 0:
        r = summary[name]['perf'][0]
        search_rows.append(f"| {counts} | {size} | {mode} | {r['input_tps']:.1f} | {r['output_tps']:.2f} | 完成 |")
    else:
        search_rows.append(f'| {counts} | {size} | {mode} | — | — | 启动 OOM |')
runner_up = summary['confirm-pp17-14-14-c8192']['perf'][0]
short_tradeoff = ('本次 8K、16K 下原生 M32 / chunk 2048 更快，16K 差距较小；32K、64K 则是 INT8 / chunk 6144 更快。因此应按输入长度分布选择部署配置，不宜把大 chunk 作为所有 B1 请求的统一最优配置。' if a[8192]['input_tps'] < b[8192]['input_tps'] else '8K 结果也随表保留，配置选择仍需结合实际输入长度分布。')
all_new = [d for name,d in summary.items() if name != 'reference-4gpu-off-full']
checks = sum(x['checks'] for x in all_new)
passed = sum(x['passed'] for x in all_new)
samples = '\n'.join(f"- {n//1024}K：输入 {', '.join(f'{v:.1f}' for v in a[n]['input_samples'])}；输出 {', '.join(f'{v:.2f}' for v in a[n]['output_samples'])}。" for n in sorted(a))
report = f'''# GLM-5.3-Flash EXL3：三张 CMP 170HX 的 PP 调优

测试始于 2026-09-11，使用 GPU0、1、2；RTX PRO 6000 全程不参与本次推理。

三张 170HX 可以运行 GLM-5.3-Flash EXL3 4.05bpw 的完整 45 层文本主干并处理 64K 输入。本次关闭视觉输入，不启用 MTP。本轮搜索后用于全长度复测的组合为 **PP `{pp}`、chunk `{chunk}`、每 rank KV 2 GiB**，开启上一轮的 SM80 临时 INT8 专家 prefill 实验，关闭普通投影 FP16 缓存。64K 输入吞吐中位数为 **{a[65536]['input_tps']:.1f} token/s**，TTFT **{a[65536]['ttft_seconds']:.3f} 秒**，decode **{a[65536]['output_tps']:.2f} token/s**。

这是针对当前机器、模型及 B1 长输入的实测选择，不是所有负载下的最优分层，也没有将实验后端改为生产默认。

## 输入与输出吞吐

单位均为 token/s。每个长度预热 2 次、正式测量 3 次，表中取中位数；每次独立请求生成 32 token。输入吞吐为 `prompt_tokens / TTFT`；decode 吞吐为 `(new_tokens - 1) / decode_seconds`，排除首 token。没有 prefix-cache 命中。测速期间关闭 event profiler。未锁定 GPU 时钟；随记录保存温度和时钟采样，逐次速度也完整保留。

原生控制组与 INT8 组使用相同的 PP `{pp}`、KV 预算、设备及输入；原生组使用生产的 M32 / chunk 2048，INT8 组使用 chunk {chunk}，因此收益包含后端与 chunk 的组合变化。

| 输入 | 三卡原生：输入 | 三卡原生：输出 | 三卡 INT8：输入 | 三卡 INT8：输出 | 输入收益 |
| --- | ---: | ---: | ---: | ---: | ---: |
{chr(10).join(rows)}

{short_tradeoff}

INT8 最终复测的逐次样本：

{samples}

## 与此前四卡部署比较

四卡参考来自普通投影缓存消融的 `off-full.json.gz`，即 3 × CMP 170HX 加 1 × RTX PRO 6000 Blackwell，PP `11/11/11/12`、chunk 6144、KV 8 GiB/rank、普通 FP16 投影缓存关闭。使用相同输入文件 SHA256、生成长度与吞吐定义，每个长度同样各 3 次。三卡组使用 KV 2 GiB/rank 和可扩展显存分配器；这是两种实际部署配置的对比，不能把全部差异归因于卡数。

| 输入 | 三卡 INT8：输入 / 输出 | 历史四卡 INT8：输入 / 输出 | 三卡输入变化 |
| --- | ---: | ---: | ---: |
{chr(10).join(reference_rows)}

四卡参考的最后 12 层使用 SM120 原专家路径；三卡的所有 MoE 层都在 SM80 上。普通投影 `EXL3_INT8_GEMV=2` 保持相同；专家 decode 按生产架构策略运行，本次三卡均实际记录为 `plain`。

## PP 与 chunk 搜索

以下搜索统一使用 KV 2 GiB/rank、`PYTORCH_ALLOC_CONF=expandable_segments:True`，其余参数不变。完成的候选各预热 1 次、正式测量 2 次 64K 请求；最终表格使用上面的独立全长度复测，不将搜索最高单次样本当作最终成绩。

| PP | chunk | 后端 | 64K 输入 token/s | decode token/s | 结果 |
| --- | ---: | --- | ---: | ---: | --- |
{chr(10).join(search_rows)}

接近方案的独立确认：`16/15/14 + 6144` 的三次 64K 中位数为 {a[65536]['input_tps']:.1f} token/s，`17/14/14 + 8192` 为 {runner_up['input_tps']:.1f} token/s，分别预热 2 次。后者三次输入样本为 {', '.join(f'{x:.1f}' for x in runner_up['input_samples'])}。二者的接近程度应结合原始样本理解，不宣称小幅差距在所有负载中稳定成立。

最前面 3 层为较轻的 dense 层，后面 42 层为 MoE；层数平均不等于计算量或显存平均。`16/15/14` 将更多层放在首卡，同时给末卡的输出头留空间。固定 chunk 6144 的同条件搜索中，`17/14/14` 为 3778.1 token/s，`16/15/14` 为 3896.1 token/s，后者约快 3.12%，decode 基本不变。

独立 CUDA event 采样中，`17/14/14` 的三段完整 chunk 层耗时中位数之和约为 1329.5 / 1162.2 / 1203.3 ms；`16/15/14` 为 1260.4 / 1240.9 / 1206.7 ms。前者采于初始 KV 4 GiB / 默认分配器，后者为 KV 2 GiB / 可扩展分配器；它们仅帮助解释负载分布。PP 阶段会重叠，不能把三段相加作为请求延迟；嵌套 kernel 区间也没有重复相加。正式速度取无 profiler 的请求。

## 显存与启动限制

初始 `17/14/14 + chunk 6144 + KV 4 GiB` 可运行，64K 两次输入中位数 3797.8 token/s。相同初始设置下，`16/15/14` 在启动 profile 时申请 4.25 GiB MLA 临时缓冲失败，当时只有 4.05 GiB 空闲，另有约 636 MiB 已保留但未使用的 PyTorch 显存。

源码确认这一步在 KV 缓存实际分配之前，单纯降低 KV 预算不能解决该启动 OOM。后续统一启用可扩展分配器，并采用 2 GiB KV 预算为实际运行留空间。`16/15/14 + chunk 6144` 记录的 KV 容量约 367664 token，足够本次 B1、64K 验证；它不是实测并发吞吐或最大可服务容量承诺。

`16/14/15` 和 `15/15/15` 在 chunk 6144 下仍于最后一张卡启动 OOM；`16/15/14` 在 chunk 8192 下也失败。失败日志一并归档。启动日志显示该模型没有可用的 dense-MHA prefill 后端，实际走稀疏 top-k MQA；但当前 `MLAAttention.forward_impl` 的 dummy 分支仍无条件申请上述 4.25 GiB 通用预检缓冲。因此这里的 OOM 是当前实现的启动约束，不能据此认定权重本身或实际稀疏 attention 必然放不下。减少这项保守预检可能扩大可选配置；本次保持代码一致，仅比较运行参数。

INT8 专家工作区与普通投影 FP16 缓存是两套机制：本次 `linear_cache` 在所有 rank 均为 `None`，仍保留 INT8 临时权重、激活量化和原 EXL3 workspace。GPU 监控每 5 秒采样一次，其显存值是观测值，不是无遗漏的瞬时峰值。

## 验证范围与复现

本次成功配置合计 **{passed}/{checks}** 个计时请求的访问码校验通过，最终两组全长度复测为 **{int8['passed']+native['passed']}/{int8['checks']+native['checks']}**。这检查长输入中指定答案的检索，不等同于完整语言能力或长上下文精度评测。

每次运行均检查实际 GPU 名称和层索引、32 个新 token、零缓存命中、普通缓存关闭、专家 decode 模式。INT8 组还检查实际 backend 调用、阈值 4096 及生成的 IMMA 指令。测试沿用提交 `f6b9d0ff7` 的计算代码与实验库，未修改 CUDA 算术；源码及二进制 SHA256 随记录保存。

环境为 PyTorch 2.13.0+cu130、CUDA 13.0、ExLlamaV3 1.4.8，TP1/PP3，同机 PCIe NODE 拓扑、同一 NUMA 节点，NCCL P2P 禁用。`--batch-size 4` 是引擎容量，输入文件每个性能 case 只有一条请求，即 B1。

从仓库根目录运行，先按 [INT8 实验说明](../../benchmarks/kernels/exl3_prefill_int8/README.md)构建 `helpers.so`，并使用没有其他 EXL3 实验覆盖项的 shell：

```bash
export CUDA_DEVICE_ORDER=PCI_BUS_ID
export CUDA_VISIBLE_DEVICES=0,1,2
export OMP_NUM_THREADS=1
export NCCL_P2P_DISABLE=1
export PYTHONPATH="$PWD/benchmarks:$PWD"
export PYTORCH_ALLOC_CONF=expandable_segments:True
export VLLM_TRITON_USE_TD=0
export EXL3_INT8_GEMV=2
export VLLM_EXL3_BATCHED_INT8_LIBRARY=/tmp/exl3-prefill-int8/helpers.so
export VLLM_EXL3_BATCHED_INT8_CONFIG=m64n128k64
export VLLM_EXL3_BATCHED_INT8_MIN_ROWS=4096
export VLLM_EXL3_MOE_MAX_TOKENS={chunk}
export VLLM_PP_LAYER_PARTITION={','.join(map(str,part))}
unset VLLM_EXL3_LINEAR_CACHE_GIB

.venv/bin/python benchmarks/benchmark_exl3.py \\
  --backend vllm \\
  --inputs docs/validation/exl3-3x170hx-20260911/inputs.json.gz \\
  --output /tmp/exl3-3x170hx-full.json \\
  --pp 3 --expected-layer-counts {' '.join(map(str,part))} \\
  --max-model-len 66560 --kv-cache-gib 2 --batch-size 4 \\
  --chunk-size {chunk} --warmups 2 --repeats 3 --tokens 32 --skip-eval \\
  --worker-extension-cls benchmarks.kernels.exl3_prefill_int8.worker.WorkerExtension
```

归档输入引用本机 checkpoint 路径，异机复现时修改模型路径。初始恢复运行的分配器环境记录在 `allocator-override.json.gz`，之后各运行的 `*-status.json.gz` 直接记录该设置。

- [结果汇总](exl3-3x170hx-20260911/summary.json.gz)、[最终配置选择](exl3-3x170hx-20260911/final-selection.json.gz)。
- [源码和实验库哈希](exl3-3x170hx-20260911/metadata.json.gz)、[原始日志、命令、脚本与文件哈希清单](exl3-3x170hx-20260911/manifest.json)。
- [四卡普通投影缓存消融](exl3-linear-cache-20260911.md)。
'''
(ROOT / 'docs/validation/exl3-3x170hx-20260911.md').write_text(report)
print('Wrote report')
