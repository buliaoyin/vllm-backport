import gzip
import json
import re
import statistics
from collections import defaultdict
from pathlib import Path

OUT = Path(__file__).resolve().parent

def read(path):
    if path.suffix == '.gz':
        with gzip.open(path, 'rt') as f:
            return json.load(f)
    return json.loads(path.read_text())

def summarize(d):
    groups = defaultdict(list)
    for case in d['perf']:
        for row in case['rows']:
            groups[row['prompt_tokens']].append(row)
    perf = []
    for length, rows in sorted(groups.items()):
        values = [length / r['ttft'] for r in rows]
        decode = [(r['new_tokens'] - 1) / r['decode'] for r in rows]
        perf.append({'prompt_tokens': length, 'n': len(rows), 'new_tokens': [r['new_tokens'] for r in rows],
                     'input_tps': statistics.median(values), 'input_samples': values,
                     'ttft_seconds': statistics.median(r['ttft'] for r in rows),
                     'output_tps': statistics.median(decode), 'output_samples': decode,
                     'cached_tokens': [r['cached_tokens'] for r in rows]})
    result = {'args': d['args'], 'gpu_names': d['gpu_names'], 'perf': perf,
              'checks': sum(len(c['checks']) for c in d['perf']),
              'passed': sum(c['matched'] for x in d['perf'] for c in x['checks']),
              'actual_layers': [[x['index'] for x in r['decoder_layers']] for r in d['runtime_after']],
              'runtime': [{k: v for k, v in r.items() if k not in ('layers', 'decoder_layers')} for r in d['runtime_after']]}
    if 'event_profile' in d:
        chunk = d['resolved_chunk_size']
        length = d['event_profile']['rows'][0]['prompt_tokens']
        full_chunks = length // chunk
        result['separate_profile'] = {'seconds': d['event_profile']['seconds'], 'full_chunks': full_chunks,
            'stage_layer_median_sum_ms': [sum(statistics.median(v[:full_chunks]) for k, v in rank['timings_ms'].items() if k.startswith('layer:')) for rank in d['event_profile']['ranks']],
            'note': 'Sum of per-layer median GPU intervals across full chunks; stages overlap, nested kernel intervals are excluded. This is not whole-request latency.'}
    return result

results = {}
for path in [*OUT.glob('*.json'), *OUT.glob('*.json.gz')]:
    d = read(path)
    if isinstance(d, dict) and 'runtime_after' in d and d.get('perf'):
        results[path.name.removesuffix('.gz').removesuffix('.json')] = summarize(d)
old = OUT / 'reference-4gpu-off-full.json.gz'
if old.exists():
    results['reference-4gpu-off-full'] = summarize(read(old))
(OUT / 'summary.json').write_text(json.dumps(results, indent=2))
for name, d in results.items():
    print(name, [(x['prompt_tokens'], round(x['input_tps'], 1), round(x['output_tps'], 2), x['n']) for x in d['perf']])
    if 'separate_profile' in d:
        print('  diagnostic stage ms', [round(x, 1) for x in d['separate_profile']['stage_layer_median_sum_ms']])
