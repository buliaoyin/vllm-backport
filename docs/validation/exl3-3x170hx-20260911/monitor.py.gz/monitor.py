import csv
import json
import subprocess
import time
from pathlib import Path

OUT = Path('/tmp/exl3-3x170hx-20260911')
end = time.time() + 5400
with (OUT / 'gpu-samples.jsonl').open('w') as f:
    while time.time() < end and not (OUT / 'MONITOR_STOP').exists():
        states = []
        for p in OUT.glob('*-status.json'):
            s = json.loads(p.read_text())
            if 'exit_code' not in s:
                states.append(s['name'])
        command = ['nvidia-smi', '--query-gpu=index,memory.used,power.draw,clocks.sm,clocks.mem,utilization.gpu,temperature.gpu', '--format=csv,noheader,nounits']
        data = subprocess.check_output(command, text=True)
        f.write(json.dumps({'time': time.time(), 'cases': states, 'gpus': list(csv.reader(data.splitlines()))}) + '\n')
        f.flush()
        time.sleep(5)
