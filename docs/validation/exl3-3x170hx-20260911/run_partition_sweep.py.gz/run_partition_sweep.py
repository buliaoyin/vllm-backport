import json
import subprocess
import sys
import time
from pathlib import Path

OUT=Path('/tmp/exl3-3x170hx-20260911')
while 'VALIDATED pp17-14-14-c6144' not in (OUT/'initial-runner.log').read_text():
 s=json.loads((OUT/'pp17-14-14-c6144-status.json').read_text())
 if s.get('exit_code',0)!=0:raise RuntimeError('Initial three-GPU run failed')
 time.sleep(3)
for part,profile in [([16,15,14],True),([15,15,15],False),([16,14,15],False)]:
 name='pp'+'-'.join(map(str,part))+'-c6144'
 command=[sys.executable,str(OUT/'run_case.py'),'--name',name,'--partition',*map(str,part)]
 if profile:command+=['--profile']
 print('RUN',name,flush=True)
 p=subprocess.run(command,cwd='/home/bul/dev/vllm-backport',timeout=1100)
 if p.returncode:raise SystemExit(p.returncode)
print('PARTITION_SWEEP_DONE',flush=True)
