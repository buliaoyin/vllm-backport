import hashlib
import json
from pathlib import Path

OUT=Path('/tmp/exl3-3x170hx-20260911')
ROOT=Path('/home/bul/dev/vllm-backport')
meta=json.loads((OUT/'metadata.json').read_text())
for path,expected in meta['sources'].items():
    assert hashlib.sha256((ROOT/path).read_bytes()).hexdigest()==expected,path
lib=Path('/tmp/exl3-target4700-20260911/kernels-batched-int8-r1/helpers.so')
assert hashlib.sha256(lib.read_bytes()).hexdigest()==meta['library_sha256']
records=[]
for path in sorted(OUT.glob('*-status.json')):
    status=json.loads(path.read_text());name=status['name']
    assert 'exit_code' in status,f'Incomplete run: {name}'
    log=(OUT/(name+'.log')).read_text()
    in_measure=False;jit=[]
    for line in log.splitlines():
        if line.startswith('MEASURE '):in_measure=True
        if line.startswith('PERF '):in_measure=False
        if in_measure and 'JIT compilation during inference' in line:jit.append(line)
    assert not jit,(name,jit)
    if status['exit_code']:
        assert 'torch.OutOfMemoryError' in log,name
        records.append({'name':name,'status':'startup OOM','jit_during_measure':jit})
        continue
    d=json.loads((OUT/(name+'.json')).read_text())
    assert d['benchmark_source_sha256']==meta['sources']['benchmarks/benchmark_exl3.py']
    assert len(d['gpu_names'])==3 and all('170HX' in n for n in d['gpu_names'])
    assert [x['index'] for r in d['runtime_after'] for x in r['decoder_layers']]==list(range(45))
    for r in d['runtime_after']:
        assert r['linear_cache'] is None
        assert all(x['decode_mode']=='plain' for x in r['layers'])
        b=r.get('batched_int8_prefill')
        if b:
            assert b['calls']>0 and b['minimum_rows']==4096
            assert all(x['imma'] for x in b['gemm_kernels'].values())
    checks=[]
    for c in d['perf']:
        assert len(c['rows'])==1
        assert c['rows'][0]['new_tokens']==32 and c['rows'][0]['cached_tokens']==0
        checks.extend(c['checks'])
    assert all(c['matched'] for c in checks),name
    records.append({'name':name,'status':'passed','requests':len(checks),'jit_during_measure':jit})
(OUT/'audit.json').write_text(json.dumps(records,indent=2)+'\n')
print('Validated',sum(r['status']=='passed' for r in records),'successful runs and',sum(r['status']=='startup OOM' for r in records),'recorded startup OOMs')
print('Timed retrieval checks',sum(r.get('requests',0) for r in records))
