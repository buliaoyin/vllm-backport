import json
import statistics
import subprocess
import sys
import time
from pathlib import Path

OUT=Path('/tmp/exl3-3x170hx-20260911')
while 'PARTITION_SWEEP_DONE' not in (OUT/'partition-runner.log').read_text():
 for p in OUT.glob('pp*-c6144-status.json'):
  if json.loads(p.read_text()).get('exit_code',0)!=0:raise RuntimeError('Partition sweep failed')
 time.sleep(3)
candidates=[]
for part in [[17,14,14],[16,15,14],[15,15,15],[16,14,15]]:
 name='pp'+'-'.join(map(str,part))+'-c6144'
 d=json.loads((OUT/(name+'.json')).read_text())
 tps=statistics.median(65536/r['rows'][0]['ttft'] for r in d['perf'])
 candidates.append({'partition':part,'tps':tps,'name':name})
best=max(candidates,key=lambda r:r['tps'])
(OUT/'partition-selection.json').write_text(json.dumps({'candidates':candidates,'selected':best},indent=2))
print('SELECTED',best,flush=True)
for chunk,native in [(8192,False),(4096,False),(2048,True)]:
 name=('native-' if native else '')+'pp'+'-'.join(map(str,best['partition']))+'-c'+str(chunk)
 command=[sys.executable,str(OUT/'run_case.py'),'--name',name,'--partition',*map(str,best['partition']),'--chunk',str(chunk)]
 if native:command+=['--native']
 p=subprocess.run(command,cwd='/home/bul/dev/vllm-backport',timeout=1100)
 if p.returncode:raise SystemExit(p.returncode)
print('CHUNK_SWEEP_DONE',flush=True)
