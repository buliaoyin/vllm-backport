import json
from pathlib import Path

ROOT = Path('/home/bul/dev/vllm-backport')
OUT = Path('/tmp/exl3-linear-cache-ablation-20260911')
s = json.loads((OUT / 'summary.json').read_text())
c = s['combined_64k']
lines = []
for n, label in [(8192, '8K'), (16384, '16K'), (32768, '32K')]:
    row = s['full_length_comparison'][str(n)]
    lines.append(f"| {label} | {row['cache_off_tps']:.1f} | {row['cache_on_tps']:.1f} | {row['cache_gain_percent']:.2f}% |")
lines.append(f"| 64K，合并正反序样本 | {c['cache_off']['median_tps']:.1f} | {c['cache_on']['median_tps']:.1f} | {c['cache_gain_percent']:.2f}% |")
pairs = []
for off, on, label in [('off-full', 'on-full', '先开后关，各 3 次'), ('off-confirm', 'on-confirm', '先关后开，各 5 次')]:
    a = s['runs'][on]['lengths']['65536']['median_prompt_tokens_per_second']
    b = s['runs'][off]['lengths']['65536']['median_prompt_tokens_per_second']
    pairs.append(f'| {label} | {b:.1f} | {a:.1f} | {100 * (a / b - 1):.2f}% |')
text = f'''# 普通投影 FP16 缓存消融（2026-09-11）

**从推荐的 INT8 + chunk 6144 组合中移除普通投影 FP16 缓存。** 固定分层的正反序对照中，缓存对 64K 输入吞吐贡献约 **{c['cache_gain_percent']:.2f}%**，TTFT 缩短约 **{c['ttft_saved_ms']:.0f} ms**，代价是三张 SM80 合计 **10.09 GiB** 常驻 FP16 权重副本。

## 同配置实测

单位为输入 token/s，即 `prompt_tokens / TTFT`，取中位数。8K–32K 每配置各 3 次；64K 合并正反序测量，每配置各 8 次。所有测量均不带 event profiler。

| 输入 | 关闭缓存 | 开启缓存，预算 4 GiB/SM80 | 缓存收益 |
| --- | ---: | ---: | ---: |
{chr(10).join(lines)}

64K 关闭缓存 TTFT 中位数为 **{c['cache_off']['median_ttft_seconds']:.3f} 秒**，开启为 **{c['cache_on']['median_ttft_seconds']:.3f} 秒**。两轮各自结果如下，避免仅靠合并中位数掩盖顺序影响：

| 测试顺序 | 关闭缓存 token/s | 开启缓存 token/s | 缓存收益 |
| --- | ---: | ---: | ---: |
{chr(10).join(pairs)}

64K 原始样本按执行顺序：

- 关闭：{', '.join(f'{v:.1f}' for v in c['cache_off']['samples'])}。
- 开启：{', '.join(f'{v:.1f}' for v in c['cache_on']['samples'])}。

单轮连续请求存在向下漂移，正反序结果是本次贡献判断的依据；不把不足 2% 的差距描述成所有机器和负载的固定收益。原报告的 **4738 token/s** 是另一轮带缓存复测的实测值，不能直接换标签充当关闭缓存的成绩。

## 条件与覆盖

- GLM-5.3-Flash EXL3 4.05bpw，GPU0–2 为 CMP 170HX / SM80，GPU3 为 RTX PRO 6000 Blackwell / SM120。单机 PCIe，GPU 间拓扑为 NODE，同一 NUMA 节点；NCCL P2P 禁用。
- TP1、PP4，实际 decoder 层索引固定为 0–10、11–21、22–32、33–44，即 `11/11/11/12`。B1，生成 32 token，每 rank KV 8 GiB，max length 66560，无 prefix-cache 命中。
- 相同 checkpoint、token IDs、实验库和计算源码。专家采用 `m64n128k64`、阈值 4096、chunk/workspace 6144；普通 INT8 GEMV 2，混合专家 decode 保持生产配置。GPU3 保留原专家路径。
- 顺序为开缓存全长度、关缓存全长度、关缓存 64K、开缓存 64K。每种输入形状预热 2 次；每组启动独立引擎，使关闭组确实不分配缓存。
- 关闭组各 rank 的 `linear_cache` 均为 `None`，SM80 的 INT8 backend 调用仍存在，两个 GEMM 形状均记录 IMMA。开启组确认缓存命中及实际分配量。
- **{s['checks_passed']}/{s['checks_passed']} 访问码检查通过**。这验证指定检索答案，不等同于完整长上下文质量评测；本轮未新增 GSM8K 对照。

## 为什么可以去掉

这份缓存由 `benchmarks/kernels/exl3_prefill/linear_cache.py` 在加载时展开普通量化投影权重。它覆盖注意力投影、共享专家等被预算选中的 Linear，输入行数达到 1024 才使用缓存；B1 decode 仍走原量化路径。

它与 INT8 MoE 专家的临时权重重建和 grouped IMMA 没有依赖关系。移除后，普通投影恢复原 EXL3 实现，专家优化继续生效。完整请求收益约 1%，因此它的显存成本不适合推荐组合。

| GPU | 省去的常驻 FP16 权重副本 |
| --- | ---: |
| GPU0 / SM80 | 3.867 GiB |
| GPU1 / SM80 | 3.113 GiB |
| GPU2 / SM80 | 3.113 GiB |
| GPU3 / SM120 | 0 |
| 合计 | **10.094 GiB** |

这是直接记录的权重副本分配量，不是整进程峰值显存下降量。新 INT8 专家的临时缓冲、原专家 workspace 和 KV cache 仍需要保留。

先前两组独立历史对照也支持收益偏小：M32/K16 + chunk 2048 在 64K 从 4093.9 到 4164.5 token/s（+1.73%）；专家展开 FP16 + chunk 8192 从 4405.4 到 4419.4（+0.32%）。这些不同配置的比例不替代上面的最终 INT8 消融。

## 配置与证据

[INT8 实验推荐命令](../../benchmarks/kernels/exl3_prefill_int8/README.md)已经改为：

```bash
unset VLLM_EXL3_LINEAR_CACHE_GIB
```

生产默认此前就没有启用这份实验缓存。缓存实验代码仍可显式开启以复现历史测量；当前推荐长输入组合不再为它保留 FP16 权重副本。

- [结果汇总](exl3-linear-cache-20260911/summary.json.gz)、[命令与环境](exl3-linear-cache-20260911/status.json.gz)、[源码及库哈希](exl3-linear-cache-20260911/metadata.json.gz)。
- [原始记录清单](exl3-linear-cache-20260911/manifest.json)：完整请求记录、日志、输入、测量脚本与分析脚本，均附 SHA256。
- [此前 4700 目标报告](exl3-target4700-20260911.md)保留带缓存的真实结果和显存成本。
'''
(ROOT / 'docs/validation/exl3-linear-cache-20260911.md').write_text(text)
print('Cache ablation report written')
