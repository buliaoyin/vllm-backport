import gzip
import hashlib
import json
from pathlib import Path

ROOT = Path('/home/bul/dev/vllm-backport')
OUT = Path('/tmp/exl3-linear-cache-ablation-20260911')
ARCHIVE = ROOT / 'docs/validation/exl3-linear-cache-20260911'
ARCHIVE.mkdir(exist_ok=True)
status = json.loads((OUT / 'status.json').read_text())
assert len(status) == 4 and all(r.get('exit_code') == 0 for r in status)
files = ['metadata.json', 'status.json', 'summary.json', 'run_ablation.py', 'analyze.py',
         'archive.py', 'write_report.py', 'benchmark_exl3.py', 'inputs.json.gz', 'confirmation-inputs.json.gz', 'runner.log']
files += [r['name'] + suffix for r in status for suffix in ['.json', '.log']]
manifest = []
for name in files:
    source = OUT / name
    data = source.read_bytes()
    artifact = ARCHIVE / (name if name.endswith('.gz') else name + '.gz')
    encoded = data if name.endswith('.gz') else gzip.compress(data, mtime=0)
    artifact.write_bytes(encoded)
    manifest.append({'source': str(source), 'artifact': artifact.name,
                     'original_sha256': hashlib.sha256(data).hexdigest(),
                     'artifact_sha256': hashlib.sha256(encoded).hexdigest()})
(ARCHIVE / 'manifest.json').write_text(json.dumps({'scope': 'Only ordinary FP16 projection cache toggled; fixed PP 11/11/11/12, INT8 m64n128k64 and chunk 6144.', 'artifacts': manifest}, indent=2))
print(len(manifest), 'artifacts archived')
