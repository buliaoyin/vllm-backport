import gzip
import hashlib
import json
import statistics
from pathlib import Path

ROOT = Path('/home/bul/dev/vllm-backport')
OUT = Path('/tmp/exl3-linear-cache-ablation-20260911')
status = json.loads((OUT / 'status.json').read_text())
assert len(status) == 4 and all(r.get('exit_code') == 0 for r in status)
inputs = {name: json.loads(gzip.decompress((OUT / name).read_bytes()))
          for name in ['inputs.json.gz', 'confirmation-inputs.json.gz']}
assert inputs['confirmation-inputs.json.gz']['cases'] == [c for c in inputs['inputs.json.gz']['cases'] if c['name'] == 'p65536_b1']
expected_layers = [list(range(0, 11)), list(range(11, 22)), list(range(22, 33)), list(range(33, 45))]
runs = {}
pooled = {True: [], False: []}
for entry in status:
    name, enabled = entry['name'], entry['cache_enabled']
    data = json.loads((OUT / (name + '.json')).read_text())
    ranks = sorted(data['runtime_after'], key=lambda r: r['pp_rank'])
    assert [[d['index'] for d in r['decoder_layers']] for r in ranks] == expected_layers
    assert data['resolved_chunk_size'] == 6144 and data['args']['kv_cache_gib'] == 8
    medians = {}
    for length in [8192, 16384, 32768, 65536]:
        selected = [s['rows'][0] for s in data['perf'] if s['rows'][0]['prompt_tokens'] == length]
        if not selected:
            continue
        samples = [length / row['ttft'] for row in selected]
        medians[str(length)] = {'prompt_tokens_per_second': samples,
                                'median_prompt_tokens_per_second': statistics.median(samples),
                                'median_ttft_seconds': statistics.median(row['ttft'] for row in selected),
                                'decode_tokens_per_second': statistics.median((row['new_tokens'] - 1) / row['decode'] for row in selected)}
        if length == 65536:
            pooled[enabled].extend(samples)
    for sample in data['perf']:
        assert len(sample['rows']) == 1 and sample['rows'][0]['cached_tokens'] == 0
        assert all(check['matched'] for check in sample['checks'])
    memory = []
    for rank in ranks:
        cache = rank['linear_cache']
        count = sum(v['bytes'] for v in cache['devices'].values()) if cache else 0
        if enabled and rank['pp_rank'] < 3:
            assert count > 0 and cache['hits'] > 0
        if not enabled:
            assert cache is None
        backend = rank['batched_int8_prefill']
        if rank['pp_rank'] < 3:
            assert backend['minimum_rows'] == 4096 and backend['calls'] > 0
        else:
            assert backend is None
        memory.append({'pp_rank': rank['pp_rank'], 'cache_bytes': count,
                       'cache_hits': cache['hits'] if cache else 0,
                       'int8_calls': backend['calls'] if backend else 0})
    runs[name] = {'cache_enabled': enabled, 'lengths': medians, 'runtime': memory,
                  'passed_retrieval_checks': sum(len(s['checks']) for s in data['perf'])}
comparison = {}
for length in runs['on-full']['lengths']:
    on = runs['on-full']['lengths'][length]
    off = runs['off-full']['lengths'][length]
    comparison[length] = {'cache_on_tps': on['median_prompt_tokens_per_second'],
                          'cache_off_tps': off['median_prompt_tokens_per_second'],
                          'cache_gain_percent': 100 * (on['median_prompt_tokens_per_second'] / off['median_prompt_tokens_per_second'] - 1),
                          'ttft_saved_ms': 1000 * (off['median_ttft_seconds'] - on['median_ttft_seconds'])}
confirmation = {label: {'samples': pooled[value], 'median_tps': statistics.median(pooled[value]),
                        'min_tps': min(pooled[value]), 'max_tps': max(pooled[value]),
                        'median_ttft_seconds': statistics.median(65536 / v for v in pooled[value])}
                for label, value in [('cache_on', True), ('cache_off', False)]}
confirmation['cache_gain_percent'] = 100 * (confirmation['cache_on']['median_tps'] / confirmation['cache_off']['median_tps'] - 1)
confirmation['ttft_saved_ms'] = 1000 * (confirmation['cache_off']['median_ttft_seconds'] - confirmation['cache_on']['median_ttft_seconds'])
summary = {'metric': 'prompt tokens / TTFT; B1; only ordinary projection cache toggled',
           'runs': runs, 'full_length_comparison': comparison, 'combined_64k': confirmation,
           'checks_passed': sum(r['passed_retrieval_checks'] for r in runs.values()),
           'evidence_sha256': {r['name'] + '.json': hashlib.sha256((OUT / (r['name'] + '.json')).read_bytes()).hexdigest() for r in status}}
(OUT / 'summary.json').write_text(json.dumps(summary, indent=2))
print(json.dumps({k: v for k, v in summary.items() if k not in ['runs', 'evidence_sha256']}, indent=2))
