import gzip
import hashlib
import json
import os
import shutil
import subprocess
import time
from pathlib import Path

ROOT = Path('/home/bul/dev/vllm-backport')
OUT = Path('/tmp/exl3-linear-cache-ablation-20260911')
ARCHIVE = ROOT / 'docs/validation/exl3-target4700-20260911'
LIBRARY = Path('/tmp/exl3-target4700-20260911/kernels-batched-int8-r1/helpers.so')
PYTHON = str(ROOT / '.venv/bin/python')
for name in ['inputs.json.gz', 'confirmation-inputs.json.gz']:
    shutil.copy2(ARCHIVE / name, OUT / name)
source_files = [ROOT / 'benchmarks/benchmark_exl3.py',
                *sorted((ROOT / 'benchmarks/kernels/exl3_prefill_int8').glob('*.py')),
                ROOT / 'benchmarks/kernels/exl3_prefill_fp16/backend.py',
                ROOT / 'benchmarks/kernels/exl3_prefill/linear_cache.py',
                ROOT / 'benchmarks/kernels/exl3_prefill/worker.py',
                ROOT / 'vllm/model_executor/layers/quantization/exl3.py']
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
metadata = {'revision': subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=ROOT, text=True).strip(),
            'sources': {str(p.relative_to(ROOT)): sha(p) for p in source_files},
            'library_sha256': sha(LIBRARY), 'production_extension_sha256': sha(ROOT / 'vllm/_exl3_C.abi3.so'),
            'metric': 'prompt tokens / TTFT, B1, clean whole-request measurement',
            'order': ['on-full', 'off-full', 'off-confirm', 'on-confirm']}
(OUT / 'metadata.json').write_text(json.dumps(metadata, indent=2))
shutil.copy2(ROOT / 'benchmarks/benchmark_exl3.py', OUT / 'benchmark_exl3.py')
status = []
def telemetry():
    return subprocess.check_output(['nvidia-smi', '--query-gpu=index,name,memory.used,utilization.gpu,temperature.gpu,clocks.sm,clocks.mem,power.draw', '--format=csv'], text=True)
for name, enabled, full, repeats in [('on-full', True, True, 3), ('off-full', False, True, 3),
                                     ('off-confirm', False, False, 5), ('on-confirm', True, False, 5)]:
    env = {k: v for k, v in os.environ.items() if not k.startswith(('EXL3_', 'VLLM_EXL3_'))}
    env.update(CUDA_DEVICE_ORDER='PCI_BUS_ID', CUDA_VISIBLE_DEVICES='0,1,2,3', OMP_NUM_THREADS='1',
               NCCL_P2P_DISABLE='1', VLLM_PP_LAYER_PARTITION='11,11,11,12', VLLM_EXL3_MOE_MAX_TOKENS='6144',
               PYTHONPATH=str(ROOT / 'benchmarks') + ':' + str(ROOT), VLLM_TRITON_USE_TD='0', EXL3_INT8_GEMV='2',
               VLLM_EXL3_BATCHED_INT8_LIBRARY=str(LIBRARY), VLLM_EXL3_BATCHED_INT8_CONFIG='m64n128k64',
               VLLM_EXL3_BATCHED_INT8_MIN_ROWS='4096')
    if enabled:
        env['VLLM_EXL3_LINEAR_CACHE_GIB'] = '4'
    command = [PYTHON, str(OUT / 'benchmark_exl3.py'), '--backend', 'vllm',
               '--inputs', str(OUT / ('inputs.json.gz' if full else 'confirmation-inputs.json.gz')),
               '--output', str(OUT / (name + '.json')), '--pp', '4', '--expected-layer-counts', '11', '11', '11', '12',
               '--max-model-len', '66560', '--kv-cache-gib', '8', '--batch-size', '4', '--chunk-size', '6144',
               '--warmups', '2', '--repeats', str(repeats), '--tokens', '32', '--skip-eval',
               '--worker-extension-cls', 'benchmarks.kernels.exl3_prefill_int8.worker.WorkerExtension']
    record = {'name': name, 'cache_enabled': enabled, 'command': command,
              'environment': {k: v for k, v in env.items() if k.startswith(('CUDA_', 'EXL3_', 'VLLM_', 'NCCL_', 'OMP_', 'PYTHONPATH'))},
              'start': time.time(), 'telemetry_before': telemetry()}
    status.append(record)
    (OUT / 'status.json').write_text(json.dumps(status, indent=2))
    print('START', name, flush=True)
    with (OUT / (name + '.log')).open('w') as log:
        process = subprocess.run(command, cwd=ROOT, env=env, stdout=log, stderr=subprocess.STDOUT, timeout=900)
    record.update(exit_code=process.returncode, end=time.time(), telemetry_after=telemetry())
    (OUT / 'status.json').write_text(json.dumps(status, indent=2))
    print('DONE', name, process.returncode, flush=True)
    if process.returncode:
        raise SystemExit(process.returncode)
    result = json.loads((OUT / (name + '.json')).read_text())
    assert len(result['perf']) == repeats * (4 if full else 1)
    for sample in result['perf']:
        assert len(sample['rows']) == 1
        assert sample['rows'][0]['cached_tokens'] == 0
        assert sample['rows'][0]['new_tokens'] == 32
        assert all(c['matched'] for c in sample['checks'])
    for runtime in result['runtime_after']:
        if enabled:
            assert runtime['linear_cache']['budget_bytes'] == 4 * 1024**3
        else:
            assert runtime['linear_cache'] is None
        if runtime['pp_rank'] < 3:
            backend = runtime['batched_int8_prefill']
            assert backend['calls'] > 0 and backend['minimum_rows'] == 4096
            assert all(kernel['imma'] for kernel in backend['gemm_kernels'].values())
        else:
            assert runtime['batched_int8_prefill'] is None
    assert metadata['sources'] == {str(p.relative_to(ROOT)): sha(p) for p in source_files}
print('ALL_CHECKS_PASSED', flush=True)
